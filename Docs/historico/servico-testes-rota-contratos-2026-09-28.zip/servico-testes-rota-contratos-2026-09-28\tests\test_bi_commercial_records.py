"""
Testes da lista de contratos do dia (`/bi/commercial/overview/records`).

A rota nasceu em 25/09/2026 para a faixa Hoje ao vivo da Visão Geral
Comercial: um registro por contrato vendido ou ativado numa janela, com a
situação já decidida pelas mesmas contas dos cards. Como na rota agregada, o
acesso ao banco é trocado por um dublê; nenhum teste fala com PostgreSQL.
"""

from datetime import UTC, date, datetime

import pytest

from app.core.exceptions import ServiceUnavailableError
from app.main import app
from app.services.bi import commercial_catalog as catalog
from app.services.bi.commercial_overview import (
    _RECORDS_SQL,
    _SALES_SQL,
    build_sale_records,
    get_commercial_overview_service,
)
from tests.conftest import auth_headers, grant_menu, login_user, register_user
from tests.test_bi_commercial import UUID_VENDEDOR, FakeCommercialService, venda

ROTA = "/api/bi/v1/bi/commercial/overview/records"

# Instantes como o SGI grava: `contracted_at` à meia-noite UTC, `created_at` e
# `started_at` com a hora real (desde setembro/2026 no sinal ligado).
REGISTRADA = datetime(2026, 9, 25, 14, 32, 10, tzinfo=UTC)
LIGADA = datetime(2026, 9, 25, 19, 5, 0, tzinfo=UTC)


def contrato(**campos):
    base = dict(
        contracted_on=date(2026, 9, 25),
        created_on=date(2026, 9, 25),
        signed_on=date(2026, 9, 25),
        started_on=date(2026, 9, 25),
        event_on=date(2026, 9, 25),
        created_at=REGISTRADA,
        started_at=LIGADA,
        document_type="cpf",
    )
    base.update(campos)
    return venda(**base)


# --- Registro ---------------------------------------------------------------


def test_registro_traz_a_situacao_pronta_e_os_horarios_no_fuso_local():
    registros, qualidade = build_sale_records(
        [
            contrato(
                has_open_order=True,
                next_visit_on=date(2026, 9, 26),
                last_visit_on=date(2026, 9, 26),
                last_order_status="scheduled",
            )
        ]
    )

    assert qualidade.unmapped_status_keys == []
    [r] = registros
    assert r.id == "00012345"
    assert r.status == "ativa"
    assert r.status_key == "active"
    assert r.stage is None
    assert r.activated is True
    assert r.contracted_on == date(2026, 9, 25)
    assert r.started_on == date(2026, 9, 25)
    # A hora sai em America/Sao_Paulo com o fuso escrito, como na OS.
    assert r.created_at is not None and r.created_at.isoformat() == "2026-09-25T11:32:10-03:00"
    assert r.started_at is not None and r.started_at.isoformat() == "2026-09-25T16:05:00-03:00"
    assert r.monthly_value == 99.9
    assert r.plan_name == "600 MB"
    assert (r.city_id, r.city_label) == ("atibaia", "Atibaia")
    assert (r.seller_id, r.seller_name) == (UUID_VENDEDOR, "Ana Maria dos Santos")
    assert (r.team, r.teams) == ("comercial", ["comercial"])
    assert r.indicated is False
    assert r.person_type == "pf"
    assert r.signed_on == date(2026, 9, 25)
    assert (r.has_open_order, r.next_visit_on) == (True, date(2026, 9, 26))
    # A última visita e o status dela: o relógio e o texto do alerta da Agendada.
    assert (r.last_visit_on, r.last_order_status) == (date(2026, 9, 26), "scheduled")


@pytest.mark.parametrize(
    ("status_key", "started_on", "stage", "activated"),
    [
        # A fila do Aguardando Ativação, etapa a etapa.
        ("pending", None, "pendente", False),
        ("pending_approval", None, "pendente", False),
        ("signed", None, "assinada", False),
        ("scheduled", None, "agendada", False),
        # Cancelada sem sinal é saída antes de ativar; com sinal, ativou e
        # cancelou depois: continua venda do dia em que ligou (17/09/2026).
        ("cancelled", None, "cancelada", False),
        ("cancelled", date(2026, 9, 25), None, True),
        # Pendente com data é o SGI preenchendo a data na venda (mai a jul/2026):
        # nunca ativou.
        ("pending", date(2026, 9, 25), "pendente", False),
        # Cortesia liga o sinal sem ser venda.
        ("courtesy", date(2026, 9, 25), None, False),
        ("active", date(2026, 9, 25), None, True),
        ("financial_blocked", date(2026, 9, 25), None, True),
    ],
)
def test_situacao_sai_pelas_mesmas_contas_dos_cards(status_key, started_on, stage, activated):
    [r] = build_sale_records([contrato(status_key=status_key, started_on=started_on)])[0]

    assert (r.stage, r.activated) == (stage, activated)


def test_registro_sem_vendedor_e_sem_time_diz_isso_sem_inventar():
    [r] = build_sale_records(
        [contrato(seller_id=None, seller_name=None, team_names=(), indication_code=" ABC1 ")]
    )[0]

    assert (r.seller_id, r.seller_name) == (None, None)
    assert (r.team, r.teams) == (None, [])
    assert r.indicated is True


def test_registro_nao_expoe_o_cliente():
    """Só classificações da venda saem do cliente: nome, documento e contato nunca."""
    [r] = build_sale_records([contrato()])[0]

    campos = set(r.model_dump())
    assert "customer_kind" in campos and "person_type" in campos
    for proibido in ("customer_name", "document", "document_type", "phone", "email", "address"):
        assert proibido not in campos


def test_chave_desconhecida_sai_crua_e_vai_para_quality():
    registros, qualidade = build_sale_records([contrato(status_key="on_hold", started_on=None)])

    assert registros[0].status == "on_hold"
    assert registros[0].stage is None
    assert qualidade.unmapped_status_keys == ["on_hold"]


# --- Venda da esteira resolvida fora do fluxo (28/09/2026) --------------------

TODAS_AS_PROVAS = dict(
    has_completed_installation=True,
    has_remote_activation=True,
    has_own_equipment_online=True,
    has_invoice=True,
)


@pytest.mark.parametrize("status_key", ["pending", "pending_approval", "signed", "scheduled"])
def test_contrato_da_fila_leva_as_provas_de_sinal_na_ordem_do_catalogo(status_key):
    [r] = build_sale_records(
        [contrato(status_key=status_key, started_on=None, **TODAS_AS_PROVAS)]
    )[0]

    assert r.signal_evidence == list(catalog.SIGNAL_EVIDENCE_KEYS)
    assert r.signal_evidence == [
        "installation_completed",
        "remote_activation",
        "equipment_online",
        "invoice_issued",
    ]


@pytest.mark.parametrize(
    ("campo", "prova"),
    [
        ("has_completed_installation", "installation_completed"),
        ("has_remote_activation", "remote_activation"),
        ("has_own_equipment_online", "equipment_online"),
        ("has_invoice", "invoice_issued"),
    ],
)
def test_cada_prova_de_sinal_vale_sozinha(campo, prova):
    [r] = build_sale_records([contrato(status_key="signed", started_on=None, **{campo: True})])[0]

    assert r.signal_evidence == [prova]
    assert r.replaced_by is None


def test_contrato_da_fila_sem_prova_sai_com_a_lista_vazia():
    [r] = build_sale_records([contrato(status_key="pending", started_on=None)])[0]

    assert (r.signal_evidence, r.replaced_by) == ([], None)


def test_venda_refeita_aponta_o_contrato_que_ligou_o_sinal():
    [r] = build_sale_records(
        [contrato(status_key="pending", started_on=None, replaced_by="01441111")]
    )[0]

    assert r.replaced_by == "01441111"
    assert r.signal_evidence == []


def test_contrato_da_fila_com_prova_e_refeito_leva_os_dois():
    """
    Existe (3 contratos em 28/09/2026): o portal precisa dos dois para dizer
    que há sinal aqui E outro contrato ativo, e não mandar ativar às cegas.
    """
    [r] = build_sale_records(
        [
            contrato(
                status_key="scheduled",
                started_on=None,
                has_own_equipment_online=True,
                replaced_by="01441111",
            )
        ]
    )[0]

    assert (r.signal_evidence, r.replaced_by) == (["equipment_online"], "01441111")


@pytest.mark.parametrize("status_key", ["active", "cancelled", "financial_blocked", "courtesy"])
def test_fora_da_fila_nao_ha_prova_nem_venda_refeita(status_key):
    """
    Ativo com instalação concluída é o caminho normal, e não "sinal fora do
    fluxo": as provas e o contrato substituto só existem para a esteira.
    """
    [r] = build_sale_records(
        [contrato(status_key=status_key, replaced_by="01441111", **TODAS_AS_PROVAS)]
    )[0]

    assert (r.signal_evidence, r.replaced_by) == ([], None)


# --- Consulta ---------------------------------------------------------------


def test_sql_da_lista_recorta_pelas_duas_reguas_e_mantem_o_corpo_da_pagina():
    """
    A lista lê o que foi vendido OU ativado na janela, cada data no fuso em
    que o SGI a grava; o corpo (de-para, histórico do cliente, ordens
    agregadas) é o mesmo da página agregada, que continua lendo por evento.
    """
    lista = str(_RECORDS_SQL)
    pagina = str(_SALES_SQL)

    assert "(s.contracted_at AT TIME ZONE 'UTC')::date BETWEEN :date_from AND :date_to" in lista
    assert "(s.started_at    AT TIME ZONE 'UTC')::date BETWEEN :date_from AND :date_to" in lista
    assert ":window_start" not in lista
    assert ":window_start" in pagina and ":date_from" not in pagina
    corpo = lambda sql: sql.split("WHERE s.deleted_at IS NULL")[0]  # noqa: E731
    assert corpo(lista) == corpo(pagina)
    # As colunas novas viajam nas duas caudas.
    for coluna in (
        "AS next_visit_on",
        "AS last_visit_on",
        "AS last_order_status",
        "AS created_at",
        "AS started_at",
    ):
        assert coluna in corpo(lista)
    assert "MIN(so.scheduled_date) FILTER (WHERE so.status IN (" in lista
    assert "MAX(so.scheduled_date)" in lista


def test_esteira_e_a_fila_da_base_comercial_sem_corte_de_idade():
    """
    Com `include_queue`, entra todo contrato na fila vendido desde o início da
    base comercial (decisão do Mário em 25/09/2026: venda esquecida há meses
    tem de aparecer). A lista de situações da fila é a mesma das etapas.
    """
    lista = str(_RECORDS_SQL)
    fila = lista.split(":include_queue")[1]

    assert "(s.contracted_at AT TIME ZONE 'UTC')::date >= :base_start" in fila
    for chave in ("pending", "signed", "scheduled", "pending_approval"):
        assert f"'{chave}'" in fila
    for fora in ("'active'", "'cancelled'", "'courtesy'", "'rejected'", "'expired'"):
        assert fora not in fila.split("AND (s.contracted_at")[0]
    assert set(catalog.QUEUE_STATUS_KEYS) >= {"pending", "signed", "scheduled", "pending_approval"}
    assert "active" not in catalog.QUEUE_STATUS_KEYS


def test_sql_procura_o_sinal_fora_do_fluxo_so_na_fila():
    """
    Equipamento, fatura e contrato substituto só são procurados nos contratos
    da fila (28/09/2026), e o corpo continua o mesmo nas duas caudas.
    """
    lista = str(_RECORDS_SQL)
    corpo = lista.split("WHERE s.deleted_at IS NULL")[0]
    assert corpo == str(_SALES_SQL).split("WHERE s.deleted_at IS NULL")[0]

    for coluna in (
        "AS has_completed_installation",
        "AS has_remote_activation",
        "AS has_own_equipment_online",
        "AS has_invoice",
        "AS replaced_by",
    ):
        assert coluna in corpo
    for bloco in (") eqp ON", ") fat ON", ") troca ON"):
        antes = corpo.split(bloco)[0]
        filtro_da_fila = antes.rsplit("LEFT JOIN (", 1)[1]
        assert "q.status IN ('pending'" in filtro_da_fila
    assert "__" not in lista  # nenhum marcador do catálogo sobrou sem troca


def test_sql_nao_aceita_o_equipamento_copiado_de_outro_contrato_do_cliente():
    """
    O SGI copia o equipamento do contrato antigo quando o cliente já tem
    outro (25/09/2026): serial repetido em outro contrato do mesmo cliente não
    é prova de sinal deste.
    """
    corpo = str(_RECORDS_SQL).split("WHERE s.deleted_at IS NULL")[0]
    equipamento = corpo.split(") eqp ON")[0].rsplit("LEFT JOIN (", 1)[1]

    assert "e.status = 'online'" in equipamento
    assert "e.serial_number IS NOT NULL" in equipamento
    assert "NOT EXISTS" in equipamento
    assert "e2.serial_number = e.serial_number" in equipamento
    assert "o.customer_id = q.customer_id" in equipamento


def test_sql_da_venda_refeita_pede_o_mesmo_cliente_no_mesmo_dia_ou_depois_e_na_base():
    corpo = str(_RECORDS_SQL).split("WHERE s.deleted_at IS NULL")[0]
    troca = corpo.split(") troca ON")[0].rsplit("LEFT JOIN (", 1)[1]

    assert "o.customer_id = q.customer_id" in troca
    assert "o.id <> q.id" in troca
    assert (
        "(o.contracted_at AT TIME ZONE 'UTC')::date >= (q.contracted_at AT TIME ZONE 'UTC')::date"
        in troca
    )
    for chave in ("'active'", "'financial_blocked'", "'administrative_blocked'", "'suspended'"):
        assert chave in troca
    for fora in ("'cancelled'", "'courtesy'", "'pending'"):
        assert fora not in troca.split("o.status IN (")[1].split(")")[0]
    # Código vazio vira o id, como no próprio registro (`code or id`): texto
    # vazio derrubaria a faixa no portal. Com mais de um, o de venda mais
    # antiga, com desempate estável.
    assert "COALESCE(NULLIF(btrim(o.code), ''), o.id::text)" in troca
    assert "ORDER BY o.contracted_at, o.code, o.id" in troca


def test_sql_da_venda_refeita_exige_o_mesmo_endereco():
    """
    Decisão do Mário em 28/09/2026: em outro endereço pode ser mudança ou
    segundo ponto, e a venda continua contando no prazo (eram 8 de 32). O
    mesmo lugar é o mesmo cadastro de endereço, ou CEP e número iguais,
    porque a venda refeita costuma ganhar um cadastro novo.
    """
    corpo = str(_RECORDS_SQL).split("WHERE s.deleted_at IS NULL")[0]
    troca = corpo.split(") troca ON")[0].rsplit("LEFT JOIN (", 1)[1]

    assert "LEFT JOIN public.customer_addresses qa ON qa.id = q.customer_address_id" in troca
    assert "LEFT JOIN public.customer_addresses oa ON oa.id = o.customer_address_id" in troca
    assert "o.customer_address_id = q.customer_address_id" in troca
    assert "oa.postal_code = qa.postal_code" in troca
    assert "lower(btrim(oa.street_number)) = lower(btrim(qa.street_number))" in troca
    assert set(catalog.IN_BASE_STATUS_KEYS) >= {
        "active",
        "financial_blocked",
        "administrative_blocked",
        "suspended",
    }


def test_sql_da_ativacao_remota_aceita_a_os_encerrada():
    """
    Das OS de Ativação Remota encerradas desde junho, 15 de 17 contratos
    ligaram o sinal (25/09/2026): encerrar em vez de concluir é o erro de
    fluxo que deixa o contrato na fila, e é justamente o que se procura.
    """
    corpo = str(_RECORDS_SQL).split("WHERE s.deleted_at IS NULL")[0]

    assert (
        f"lower(cat.name) = '{catalog.REMOTE_ACTIVATION_CATEGORY}' "
        "AND so.status IN ('completed', 'closed')"
    ) in corpo
    assert "so.type = 'installation' AND so.status = 'completed'" in corpo


# --- Rota -------------------------------------------------------------------


class FakeRecordsService(FakeCommercialService):
    """Dublê da lista: guarda a janela pedida e devolve as linhas programadas."""

    def __init__(self, linhas=None, erro=None):
        super().__init__(linhas=linhas, erro=erro)
        self.janelas: list[tuple[date, date]] = []
        self.com_esteira: list[bool] = []

    def _load_records(self, date_from, date_to, include_queue):
        self.janelas.append((date_from, date_to))
        self.com_esteira.append(include_queue)
        if self.erro:
            raise self.erro
        return self.linhas


@pytest.fixture
def fake_records():
    fake = FakeRecordsService(
        linhas=[
            contrato(),
            contrato(id="b", code="2", status_key="scheduled", started_on=None, started_at=None,
                     has_open_order=True, next_visit_on=date(2026, 9, 26)),
            # Ativada hoje, vendida ontem: a herança que a faixa aponta no canto.
            contrato(id="c", code="3", contracted_on=date(2026, 9, 24), created_on=date(2026, 9, 24)),
        ]
    )
    app.dependency_overrides[get_commercial_overview_service] = lambda: fake
    yield fake
    app.dependency_overrides.pop(get_commercial_overview_service, None)


@pytest.fixture
def viewer_headers(client):
    """A lista mora na mesma página da rota agregada e cobra o mesmo menu, `commercial/overview`."""
    register_user(client, email="viewer-comercial@test.com")
    grant_menu("viewer-comercial@test.com", "commercial", "overview")
    return auth_headers(login_user(client, email="viewer-comercial@test.com"))


def test_rota_exige_token(client, fake_records):
    assert client.get(ROTA).status_code == 401
    assert fake_records.janelas == []


def test_rota_exige_o_menu_no_perfil_de_acesso(client, fake_records):
    register_user(client, email="sem-menu@test.com")
    headers = auth_headers(login_user(client, email="sem-menu@test.com"))

    resp = client.get(ROTA, headers=headers)

    assert resp.status_code == 403
    assert fake_records.janelas == []


def test_rota_devolve_a_janela_pedida_com_um_registro_por_contrato(client, fake_records, viewer_headers):
    resp = client.get(ROTA, params={"date_from": "2026-09-25", "date_to": "2026-09-25"}, headers=viewer_headers)

    assert resp.status_code == 200
    corpo = resp.json()
    assert corpo["generated_at"].endswith("-03:00")
    assert corpo["source"] == {"updated_at": "2026-07-31", "sale_rule": catalog.DEFAULT_SALE_RULE}
    assert corpo["filters"] == {
        "date_from": "2026-09-25",
        "date_to": "2026-09-25",
        "include_queue": False,
        "queue_from": None,
    }
    assert corpo["count"] == 3
    assert fake_records.janelas == [(date(2026, 9, 25), date(2026, 9, 25))]
    assert fake_records.com_esteira == [False]

    por_codigo = {r["id"]: r for r in corpo["records"]}
    assert por_codigo["00012345"]["activated"] is True
    assert por_codigo["00012345"]["created_at"] == "2026-09-25T11:32:10-03:00"
    assert (por_codigo["2"]["stage"], por_codigo["2"]["activated"]) == ("agendada", False)
    assert por_codigo["2"]["next_visit_on"] == "2026-09-26"
    assert por_codigo["3"]["contracted_on"] == "2026-09-24"
    assert por_codigo["3"]["started_on"] == "2026-09-25"
    assert corpo["quality"]["unmapped_status_keys"] == []
    # Os dois campos de 28/09/2026 viajam em TODO registro, mesmo vazios: o
    # portal recusa a resposta sem eles.
    for registro in corpo["records"]:
        assert registro["signal_evidence"] == []
        assert registro["replaced_by"] is None


def test_rota_com_esteira_pede_a_fila_e_diz_de_quando_ela_vale(client, fake_records, viewer_headers):
    resp = client.get(
        ROTA,
        params={"date_from": "2026-09-25", "date_to": "2026-09-25", "include_queue": "true"},
        headers=viewer_headers,
    )

    assert resp.status_code == 200
    assert fake_records.com_esteira == [True]
    assert resp.json()["filters"]["include_queue"] is True
    assert resp.json()["filters"]["queue_from"] == "2026-01-01"


def test_rota_sem_janela_le_a_base_inteira_ate_hoje(client, fake_records, viewer_headers):
    resp = client.get(ROTA, headers=viewer_headers)

    assert resp.status_code == 200
    [(inicio, fim)] = fake_records.janelas
    assert inicio == catalog.BASE_START
    assert fim >= date(2026, 9, 25)
    assert resp.json()["filters"]["date_from"] == "2026-01-01"


def test_rota_recusa_janela_invertida(client, fake_records, viewer_headers):
    resp = client.get(ROTA, params={"date_from": "2026-09-25", "date_to": "2026-09-24"}, headers=viewer_headers)

    assert resp.status_code == 422
    assert fake_records.janelas == []


def test_rota_sem_sgi_responde_503(client, viewer_headers):
    fake = FakeRecordsService(erro=ServiceUnavailableError("SGI indisponível"))
    app.dependency_overrides[get_commercial_overview_service] = lambda: fake
    try:
        resp = client.get(ROTA, params={"date_from": "2026-09-25", "date_to": "2026-09-25"}, headers=viewer_headers)
    finally:
        app.dependency_overrides.pop(get_commercial_overview_service, None)

    assert resp.status_code == 503
