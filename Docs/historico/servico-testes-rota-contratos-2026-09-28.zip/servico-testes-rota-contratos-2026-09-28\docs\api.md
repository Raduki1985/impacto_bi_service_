# API

## Base URL

```
/api/bi
```

Documentação interativa disponível em:
- Swagger UI: `GET /api/bi/docs`
- ReDoc: `GET /api/bi/redoc`
- OpenAPI JSON: `GET /api/bi/openapi.json`

---

## Health Check

### `GET /api/bi/health`

**Response `200 OK`:**
```json
{
  "status": "ok",
  "service": "impacto-bi-service",
  "version": "0.0.1",
  "time": "2026-03-30T12:00:00+00:00"
}
```

---

## Autenticação

> Não há cadastro público: usuário é criado por um administrador em
> `POST /api/bi/v1/users`.
>
> O 2FA está **desativado** — as rotas `/auth/2fa/*` permanecem no repositório
> comentadas em `app/api/v1/auth.py`, para reativação futura.

### `POST /api/bi/v1/auth/login`

**Body (`application/x-www-form-urlencoded`):**
```
username=user@example.com&password=senha123
```

**Response `200 OK`:**
```json
{
  "access_token": "eyJ...",
  "token_type": "bearer"
}
```

| Status | Descrição |
|---|---|
| `401` | E-mail desconhecido, sem senha definida ou senha errada |
| `403` | Conta inativa, ou usuário sem perfil de acesso |

---

### `POST /api/bi/v1/auth/logout`

Revoga a sessão do token atual. **Headers:** `Authorization: Bearer <access_token>`

**Response `200 OK`:** `{ "message": "Sessão encerrada." }`

---

### `POST /api/bi/v1/auth/set-password`

Define a senha no primeiro acesso, com o token do e-mail de cadastro, e ativa a conta.
Token invalidado após o uso.

Aceita **só** token do tipo `set-password`. O de recuperação vai em
`/auth/recover/reset`.

**Body (JSON):**
```json
{ "token": "eyJ...", "password": "nova-senha" }
```

**Response `200 OK`:**
```json
{ "message": "Senha definida com sucesso." }
```

| Status | Descrição |
|---|---|
| `401` | Token inválido, expirado, já utilizado ou do tipo errado |
| `422` | Senha fora da regra de composição. O token **não** é consumido |

> **Regra da senha**, igual nos dois endpoints: no mínimo 6 caracteres, com ao menos
> uma letra maiúscula, uma minúscula, um número e um caractere especial. Detalhes em
> [`authentication.md`](authentication.md#regra-da-senha).

---

### `POST /api/bi/v1/auth/recover`

Solicita reset de senha. Sempre retorna `200` para evitar enumeração de emails.

**Só conta `active` recebe o link.** `pending` não tem senha a recuperar (o caminho
dele é `POST /users/{id}/first-access`), e `inactive`/`blocked` não entram no portal.
A recusa é silenciosa: mesma frase, nenhum token gravado, nenhum e-mail enviado. Em
`ENV=local`, pedido recusado volta sem `reset_url`.

**Body (JSON):**
```json
{ "email": "user@example.com" }
```

**Response `200 OK`:**
```json
{
  "message": "Se o email existir, você receberá as instruções em breve.",
  "reset_url": "..."
}
```
> `reset_url` só aparece em `ENV=local`.

---

### `POST /api/bi/v1/auth/recover/reset`

Redefine a senha com o token de reset. Token é invalidado após uso.

Aceita **só** token do tipo `reset`. O de primeiro acesso vai em `/auth/set-password`.

A situação é conferida outra vez na gravação, porque o link vale dez minutos e nesse
intervalo a conta pode ser desativada.

**Body (JSON):**
```json
{ "token": "eyJ...", "password": "nova-senha" }
```

**Response `200 OK`:**
```json
{ "message": "Senha alterada com sucesso." }
```

| Status | Descrição |
|---|---|
| `401` | Token inválido, expirado, já utilizado ou do tipo errado |
| `403` | A conta deixou de estar `active` depois de o link ser emitido |
| `422` | Senha fora da regra de composição. O token **não** é consumido |

> **Regra da senha**, igual nos dois endpoints: no mínimo 6 caracteres, com ao menos
> uma letra maiúscula, uma minúscula, um número e um caractere especial. Detalhes em
> [`authentication.md`](authentication.md#regra-da-senha).

---

## Usuários

### `GET /api/bi/v1/users/me`

**Headers:** `Authorization: Bearer <access_token>`

**Response `200 OK`:**
```json
{
  "id": "uuid",
  "name": "Nome do Usuário",
  "email": "user@example.com",
  "status": "active",
  "is_active": true,
  "last_access": "2026-09-22T10:00:00Z",
  "profile_system_id": "uuid",
  "access_profile_id": "uuid",
  "profile_type": { "id": "uuid", "code": "analyst", "name": "Analista" },
  "access": { "id": "uuid", "name": "Analista OS" },
  "set_password_expire": null,
  "created_at": "2026-08-14T10:00:00Z",
  "updated_at": "2026-09-22T10:00:00Z"
}
```

> `set_password_expire` é a validade do convite de primeiro acesso, e **nunca** o
> token: o valor do link só existe no e-mail, e o que fica gravado é o hash dele.
> `null` significa que não há convite pendente, que é o caso de todo usuário que
> já definiu a senha. O portal usa esse campo para só oferecer o reenvio do
> convite depois que o link atual vence.

| Status | Descrição |
|---|---|
| `401` | Token ausente ou inválido |
| `403` | Conta inativa, ou usuário sem perfil de acesso |

Outras rotas do próprio usuário: `PUT /users/me` (só `name`),
`POST /users/me/password`, `GET`/`DELETE /users/me/sessions`,
`DELETE /users/me/sessions/{id}` e `POST /users/me/delete`.

---

## Administração de usuários

Todas as rotas abaixo exigem `Authorization: Bearer <access_token>` de um usuário cujo
tipo de perfil tenha `code = "adm"`. Sem isso, a resposta é `403` com a mensagem
`Permissão insuficiente`.

### `GET /api/bi/v1/users`

**Query params:**

| Param | Tipo | Default | Descrição |
|---|---|---|---|
| `page` | `int ≥ 1` | `1` | Página desejada |
| `size` | `1..100` | `10` | Registros por página |
| `search` | `str` | — | Filtra por nome ou e-mail (parcial, case-insensitive) |
| `profile_system_id` | `uuid` | — | Filtra por tipo de perfil |
| `access_profile_id` | `uuid` | — | Filtra por perfil de acesso |
| `status` | `pending \| active \| inactive \| blocked` | — | Filtra por situação |

Usuários com `deleted_at` preenchido nunca aparecem.

**Response `200 OK`:** envelope `Page[UserOut]`.
```json
{
  "pagination": {
    "total": 42,
    "size": 10,
    "current": 1,
    "pages": 5,
    "previous": false,
    "next": true
  },
  "list": [ { "id": "uuid", "email": "...", "status": "active", "...": "..." } ]
}
```

> Para obter apenas uma contagem, combine `size=1` com o filtro desejado e leia
> `pagination.total` — o agregado é calculado no banco.

### `POST /api/bi/v1/users`

**Body:**
```json
{
  "name": "Nome",
  "email": "novo@example.com",
  "profile_system_id": "uuid",
  "access_profile_id": "uuid",
  "password": "min. 6 caracteres"
}
```

**`status` é opcional, e omitido ele sai da senha**: sem `password` o usuário nasce
`pending` e recebe o e-mail de primeiro acesso; com `password` nasce `active`. É o
fluxo normal do portal, que cadastra sem senha.

`pending` é a situação de quem ainda não definiu senha. Ela vira `active` sozinha no
instante em que a senha passa a existir, por `POST /auth/set-password` (o link do
e-mail) ou por `PUT /users/{id}` com `password` (o administrador). Nenhuma outra
transição é automática.

Enviar `status` explicitamente recusa as duas combinações que o banco não guarda:
`pending` com senha (`ck_users_pending_without_password`) e qualquer situação
diferente de `pending` sem senha (`active` bate em
`ck_users_password_when_active`; `inactive` e `blocked` sem senha seriam contas sem
caminho de entrada).

**Response `201 Created`:** `UserOut`

| Status | Descrição |
|---|---|
| `409` | E-mail já cadastrado |
| `422` | Tipo de perfil ou perfil de acesso inexistente |
| `422` | Perfil de acesso pertence a outro tipo de perfil |
| `422` | `status: "pending"` com `password` |
| `422` | Qualquer `status` diferente de `pending` sem `password` |

### `GET /api/bi/v1/users/{id}`

**Response `200 OK`:** `UserOut` · `404` se não existir.

### `PUT /api/bi/v1/users/{id}`

Todos os campos são opcionais — só o que vier no corpo é alterado. `access_profile_id:
null` desvincula o perfil e bloqueia o login do usuário.

```json
{ "name": "Novo nome", "email": "novo@example.com", "profile_system_id": "uuid", "access_profile_id": "uuid", "status": "blocked", "password": "SenhaNova1!" }
```

**Response `200 OK`:** `UserOut`

| Status | Descrição |
|---|---|
| `400` | Tentativa de alterar o próprio perfil ou a própria situação |
| `404` | Usuário não encontrado |
| `409` | E-mail já pertence a outro usuário |
| `422` | Vínculos incoerentes, ativar usuário sem senha, ou senha fora da [regra da senha](authentication.md#regra-da-senha) |
| `422` | `status: "pending"`: não se devolve um usuário a pendente |
| `422` | Mudar a situação de um usuário `pending` sem mandar `password` na mesma chamada |

> **Usuário `pending` não é ativado nem desativado.** As duas ações pressupõem uma
> conta que já entra no portal, e pendente é justamente quem ainda não tem senha. O
> único jeito de sair de `pending` é ganhar uma senha, então `status` sozinho
> responde `422` e `password` (com ou sem `status: "active"`) resolve. É a mesma
> regra que desabilita o botão de ativar/desativar na tabela de Usuários do portal.

> Trocar `profile_system_id` sem trocar `access_profile_id` responde `422`: o perfil de
> acesso antigo pertence ao tipo antigo, e a FK composta não aceita a combinação. Mande
> os dois juntos.

> **`password` + `status: "active"` na mesma chamada** é como o portal resolve o
> primeiro acesso de quem nunca recebeu o e-mail: o administrador define a senha e ativa
> a conta de uma vez. Separar as duas gravações não funciona, porque ativar quem ainda
> não tem senha responde `422`.
>
> Definir a senha por aqui **queima os dois tokens pendentes** (`set_password` e
> `password_recovery`). O link que já estava na caixa de entrada deixa de valer, e
> ninguém o usa depois para trocar a senha recém-definida.

### `POST /api/bi/v1/users/{id}/first-access`

Gera um novo token de primeiro acesso (`users.set_password`) e reenvia o e-mail
`mails/set_password.html`, com link para `{FRONTEND_URL}/set-password?token=...`.

Não mexe em `password_recovery`: um pedido de recuperação em aberto sobrevive ao
reenvio.

**Só para usuário `pending`.** Qualquer outra situação responde `400`. A guarda existe
porque um convite emitido para conta que JÁ tem senha é um link capaz de trocá-la sem
conhecer a atual: seria um segundo caminho de troca de senha, contornando a
confirmação que `POST /users/{id}/password` cobra. Quem esqueceu a senha usa
`POST /auth/recover`; quem foi desativado é reativado por `PUT /users/{id}`.

**Response `200 OK`:** `{ "message": "E-mail de primeiro acesso enviado." }`
(`set_password_url` junto, em `ENV=local`.)

| Status | Descrição |
|---|---|
| `400` | Usuário não está `pending` (a frase diz em que situação ele está) |
| `404` | Usuário não encontrado |

### `DELETE /api/bi/v1/users/{id}`

Exclusão **lógica**: grava `deleted_at`/`deleted_by` e libera o e-mail para novo cadastro.

**Response `204 No Content`**

| Status | Descrição |
|---|---|
| `400` | Tentativa de excluir a própria conta |
| `404` | Usuário não encontrado |

---

## Tipos de perfil

`profile_types` são **três registros fixos** do sistema (`adm`, `analyst`, `executive`),
criados pelo seed.

> **O portal só lê.** Tipo de perfil não é criado, editado nem excluído pelo front — ele
> usa `GET /profile-types` apenas para preencher o seletor de perfil do cadastro de
> usuário. As rotas de escrita existem para manutenção pelo backend, se for realmente
> necessário, e são restritas a administrador.

| Rota | Descrição |
|---|---|
| `GET /api/bi/v1/profile-types` | `Page[ProfileTypeOut]`; query `page`, `size`, `search` (nome ou código) |
| `GET /api/bi/v1/profile-types/{id}` | `ProfileTypeOut` · `404` |
| `POST /api/bi/v1/profile-types` | `{ "code": "exec", "name": "Executivo" }` → `201` · `409` se o código existir |
| `PUT /api/bi/v1/profile-types/{id}` | `code` e `name` opcionais · `409` se o código já for de outro |
| `DELETE /api/bi/v1/profile-types/{id}` | `204` · `409` se houver perfil de acesso ou usuário vinculado |

Os três códigos do sistema são protegidos: `DELETE` e a troca de `code` respondem `409`
(`"é um dos três tipos de perfil fixos do sistema"`). O `name` continua editável, e
`code` é normalizado para minúsculas.

---

## Perfis de acesso

`access` é o perfil de acesso: o conjunto de menus que o usuário enxerga. Leitura
liberada a qualquer autenticado; escrita só para administradores.

### `GET /api/bi/v1/access`

**Query params:** `page`, `size`, `search` (nome ou descrição), `profile_type_id`.

**Response `200 OK`:** `Page[AccessOut]`.
```json
{
  "id": "uuid",
  "name": "Analista OS",
  "description": "Operação de campo",
  "access_profile_system_id": "uuid",
  "profile_type": { "id": "uuid", "code": "analyst", "name": "Analista" },
  "menus": [ { "id": "uuid", "name": "Visão Geral", "position": 1, "menu_id": "visao-geral", "icon": null, "profile_menu_id": null, "created_at": "...", "updated_at": "..." } ],
  "users_count": 3,
  "created_at": "...",
  "updated_at": "..."
}
```

`menus` sai ordenado por `position`. `users_count` conta só usuários não excluídos.

### `POST /api/bi/v1/access`

```json
{
  "name": "Analista OS",
  "description": "Operação de campo",
  "access_profile_system_id": "uuid",
  "menu_ids": ["uuid", "uuid"]
}
```

**Response `201 Created`:** `AccessOut`

| Status | Descrição |
|---|---|
| `422` | Tipo de perfil inexistente, ou algum id de `menu_ids` não existe |

### `GET /api/bi/v1/access/{id}` · `PUT` · `DELETE`

`PUT` aceita todos os campos opcionais. `menu_ids` ausente mantém os menus; `[]` limpa;
uma lista substitui a anterior inteira.

| Status | Descrição |
|---|---|
| `404` | Perfil de acesso não encontrado |
| `409` | `DELETE` com usuários vinculados |
| `409` | `PUT` trocando `access_profile_system_id` com usuários vinculados |
| `422` | Tipo de perfil ou menu inexistente |

---

## Menus

`profile_menu` é a árvore de menus do portal. Leitura liberada a qualquer autenticado;
escrita só para administradores.

### `GET /api/bi/v1/profile-menus`

**Query params:** `page`, `size`, `search` (nome ou `menu_id`), `parent_id`,
`roots_only`.

**Response `200 OK`:** `Page[ProfileMenuOut]`, ordenado por `position` e depois `name`.

### `GET /api/bi/v1/profile-menus/tree`

Árvore inteira já aninhada, para montar o menu do portal numa chamada.

```json
[
  {
    "id": "uuid",
    "name": "Operação",
    "position": 1,
    "menu_id": "operacao",
    "icon": "chart",
    "profile_menu_id": null,
    "created_at": "...",
    "updated_at": "...",
    "children": [ { "menu_id": "visao-geral", "children": [], "...": "..." } ]
  }
]
```

### `POST /api/bi/v1/profile-menus` · `GET`/`PUT`/`DELETE` `/{id}`

```json
{ "name": "Visão Geral", "position": 1, "menu_id": "visao-geral", "icon": "chart", "profile_menu_id": "uuid-do-pai" }
```

No `PUT`, `profile_menu_id: null` promove o menu a raiz. `DELETE` leva junto a subárvore
e os vínculos com perfis de acesso.

| Status | Descrição |
|---|---|
| `404` | Menu (ou o pai informado) não encontrado |
| `409` | `menu_id` já cadastrado |
| `422` | Menu apontado como pai de si mesmo, ou pai que é descendente dele |

---

## Vínculos perfil/menu

`access_profile_menu` liga perfil de acesso e menu (N:N, chave composta). É o mesmo
vínculo que `menu_ids` em `/access` escreve — aqui um de cada vez. Leitura liberada a
qualquer autenticado; escrita só para administradores.

| Rota | Descrição |
|---|---|
| `GET /api/bi/v1/access-profile-menus` | `Page[AccessProfileMenuOut]`; query `page`, `size`, `access_id`, `profile_menu_id` |
| `POST /api/bi/v1/access-profile-menus` | `{ "access_id": "uuid", "profile_menu_id": "uuid" }` → `201` |
| `GET /api/bi/v1/access-profile-menus/{access_id}/{profile_menu_id}` | `AccessProfileMenuOut` · `404` |
| `DELETE /api/bi/v1/access-profile-menus/{access_id}/{profile_menu_id}` | `204` · `404` |

| Status | Descrição |
|---|---|
| `409` | Vínculo já existe |
| `422` | Perfil de acesso ou menu inexistente |

---

## BI · Ordens de Serviço

Dados do SGI (o PostgreSQL do ERP) já normalizados para o portal. Exigem
`SGI_DATABASE_URL` configurada; sem ela, ou com o SGI fora do ar, respondem
`503 SERVICE_UNAVAILABLE` com a causa na mensagem. Contrato e regras completas em
[GUIA-BACKEND-VISAO-GERAL-OS-COMERCIAL.md](../GUIA-BACKEND-VISAO-GERAL-OS-COMERCIAL.md).

> **Autenticação desligada por ora** nos endpoints `/bi` (decisão do guia,
> seção 5.4: o login do portal ainda é mock). O JWT está comentado nos routers
> `app/api/v1/bi_os.py` e `bi_commercial.py`; para religar, descomente o
> `Depends(get_current_user)` de cada rota. O `/integrations/sgi/status`
> continua restrito a administradores.

### `GET /api/bi/v1/integrations/sgi/status`

Testa a conexão com o SGI (admin). Abre uma conexão do pool somente leitura e
roda um `SELECT` sem tocar em tabela alguma.

**Response `200 OK`:**
```json
{
  "connected": true,
  "database": "impacto-sgi-dev",
  "user": "bi_web",
  "server_version": "17.5",
  "server_time": "2026-08-27T15:10:00-03:00",
  "read_only": true
}
```

### `GET /api/bi/v1/bi/os/overview/records`

Um registro por ordem de serviço, na projeção que a Visão Geral de OS consome
(`OverviewOsRecord` no portal). Filtros dependentes, período anterior e gráficos
continuam sendo calculados no portal. Sem autenticação por ora.

**Query params** (opcionais, ISO `YYYY-MM-DD`, inclusivos, sobre a **data de
agendamento**): `date_from`, `date_to`. Sem parâmetros devolve a base inteira.

**Response `200 OK`:**
```json
{
  "generated_at": "2026-08-27T15:10:00-03:00",
  "source": {
    "updated_at": "2026-08-27",
    "coverage": { "min": "2026-04-06", "max": "2026-08-27" }
  },
  "filters": { "date_from": "2026-08-01", "date_to": "2026-08-21" },
  "count": 1248,
  "records": [
    {
      "id": "OS-2026-1",
      "date": "2026-08-01",
      "period": "Manhã",
      "technician_id": "5c1f0d2a-7b3e-4c9d-8e1f-0a2b3c4d5e6f",
      "team": "Infra",
      "service_type": "Instalação",
      "category": "fibra instalação",
      "city": "Atibaia",
      "status": "Concluída",
      "status_key": "completed",
      "resolution": "Instalação Realizada",
      "started_at": "2026-08-01T09:29:22-03:00",
      "finished_at": "2026-08-01T10:44:55-03:00",
      "travel_minutes": 29.5,
      "difficulty": "Média",
      "unproductive_reason": null
    }
  ],
  "catalog": {
    "technicians": [
      { "id": "5c1f0d2a-7b3e-4c9d-8e1f-0a2b3c4d5e6f", "name": "Emerson Wesley" }
    ],
    "statuses": [
      { "label": "Pendente", "order": 1 },
      { "label": "Agendada", "order": 2 },
      { "label": "Concluída", "order": 8 },
      { "label": "waiting_parts", "order": null }
    ],
    "service_types": [
      { "label": "Instalação", "order": 1 },
      { "label": "Instalação de Câmera", "order": 7 },
    ]
  },
  "quality": {
    "records_without_team": 0,
    "unclassified_technician_ids": [],
    "unmapped_status_keys": [],
    "unmapped_service_type_keys": [],
    "unknown_cities": []
  }
}
```

- `source.coverage` é a cobertura da **base inteira**, não do recorte: o portal
  usa para limitar os calendários e escolher o período padrão.
- `team` é nulo quando a OS não tem técnico **ou** quando o técnico ainda não
  está no catálogo de equipes do BI; o segundo caso aparece em `quality`.
- Chave de status/tipo do SGI sem de-para sai crua no registro e listada em
  `quality`; nunca vira um rótulo inventado.
- `status_key` é a chave de `service_orders.status` como está no SGI. É por ela
  que concluídas e improdutivas são **contadas**, no serviço e no portal
  (decisão de 08/09/2026): rótulo é apresentação e pode mudar, chave é
  identidade. O portal recusa a carga se o campo não vier.
- `city` é o nome de exibição do **cadastro do SGI** (`enum_types`, tipo
  `available_cities`), que é o que agrupa `ATIBAIA` e `Atibaia` numa única
  barra. Grafia fora do cadastro aparece como foi digitada, só com a caixa
  padronizada, e vai para `quality.unknown_cities` — não vira `Cidade não
  informada`, que é reservado para OS sem endereço.
- `resolution` não é traduzida: é o texto do cadastro com a caixa em Title
  Case pt-BR. Typo do SGI aparece como está.
- Execução em campo (21/09/2026), seis campos OPCIONAIS no contrato: a Visão
  Geral de OS e a página de Técnicos do portal os consomem, e um portal mais
  antigo segue funcionando sem eles. Todos nulos quando o SGI não tem o dado.
  - `period`: turno do agendamento (`Manhã`, `Tarde`), de
    `service_orders.period`; turno novo sai cru.
  - `started_at` e `finished_at`: início e fim do serviço no cliente, em
    `America/Sao_Paulo` com o fuso escrito. A duração da execução é a
    diferença entre os dois.
  - `travel_minutes`: deslocamento até o cliente, já em minutos
    (`arrived_at` menos `started_motion_at`, calculado no banco). Sai pronto
    porque os dois horários foram gravados 3h adiantados até 01/09/2026: a
    duração é correta na base inteira, o instante de cada marca não é.
    Negativo (chegada antes da partida) vira nulo, e não zero.
  - `difficulty`: `Fácil`, `Média` ou `Difícil`, de
    `service_orders.difficulty_level`.
  - `unproductive_reason`: motivo da visita improdutiva, encurtado para caber
    em legenda (`Cliente ausente`, `Local sem condição`...). Frase nova do
    aplicativo do técnico sai crua, e não vira "outros".
- `catalog.statuses` e `catalog.service_types` são o de-para como dado
  (decisão de 08/09/2026): todos os rótulos conhecidos, com a posição de
  exibição em `order` (a ordem operacional do gráfico de status e a ordem do
  filtro de tipo), e depois as chaves cruas presentes nos registros, com
  `order` nulo. O portal ordena filtros e gráfico por essa lista e não carrega
  catálogo próprio. Equipe não tem catálogo: é o cadastro do SGI e sai em
  ordem alfabética.
- O nome do técnico sai só em `catalog.technicians`; cliente, endereço,
  telefone, coordenadas e observações não saem.

**Erros:** `422 UNPROCESSABLE` quando `date_from` é posterior a `date_to`;
`503 SERVICE_UNAVAILABLE` quando o SGI está inacessível ou não configurado.

### `GET /api/bi/v1/bi/os/overview`

A Visão Geral de OS inteira, já agregada para um conjunto de filtros (opção B
do guia, seção 3.8). As regras são as mesmas do portal
(`resolveOverviewOsFilters` e `buildOverviewOsData`), aplicadas sobre os
mesmos registros de `/overview/records`. Sem autenticação por ora. Resposta
em cache por `BI_CACHE_TTL_SECONDS` por combinação de parâmetros.

**Query params** (todos opcionais): `date_from`, `date_to` (ISO, sobre a data de
agendamento; sem eles, do dia 1 do mês da última OS até ela), `team`,
`technician_id` (uuid em `auth.users`), `service_type`, `category`, `city`,
`status` (rótulos do portal; vazio ou ausente = Todos).

**Response `200 OK`** (recorte padrão 01/08 a 21/08/2026, valores da fato sanitizada):
```json
{
  "generated_at": "2026-08-27T15:10:00-03:00",
  "source": { "updated_at": "2026-08-27", "coverage": { "min": "2026-04-06", "max": "2026-08-21" } },
  "filters": { "date_from": "2026-08-01", "date_to": "2026-08-21", "team": null, "technician_id": null, "service_type": null, "category": null, "city": null, "status": null },
  "options": {
    "teams": ["Infra", "Terceirizada", "Câmeras", "Suporte Técnico"],
    "technicians": ["5c1f0d2a-7b3e-4c9d-8e1f-0a2b3c4d5e6f", "…"],
    "service_types": ["Instalação", "Infraestrutura", "Manutenção", "Mudança de Endereço", "Auditoria", "Instalação de Câmera"],
    "categories": ["ampliação de cto", "Auditória de Infraestrutura", "…"],
    "cities": ["Atibaia", "Bom Jesus dos Perdões", "…"],
    "statuses": ["Pendente de Aprovação", "Concluída", "Improdutiva", "Encerrada", "Expirada"]
  },
  "kpis": {
    "total": 1248, "completed": 959, "unproductive": 134,
    "completion_rate": 0.7684294871794872, "unproductive_rate": 0.10737179487179487,
    "previous": { "range": { "date_from": "2026-07-11", "date_to": "2026-07-31" }, "coverage": "complete", "total": 1110, "completed": 880, "unproductive": 136 },
    "deltas": {
      "total": { "rate": 0.12432, "available": true, "reason": null },
      "completed": { "rate": 0.08977, "available": true, "reason": null },
      "completion_rate": { "rate": -0.03073, "available": true, "reason": null },
      "unproductive_rate": { "rate": -0.12366, "available": true, "reason": null }
    }
  },
  "charts": {
    "daily": [ { "date": "2026-08-01", "total": 86, "completed": 67, "unproductive": 3 } ],
    "status": [ { "label": "Pendente de Aprovação", "count": 1 }, { "label": "Concluída", "count": 959 } ],
    "service_types": [ { "label": "Instalação", "count": 584, "categories": [ { "label": "fibra instalação", "count": 562 } ] } ],
    "cities": [ { "label": "Atibaia", "count": 938 } ],
    "categories_top": [ { "label": "fibra instalação", "count": 562 } ],
    "resolutions_top": [ { "label": "Instalação Realizada", "count": 647 } ]
  },
  "quality": { "records_without_team": 0, "unclassified_technician_ids": [], "unmapped_status_keys": [], "unmapped_service_type_keys": [], "unknown_cities": [] }
}
```

- `options` segue a cadeia Período → Equipe → Técnico → Tipo de OS → Categoria
  → Cidade → Status: cada campo lista só o que existe no contexto dos
  anteriores. Uma seleção fora das opções volta ao neutro (não é erro) e
  `filters` mostra o que foi aplicado.
- `options.technicians` traz **identificadores**; o nome de cada um está em
  `catalog.technicians`, que é o que o seletor exibe. Enquanto o catálogo vier
  vazio, o portal mantém o filtro de técnico desabilitado em vez de listar uuid.
- `kpis.previous` é a janela anterior de mesma duração terminando na véspera;
  `coverage = incomplete` quando ela alcança datas antes de `source.coverage.min`
  (totais nulos, deltas com `reason = previous_incomplete`); janela coberta sem
  OS gera `reason = no_previous_data`. Taxas são proporções de 0 a 1, sem
  arredondar.
- `charts.status` aplica todos os filtros **menos** status e sai na ordem do
  catálogo; rankings são decrescentes com desempate por ordem de código de
  caractere; `daily` só tem dias com OS; `cities` não tem corte; `categories_top`
  e `resolutions_top` são Top 10 (resoluções só de OS Concluídas).

**Erros:** `422 UNPROCESSABLE` para período invertido; `503` sem SGI.

---

## BI · Comercial

### `GET /api/bi/v1/bi/commercial/overview`

A Visão Geral Comercial já agregada (guia, seção 4.9). Sem autenticação por
ora. Resposta em cache por `BI_CACHE_TTL_SECONDS`.

**Query params** (opcionais): `start_date`, `end_date` (ISO, sobre a data de
evento do contrato; sem eles, do dia 1 do mês da última venda até ela),
`city_id` (`atibaia`, `piracaia`, `bom-jesus-dos-perdoes`, `joanopolis`,
`mairipora`, `terra-preta`), `team` (`todos` | `comercial` | `corporativo`,
pelo vínculo do vendedor em `teams`/`team_users`), `seller_id` (uuid de
`auth.users`, quem criou o contrato; só os de `catalog.sellers`; venda com
indicação não conta para ele), `sale_rule` (`activated`, o padrão: a venda
vale pela data de início e pela situação já ter passado da fila, mesmo que o
contrato tenha sido cancelado ou bloqueado depois; `started_at_active`, que exige
contrato ativo hoje, a régua do Vendas Ativas do SGI; ou `started_at`, só a
data de início).

**Response `200 OK`** (julho/2026 na base sintética do portal):
```json
{
  "generated_at": "2026-08-27T15:10:00-03:00",
  "source": { "updated_at": "2026-07-31", "period": { "start": "2026-01-01", "end": "2026-07-31" }, "months": ["2026-01", "2026-02", "2026-03", "2026-04", "2026-05", "2026-06", "2026-07"], "sale_rule": "started_at_active" },
  "filters": { "start_date": "2026-07-01", "end_date": "2026-07-31", "city_id": null, "team": "todos", "seller_id": null },
  "catalog": {
    "cities": [ { "id": "atibaia", "name": "Atibaia" }, { "id": "piracaia", "name": "Piracaia" } ],
    "sellers": [ { "id": "…", "name": "Ana Maria dos Santos" }, { "id": "…", "name": "Arthur Lopes" } ]
  },
  "metrics": {
    "total_contracts": 1132, "active_sales": 883, "active_sales_sold_earlier": 0, "activation_rate": 0.7800353356890459,
    "commercial_sales": 795, "corporate_sales": 88, "indicated_sales": 64, "seller_sales": 819,
    "monthly_revenue": 132111.7, "average_ticket": 149.62, "pipeline_sales": 162,
    "goal": 800.0, "super_goal": 880.0, "goal_achieved": 795, "super_goal_achieved": 883
  },
  "previous": { "range": { "start_date": "2026-06-01", "end_date": "2026-06-30" }, "active_sales": 894, "monthly_revenue": 131900.6, "goal_achieved": 820, "super_goal_achieved": 894, "new_customers": 693, "maturity": { "days": 90, "activated_from": "2026-03-03", "activated_to": "2026-04-01", "sales": 700, "blocked": 62, "cancelled": 7 } },
  "customers": { "new": 700, "expansion": 145, "returning": 38 },
  "maturity": { "days": 90, "activated_from": "2026-04-02", "activated_to": "2026-05-02", "sales": 640, "blocked": 48, "cancelled": 7 },
  "pipeline_stages": [ { "id": "pendente", "label": "Pendente", "count": 59 }, { "id": "assinada", "label": "Assinada", "count": 47 }, { "id": "agendada", "label": "Agendada", "count": 36 }, { "id": "aguardando-aprovacao", "label": "Em aprovação", "count": 20 } ],
  "cities": { "comparison_total": 883, "rows": [ { "id": "atibaia", "label": "Atibaia", "active_sales": 463, "monthly_value": 68933.7 } ] },
  "teams": { "comparison_total": 883, "rows": [ { "id": "comercial", "label": "Comercial", "active_sales": 795, "monthly_value": 107920.5 }, { "id": "corporativo", "label": "Corporativo", "active_sales": 88, "monthly_value": 24191.2 } ] },
  "origins": [ { "id": "vendedores", "label": "Vendedores", "active_sales": 819, "monthly_value": 123588.1 }, { "id": "indicacao", "label": "Indicação", "active_sales": 64, "monthly_value": 8523.6 } ],
  "top_plans": [ { "label": "600 MB", "active_sales": 160, "monthly_value": 20784.0 } ],
  "top_sellers": [ { "seller_id": "…", "seller_name": "Cristina Hernandez Materniano", "team": "comercial", "active_sales": 56, "monthly_revenue": 7574.4 } ],
  "top_sellers_total": 819,
  "monthly": [ { "month": "2026-07", "commercial_sales": 795, "corporate_sales": 88, "unassigned_sales": 0, "commercial_value": 107920.5, "corporate_value": 24191.2, "unassigned_value": 0.0 } ],
  "cohorts": [ { "month": "2026-07", "sold": 0, "activated_in_month": 0, "activated_later": 0, "awaiting": 0, "cancelled": 0, "cancelled_before": 0, "other": 0 } ],
  "quality": { "sales_without_team": 0, "sellers_without_team": [], "unmapped_team_names": [], "unmapped_status_keys": [], "unknown_cities": [] }
}
```

- Regra da venda (decisão de 17/09/2026, Mário, confirmada com o Caio, dev do
  SGI): `metrics.active_sales` conta a assinatura com `started_at` dentro do
  período cuja situação já passou da fila (não é pendente, assinada, agendada,
  em aprovação, reprovada nem expirada), independente do que aconteceu depois:
  cancelamento e bloqueio não tiram a venda do mês em que ativou. Cortesia
  liga o sinal sem ser venda e fica fora (18/09/2026). A regra
  anterior (`started_at_active`, 15/09) exigia contrato ativo hoje e encolhia
  os meses antigos (janeiro/2026 lia 582 quando 776 ligaram o sinal). O
  exemplo de resposta acima foi gerado com `started_at_active` (883); com
  `activated` a mesma base sintética dá 924, porque suspensa e bloqueios com
  data de início passam a contar.
  `metrics.active_sales_sold_earlier` diz quantas dessas ativadas foram
  vendidas antes de `start_date` (`contracted_at` anterior ao período), as
  herdadas: em setembro/2026 (1 a 17), 67 de 378. `total_contracts` e
  `pipeline_sales` usam a data de evento `COALESCE(started_at,
  contrato.signed_at, contracted_at, created_at)`, para posicionar no tempo
  também contratos ainda não ativados.
- Aguardando Ativação (decisão de 16/09/2026): `metrics.sold_contracts` conta
  os contratos pela DATA DA VENDA (`contracted_at`, dia em UTC, a régua do
  Total de Vendas do SGI) e `metrics.awaiting_activation` quantos deles não
  estão ativos hoje: `pendente`, `assinada`, `agendada`, `aguardando-aprovacao`
  ou `cancelada` sem `started_at`. `awaiting_stages` traz sempre as 4 etapas
  (`pendente`, que soma `aguardando-aprovacao`, `assinada`, `agendada`,
  `cancelada`), cada uma com `count`, `stalled`, `scheduled_visit` e
  `needs_reschedule`. `stalled` são
  os que passaram do prazo normal medido em produção: pendente com mais de 7
  dias da venda; assinada sem OS de instalação há mais de 4 dias; agendada
  sem OS aberta há mais de 4 dias do último evento de OS; nulo na cancelada.
  O portal deixou de ler `stalled` em 17/09/2026 (decisão do Mário: prazo
  não é assunto do card Aguardando Ativação), e o campo fica até a limpeza
  combinada. `scheduled_visit` e `needs_reschedule` (17/09/2026) são o que a
  leitura do card narra: quantos da etapa têm OS de instalação aberta, com
  visita marcada, e quantos tiveram OS improdutiva e estão sem nova OS
  aberta, ou seja, precisam reagendar; disjuntos, e fora da Agendada tendem
  a zero. Agosto/2026 em produção: 826 vendidos, 76 aguardando (47, 2, 24,
  3). `pipeline_stages` continua na resposta até a limpeza combinada com o
  portal.
- Regra do cliente novo (decisão de 15/09/2026): cliente é quem comprou, então
  `customers.new` conta as vendas ativadas do recorte cuja ativação é a
  PRIMEIRA daquele `customer_id` na base inteira, desde 2019, e não apenas na
  janela de `BASE_START`. `expansion` é a ativação de quem já tinha outro
  contrato vigente na data e `returning` a de quem foi cliente, cancelou e
  voltou. As três somam `metrics.active_sales`. O bloco é `null` quando a fonte
  não classifica o cliente, e aí `previous.new_customers` também é nulo. Linha
  em status que nunca ligou o sinal (pendente, assinada, agendada, em
  aprovação, reprovada, expirada) fica fora do histórico mesmo com
  `started_at` (18/09/2026): eram 36 clientes em 2026 lidos como ampliação ou
  retorno em vez de novos.
- Regra do vendedor (decisão de 14/09/2026): venda com `indication_code` é da
  indicação, não de quem a registrou. Com `seller_id`, o recorte é `created_by
  = seller_id` E sem indicação, em todos os cards e painéis. `top_sellers`
  ignora o filtro de vendedor (o portal destaca o selecionado) e conta só a
  venda própria; `top_sellers_total` é o total de vendas próprias desse
  conjunto, denominador da participação. `catalog.sellers` é quem criou
  contrato na base, em ordem de nome; `seller_id` fora dela responde `422`.
- `goal`/`super_goal` são proporcionais aos dias do período (800/880 por mês
  no consolidado; por cidade, 50 × vendedores internos alocados; com
  `seller_id`, a meta individual de 50/55 do vendedor interno do roster, casado
  pelo nome de `auth.users`) e nulos sem meta para o recorte (Corporativo,
  cidade sem vendedor interno, vendedor fora do roster ou de outra cidade).
  `previous.range` segue a natureza do recorte desde 25/09/2026, a régua da
  Visão Geral de OS: um dia compara com o mesmo dia da semana anterior; do
  dia 1 até um dia do mesmo mês, com o mês anterior até o mesmo dia (limitado
  ao fim dele), e o mês inteiro com o mês anterior inteiro; de segunda-feira
  até um dia da mesma semana, com os mesmos dias da semana anterior; qualquer
  outro recorte, com a mesma quantidade de dias logo antes. `previous` é nulo
  quando a janela anterior começa antes de `source.period.start`.
- `cities` ignora o filtro de cidade; `teams` e `origins` ignoram o filtro de
  time (o portal só destaca a seleção). Vendedor sem equipe reconhecida em
  `team_users` aparece como `sem-time` no painel e não conta como Comercial.
  Endereço fora das 6 cidades aparece como `outras`; sem endereço, `nao-informada`.
- `monthly[]` traz três parcelas por mês (17/09/2026, decisão do Mário):
  `commercial_*`, `corporate_*` e `unassigned_*`, esta última a venda de
  vendedor sem equipe ou sem vendedor registrado (`created_by` nulo, caso de
  toda venda anterior a junho/2026). As três somam as vendas ativadas do mês;
  sem a terceira, o portal zerava janeiro a maio. Com `team` aplicado,
  `unassigned_*` é sempre zero. "Sem time" é agrupamento provisório: o que
  fazer com essa informação é decisão futura do Mário.
- Safra por mês vendido (decisão de 18/09/2026, Mário): `cohorts[]` traz, para
  cada mês da base, quanto foi VENDIDO (`contracted_at`, dia em UTC) e o que
  virou até hoje: `activated_in_month` (sinal ligado no mesmo mês, inclusive a
  rara venda registrada depois do sinal), `activated_later` (mês seguinte ou
  depois), `awaiting` (pendente, assinada, agendada, em aprovação),
  `cancelled` (cancelada hoje, antes ou depois do sinal) e `other`
  (reprovada, expirada, cortesia: zero na base hoje). As cinco somam `sold`.
  Cidade, time, vendedor e tipo de cliente valem; o período não. Desde
  28/09/2026 (decisão do Mário) a cancelada é uma parcela só, que antes era
  `cancelled_before` (o nome antigo continua na resposta com o mesmo número
  até o portal novo ser publicado, porque o portal publicado exige que as
  parcelas somem o vendido): até jul/2026 o SGI gravava a data de ativação já na
  venda e os dois casos não se separam; as duas parcelas de ativadas contam
  só quem não está cancelado hoje. Produção em 28/09/2026: janeiro 837
  vendidas, 611 ativaram no mês e seguem, 113 depois, 113 canceladas;
  agosto 826, 683, 65, 71 aguardam, 5 canceladas. A base sintética do
  exemplo acima não tem data de venda, por isso o ponto sai zerado.
- Bloqueio ou cancelamento em 90 dias (decisão de 28/09/2026, Mário):
  `maturity` julga as vendas ativadas (regra `activated`, qualquer que seja o
  `sale_rule`) cujo 90º dia depois do sinal cai no período: setembro julga as
  ativadas de junho (`activated_from` e `activated_to`). `blocked` é quem
  estava em bloqueio financeiro no 90º dia, pelo último evento de bloqueio ou
  desbloqueio do histórico entre o sinal e esse dia; `cancelled` é quem
  cancelou até ele. Os dois não se sobrepõem e cabem em `sales`. Fica fora a
  cancelada que não chegou a ser cliente: baixa prematura, instalação não
  concluída ou sem motivo (medido: das 31 baixas prematuras desde jun/2026, 2
  tinham instalação concluída e 1 fatura paga). Cidade, time, vendedor e tipo
  de cliente valem. Nulo quando a janela de ativação começa antes de
  `BASE_START` (o primeiro período medido começa em 01/04/2026) e enquanto a
  leitura do histórico de bloqueio não existe: ela é uma consulta à parte,
  feita em segundo plano, porque a frio levou de 6 a 162 s conforme o
  caminho. A página usa a última leitura pronta e nunca espera por ela; uma
  leitura nova começa quando a página é aberta e a última tem mais de 30
  minutos. Leitura com mais de 6 horas não vale, e depois de uma falha a
  próxima tentativa espera 5 minutos. Logo depois de o serviço subir, ou
  depois de horas sem acesso, o bloco sai nulo até a leitura terminar. A data
  do cancelamento é lida em UTC, como a da venda: o SGI a grava como dia à
  meia-noite. `previous.maturity`
  é o mesmo bloco no período anterior. Produção em 28/09/2026: 01 a 27/09,
  594 vendas, 71 bloqueadas e 5 canceladas (12,8%); 01 a 27/08, 607, 61 e 10
  (11,7%).
- Valores em reais são decimais com 2 casas; participações, ticket por time e
  percentual do velocímetro continuam sendo calculados no portal.

**Erros:** `422 VALIDATION_ERROR` para `team`/`sale_rule` fora da lista;
`422 UNPROCESSABLE` para `city_id` desconhecido ou período invertido; `503` sem SGI.

### `GET /api/bi/v1/bi/commercial/overview/records`

Um registro por contrato VENDIDO ou ATIVADO na janela, na projeção que a faixa
Hoje ao vivo da Visão Geral Comercial consome (25/09/2026). O portal pede o
dia de hoje a cada minuto, separa as vendas do dia por situação e aponta as
ativações do dia que vieram de vendas anteriores; cidade, time, vendedor e
tipo de cliente são aplicados no portal sobre os campos do registro. No
mesmo dia a rota passou a servir também à janela de contratos da página (os
painéis Safra de vendas por mês e Evolução mensal pedem o mês clicado) e à
planilha de todos os contratos do período (o período da página inteiro).
Sem autenticação por ora. Resposta em cache por `BI_CACHE_TTL_SECONDS`.

**Query params** (opcionais, ISO `YYYY-MM-DD`, inclusivos): `date_from`
(vazio: 01/01/2026, início da base comercial) e `date_to` (vazio: hoje). Entra
o contrato cujo dia da venda (`contracted_at`, em UTC) OU dia do sinal ligado
(`started_at`, em UTC) cai na janela: as mesmas duas réguas da página.
`include_queue` (`false` por padrão): com `true`, entra também a ESTEIRA,
todo contrato vendido desde 01/01/2026 que ainda está na fila (pendente,
assinada, agendada, em aprovação), sem corte de idade (decisão do Mário em
25/09/2026: a venda esquecida há meses tem de aparecer). O contrato parado de
antes da base comercial, do sistema anterior ao SGI, fica fora.

**Response `200 OK`:**
```json
{
  "generated_at": "2026-09-25T10:12:00-03:00",
  "source": { "updated_at": "2026-09-25", "sale_rule": "activated" },
  "filters": { "date_from": "2026-09-25", "date_to": "2026-09-25", "include_queue": true, "queue_from": "2026-01-01" },
  "count": 2,
  "records": [
    {
      "id": "00012345",
      "status": "agendada", "status_key": "scheduled",
      "stage": "agendada", "activated": false,
      "contracted_on": "2026-09-25", "signed_on": "2026-09-25", "created_at": "2026-09-25T09:41:12-03:00",
      "started_on": null, "started_at": null,
      "monthly_value": 129.9, "plan_name": "res_600mb solo",
      "city_id": "atibaia", "city_label": "Atibaia",
      "seller_id": "…", "seller_name": "Ana Maria dos Santos",
      "team": "comercial", "teams": ["comercial"], "indicated": false,
      "customer_kind": null, "person_type": "pf",
      "has_open_order": true, "has_installation_order": true, "has_unproductive_order": false,
      "next_visit_on": "2026-09-26", "last_visit_on": "2026-09-26", "last_order_status": "scheduled",
      "signal_evidence": [], "replaced_by": null
    },
    {
      "id": "00012340",
      "status": "ativa", "status_key": "active",
      "stage": null, "activated": true,
      "contracted_on": "2026-09-24", "signed_on": "2026-09-24", "created_at": "2026-09-24T15:03:40-03:00",
      "started_on": "2026-09-25", "started_at": "2026-09-25T10:05:31-03:00",
      "monthly_value": 99.9, "plan_name": "res_300mb solo",
      "city_id": "piracaia", "city_label": "Piracaia",
      "seller_id": "…", "seller_name": "Maisa Fernanda Moreira dos Santos",
      "team": "comercial", "teams": ["comercial"], "indicated": false,
      "customer_kind": "novo", "person_type": "pf",
      "has_open_order": false, "has_installation_order": true, "has_unproductive_order": false,
      "next_visit_on": null, "last_visit_on": "2026-09-25", "last_order_status": "completed",
      "signal_evidence": [], "replaced_by": null
    }
  ],
  "quality": { "sales_without_team": 0, "sellers_without_team": [], "unmapped_team_names": [], "unmapped_status_keys": [], "unknown_cities": [] }
}
```

- A situação sai PRONTA, pelas mesmas contas dos cards: `stage` é a etapa do
  Aguardando Ativação (`pendente`, `assinada`, `agendada`, ou `cancelada` para
  quem cancelou sem nunca ligar o sinal; nulo quando não aguarda) e `activated`
  é a regra da venda ativada (`sale_rule=activated`: sinal ligado e situação já
  fora da fila, sem ser cortesia; cancelamento ou bloqueio depois não a tira).
  Um contrato com `stage` nulo e `activated` falso é reprovada, expirada ou
  cortesia.
- `created_at` e `started_at` são instantes em `America/Sao_Paulo` com o fuso
  escrito: a hora da venda e a hora do sinal, para a lista do dia. Os DIAS que
  contam (`contracted_on`, `started_on`) seguem a régua da página, em UTC; uma
  ativação depois das 21h cai no dia seguinte, como no relatório do SGI.
  Antes de setembro/2026 o SGI gravava o sinal só com a data.
- `next_visit_on` é a menor data agendada entre as ordens de serviço abertas
  do contrato; `last_visit_on` e `last_order_status` são a data agendada e a
  chave do status da ÚLTIMA ordem, aberta ou não. São os relógios dos alertas
  da faixa (regra do Mário, 25/09/2026, sem contar domingo): pendente 2 dias
  após a venda sem assinatura; assinada 2 dias após `signed_on` sem ordem;
  agendada 1 dia após `last_visit_on` sem sinal e sem outra visita marcada.
  O portal aplica os prazos; o serviço só manda as datas.
- `signal_evidence` e `replaced_by` dizem se uma venda da esteira já se
  resolveu fora do fluxo do SGI (decisão do Mário em 28/09/2026); fora da fila
  saem vazios. `signal_evidence` lista as provas de sinal ligado NESTE
  contrato, nesta ordem: `installation_completed` (OS de instalação
  concluída), `remote_activation` (OS da categoria Ativação Remota concluída
  ou encerrada), `equipment_online` (equipamento do contrato online com serial
  que não aparece em outro contrato do mesmo cliente, porque o SGI copia o do
  contrato antigo) e `invoice_issued` (fatura emitida). `replaced_by` é o
  código do contrato do MESMO cliente, no mesmo endereço (o mesmo cadastro de
  endereço, ou CEP e número iguais), vendido no mesmo dia ou depois (dia da
  venda em UTC), que ligou o sinal e continua na base (ativo, bloqueado ou
  suspenso): a venda foi refeita nele. Em outro endereço pode ser mudança ou
  segundo ponto, e não conta. Havendo mais de um, vai o de venda mais
  antiga; sem código no SGI, o id interno. Com qualquer dos dois, o portal não
  conta o contrato como fora do prazo e escreve o motivo no Detalhe; ele
  continua na caixa, que espelha a situação do SGI. Medido no dia: dos 261
  fora do prazo, 17 tinham prova de sinal e 31 eram vendas refeitas, 8
  delas em outro endereço (essas continuam contando).
- `teams` traz todos os times do vendedor, e é por ele que o portal aplica o
  filtro de time; `team` é o principal, para agrupar. Com `indicated`, a venda
  é da indicação e não conta para o vendedor no filtro por vendedor.
- Do cliente saem só `customer_kind` e `person_type`; nome, documento e
  contato nunca. O vendedor sai com id e nome, como em `catalog.sellers`.

**Erros:** `401` sem token; `403` sem o menu `commercial/overview` no perfil de
acesso (o mesmo da rota agregada); `422 UNPROCESSABLE` para janela invertida;
`503` sem SGI.

---

## Formato de Erro Padrão

```json
{
  "error": {
    "code": "NOT_FOUND",
    "message": "Resource not found",
    "request_id": "550e8400-e29b-41d4-a716-446655440000"
  }
}
```

| HTTP | Code | Quando ocorre |
|---|---|---|
| `400` | `HTTP_ERROR` | Requisição inválida |
| `401` | `UNAUTHORIZED` | Token ausente ou inválido |
| `403` | `FORBIDDEN` | Sem permissão |
| `404` | `NOT_FOUND` | Recurso não encontrado |
| `409` | `CONFLICT` | Conflito (ex: email duplicado) |
| `422` | `VALIDATION_ERROR` | Falha na validação dos campos |
| `422` | `UNPROCESSABLE` | Entrada válida mas sem sentido para a regra (período invertido, cidade desconhecida) |
| `429` | — | Rate limit excedido |
| `500` | `INTERNAL_ERROR` | Erro interno inesperado |
