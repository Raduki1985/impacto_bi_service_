import type { Theme } from '../../../contexts/PreferencesContextCore'
import { formatPercent } from '../../../lib/formatters'

/**
 * Constantes e helpers do card executivo comercial.
 *
 * Ficam separados do componente pelo mesmo motivo de `PreferencesContextCore`:
 * um arquivo que exporta componente e valor ao mesmo tempo quebra o fast
 * refresh. Aqui também dá para testar os helpers sem renderizar nada.
 */

/** Cor de identidade do indicador, usada na caixa do ícone e no visual. */
export type CommercialCardTone = 'green' | 'blue' | 'indigo' | 'violet' | 'amber' | 'cyan'

export const commercialCardColors: Record<CommercialCardTone, string> = {
  green: '#00a862',
  blue: '#2f7de1',
  indigo: '#4263eb',
  violet: '#8b5cf6',
  amber: '#d97706',
  cyan: '#0f9689',
}

export type CommercialCardVariant = 'spark' | 'gauge' | 'pipeline'

/**
 * Interpretação de negócio da comparação, sempre decidida por quem consome.
 *
 * O card NÃO deduz semântica a partir do sinal do número. No portal existem
 * indicadores em que crescer é piorar, como cancelamentos, atrasos e
 * inadimplência: se a comparação decidisse sozinha, um aumento de cancelamento
 * apareceria em verde. Quem conhece a regra do indicador informa o tom.
 */
export type CommercialDeltaTone = 'favoravel' | 'desfavoravel' | 'neutro' | 'indisponivel'

/** Comparação já interpretada pelo consumidor, pronta para o card. */
export type CommercialCardDelta = {
  /** Texto visível, abreviado com `vs. p.p.`. */
  readonly label: string
  /** Leitura completa, com `versus período anterior` por extenso. */
  readonly accessibleLabel: string
  readonly tone: CommercialDeltaTone
}

/**
 * Cor do texto comparativo, por tom e por tema.
 *
 * A comparação é só texto: não existe fundo, borda, contorno nem pílula. Por
 * isso a cor precisa ser sólida e alcançar contraste sozinha, e o mesmo verde
 * não serve para superfície clara e para superfície escura.
 *
 * A informação nunca depende apenas da cor: o texto traz o triângulo de direção
 * e o conteúdo acessível traz a interpretação por extenso.
 */
export const commercialDeltaColors: Record<Theme, Record<CommercialDeltaTone, string>> = {
  light: {
    favoravel: '#00844d',
    desfavoravel: '#b51d38',
    neutro: '#475467',
    indisponivel: '#5b6779',
  },
  dark: {
    favoravel: '#34d399',
    desfavoravel: '#ff8fa3',
    neutro: '#cdd5df',
    indisponivel: '#aeb9c7',
  },
}

/**
 * Tipografia comum dos textos semânticos exibidos na frente dos cards.
 *
 * A comparação com o período anterior e a distância até Meta/Supermeta são a
 * mesma categoria de informação: uma frase curta, colorida pelo tom do
 * resultado. Por isso as duas herdam a família do portal e compartilham corpo,
 * peso E entrelinha daqui. O line-height entrou no token justamente porque
 * ficar em cada posição era o que deixava os dois textos parecidos, mas não
 * iguais.
 *
 * A entrelinha é 1,25, e não `leading-none`, por causa da posição que quebra: a
 * distância até a meta pode ocupar duas linhas no card estreito, e linhas
 * encostadas ficariam ilegíveis. Na comparação, que é sempre uma linha truncada
 * dentro de uma faixa de altura fixa e centralizada, o valor não muda nada na
 * tela.
 */
export const commercialSemanticTextClass = 'text-[11px] font-semibold leading-[1.25]'

/**
 * Leitura do tom, anexada ao texto acessível.
 *
 * Garante que a interpretação não dependa somente da cor: quem usa leitor de
 * tela recebe a mesma informação que a paleta transmite visualmente.
 */
export const commercialDeltaReading: Record<CommercialDeltaTone, string> = {
  favoravel: 'Resultado favorável.',
  desfavoravel: 'Resultado desfavorável.',
  neutro: 'Resultado neutro.',
  indisponivel: 'Comparação indisponível.',
}

/** Abreviação visual do período anterior, comum a todos os cards comerciais. */
export const PREVIOUS_PERIOD_SHORT = 'vs. p.p.'

/** Expressão completa, sempre disponível para tecnologia assistiva. */
export const PREVIOUS_PERIOD_LONG = 'versus período anterior'

/**
 * Comparação percentual com o período anterior.
 *
 * Vale para os indicadores em que crescer é favorável, que são todos os deste
 * bloco. Quem tiver indicador de sentido invertido, como cancelamento ou
 * atraso, monta o próprio `CommercialCardDelta`: nem esta função nem o card
 * deduzem semântica a partir do sinal do número.
 */
export function buildCommercialDelta(rate: number | null, subject: string): CommercialCardDelta {
  if (rate === null) {
    return {
      label: 'Sem período anterior',
      accessibleLabel: `${subject}: não há período anterior comparável`,
      tone: 'indisponivel',
    }
  }
  if (rate > 0) {
    return {
      label: `▲ ${formatPercent(rate)} ${PREVIOUS_PERIOD_SHORT}`,
      accessibleLabel: `${subject} cresceu ${formatPercent(rate)} ${PREVIOUS_PERIOD_LONG}`,
      tone: 'favoravel',
    }
  }
  if (rate < 0) {
    return {
      label: `▼ ${formatPercent(Math.abs(rate))} ${PREVIOUS_PERIOD_SHORT}`,
      accessibleLabel: `${subject} recuou ${formatPercent(Math.abs(rate))} ${PREVIOUS_PERIOD_LONG}`,
      tone: 'desfavoravel',
    }
  }
  return {
    label: `Estável ${PREVIOUS_PERIOD_SHORT}`,
    accessibleLabel: `${subject} ficou estável ${PREVIOUS_PERIOD_LONG}`,
    tone: 'neutro',
  }
}
