import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react'
import {
  CircleCheckBig,
  ClipboardList,
  Handshake,
  Hourglass,
  TrendingDown,
  UserMinus,
  UsersRound,
  type LucideIcon,
} from 'lucide-react'

import { Chart } from '../../../components/charts/Chart'
import type { Theme } from '../../../contexts/PreferencesContextCore'
import { usePreferences } from '../../../contexts/usePreferences'
import { formatIsoAsBrDate } from '../../../data/commercialCalendar'
import type { CommercialDataset } from '../../../data/commercialTypes'
import { getCommercialDataset, peekCommercialDataset } from '../../../data/mockCommercialData'
import { formatNumber, formatPercent } from '../../../lib/formatters'
import { commercialCardColors, type CommercialCardTone } from '../components/commercialCardModel'
import { CommercialExecutiveCard, CommercialSparkline } from '../components/CommercialExecutiveCard'
import { SalesPeriodCycleSituation } from './SalesPeriodCycleSituation'
import { SalesPeriodCycleTable } from './SalesPeriodCycleTable'
import { SalesPeriodFilters } from './SalesPeriodFilters'
import { makeSalesPeriodDailyOptions } from './salesPeriodChartOptions'
import {
  buildSalesPeriodCycleSnapshot,
  initialSalesPeriodCycleFilters,
  type SalesPeriodCycleDailyPoint,
  type SalesPeriodCycleFilters as CycleFilters,
  type SalesPeriodCycleMetrics,
  type SalesPeriodCycleOriginSlice,
  type SalesPeriodCycleSnapshot,
} from './salesPeriodCycleModel'

const currency = new Intl.NumberFormat('pt-BR', {
  style: 'currency',
  currency: 'BRL',
  minimumFractionDigits: 2,
})

const panelClass =
  'min-w-0 rounded-xl border border-[var(--border)] bg-[var(--surface)] px-[18px] py-4'

/**
 * Grade dos cinco cards executivos.
 *
 * É exatamente a mesma de Comercial > Visão Geral, que também publica cinco
 * cards: uma coluna no celular, duas em `sm`, três em `lg` e os cinco em uma
 * linha a partir de `xl`, que cobre 1440 px. Repetir a grade do template
 * consolidado é o ponto: uma variação própria daqui faria os dois blocos
 * parecerem componentes diferentes.
 *
 * O carregamento usa a mesma grade para o layout não pular quando os valores
 * reais entram.
 */
const CARD_GRID_CLASS = 'grid min-w-0 grid-cols-1 gap-3.5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5'

/**
 * Comercial > Vendas por Período.
 *
 * A página responde uma pergunta só: das vendas INICIADAS no período, em qual
 * situação elas estão agora, quantas chegaram à ativação e onde foram perdidas.
 *
 * Três decisões sustentam o bloco:
 *
 * 1. A Data de Início decide sozinha o período. Ativação e cancelamento
 *    posteriores nunca transferem a venda para outro recorte, e nenhum gráfico
 *    posiciona registro pela data de ativação ou de cancelamento.
 * 2. Existe uma única fonte analítica, `buildSalesPeriodCycleSnapshot`. Filtros,
 *    cards, evolução, origem, Situação das vendas e tabela leem o MESMO conjunto
 *    filtrado, então nenhum número da tela pertence a um universo diferente do
 *    outro.
 * 3. Não há comparação com o período anterior. Períodos diferentes têm tempos de
 *    acompanhamento diferentes, e comparar coortes de maturidade distinta
 *    produziria uma leitura falsa de melhora ou piora. Por isso os cards são
 *    montados sem a faixa de comparação, que o componente compartilhado já trata
 *    como opcional.
 *
 * A apresentação é a do template consolidado do Comercial: cards executivos,
 * painéis de evolução e de origem, painel analítico e tabela. O que mudou frente
 * ao bloco anterior é o conteúdo, e não a linguagem visual.
 *
 * Todos os registros são sintéticos.
 */
export function SalesPeriod() {
  const { theme } = usePreferences()
  const [dataset, setDataset] = useState<CommercialDataset | null>(() => peekCommercialDataset())
  const [error, setError] = useState<string | null>(null)
  const [filters, setFilters] = useState<CycleFilters>(initialSalesPeriodCycleFilters)
  const [page, setPage] = useState(0)

  useEffect(() => {
    if (dataset !== null || error !== null) return

    let cancelled = false
    const timer = window.setTimeout(() => {
      try {
        const built = getCommercialDataset()
        if (!cancelled) setDataset(built)
      } catch (cause) {
        if (!cancelled) {
          setError(
            cause instanceof Error
              ? cause.message
              : 'Falha desconhecida ao montar a base comercial mockada.',
          )
        }
      }
    }, 0)

    return () => {
      cancelled = true
      window.clearTimeout(timer)
    }
  }, [dataset, error])

  const cycle = useMemo(
    () => (dataset === null ? null : buildCycle(dataset, filters)),
    [dataset, filters],
  )

  // Trocar qualquer filtro devolve a tabela à primeira página: manter a página
  // anterior mostraria um trecho arbitrário de um conjunto que acabou de mudar.
  const handleFiltersChange = (next: CycleFilters) => {
    setFilters(next)
    setPage(0)
  }

  if (error !== null) return <ErrorPanel message={error} />
  if (dataset === null || cycle === null) return <LoadingPanel />
  // Erro de integridade do ciclo não vira recorte vazio: uma venda que perdeu o
  // fato comercial faria todos os indicadores fecharem sobre um total menor sem
  // nada indicar isso na tela.
  if (!cycle.ok) return <ErrorPanel message={cycle.message} />

  const { snapshot } = cycle
  const { metrics } = snapshot

  return (
    <div className="flex flex-col gap-4">
      <SalesPeriodFilters
        cities={dataset.cities}
        filters={filters}
        onChange={handleFiltersChange}
        options={snapshot.options}
        referenceDate={dataset.referenceDate}
      />

      <CycleCards snapshot={snapshot} theme={theme} />

      <div className="grid min-w-0 grid-cols-1 gap-3.5 xl:grid-cols-[1.55fr_1fr]">
        <Panel
          subtitle={`Quantidade de vendas e valor mensal contratado agrupados pela Data de Início, de ${snapshot.periodLabel}.`}
          title="Evolução das vendas iniciadas"
        >
          {metrics.startedSales === 0 ? (
            <EmptyPanel>
              Nenhuma venda iniciada corresponde aos filtros selecionados.
            </EmptyPanel>
          ) : (
            <>
              <Chart height={290} minWidth={600} option={makeSalesPeriodDailyOptions(snapshot.daily)} />
              <DailyChartTable daily={snapshot.daily} periodLabel={snapshot.periodLabel} />
            </>
          )}
        </Panel>

        <OriginsPanel origins={snapshot.origins} total={metrics.startedSales} />
      </div>

      <SalesPeriodCycleSituation metrics={metrics} theme={theme} />

      <SalesPeriodCycleTable
        onPageChange={setPage}
        page={page}
        records={snapshot.records}
        theme={theme}
      />

      <p className="text-[11px] leading-relaxed text-[var(--text-secondary)]">
        Esboço com dados sintéticos para validar a leitura do ciclo comercial. Os registros e também
        a Data de Início, as datas de ativação e de cancelamento, os resultados comerciais, os
        motivos de perda, as modalidades para ativação e as Ordens de Serviço resumidas foram
        criados apenas para exercitar esta visualização: nenhum percentual desta página representa a
        operação real da Impacto Telecom. Não existe integração com o Sales ou com o SGI neste
        protótipo, e a integração futura passará a usar a Data de Início oficial da venda no lugar
        do valor sintético. Cobrança da instalação, execução da instalação e resultado comercial são
        conceitos diferentes: instalação isenta não é ausência de instalação, ativação remota não é
        instalação física, e uma execução concluída não garante que a venda continue ativa. Base
        mockada apurada em {formatIsoAsBrDate(dataset.referenceDate)}.
      </p>
    </div>
  )
}

/* -------------------------------------------------------------------------- */
/* Fonte analítica                                                            */
/* -------------------------------------------------------------------------- */

type CycleResult =
  | { readonly ok: true; readonly snapshot: SalesPeriodCycleSnapshot }
  | { readonly ok: false; readonly message: string }

/**
 * Recorte do ciclo, com o erro de integridade preservado.
 *
 * O modelo interrompe de propósito quando uma venda perde o fato comercial
 * correspondente. Aqui esse erro é capturado para virar o estado de erro da
 * página, e nunca uma lista vazia: esconder a falha faria a tela parecer um
 * período sem vendas.
 */
function buildCycle(dataset: CommercialDataset, filters: CycleFilters): CycleResult {
  try {
    return { ok: true, snapshot: buildSalesPeriodCycleSnapshot(dataset, filters) }
  } catch (cause) {
    return {
      ok: false,
      message:
        cause instanceof Error
          ? cause.message
          : 'Falha desconhecida ao montar o ciclo comercial das vendas iniciadas.',
    }
  }
}

/* -------------------------------------------------------------------------- */
/* Cards executivos                                                           */
/* -------------------------------------------------------------------------- */

type CycleCard = {
  readonly icon: LucideIcon
  readonly label: string
  readonly value: string
  readonly points: readonly number[]
  readonly tone: CommercialCardTone
  readonly readingTitle: string
  readonly readingText: string
  /** Bloco `OBSERVAR` da leitura gerencial: o que o minigráfico do card mostra. */
  readonly observe: string
}

/**
 * O que cada minigráfico mostra, escrito uma vez.
 *
 * A série distribui as vendas pela Data de Início dentro do período: a venda de
 * 03/07 que só ativou no dia 20 continua contada no dia 03/07. A frase cita a
 * Data de Início e nega a data do desfecho, em vez de descrever a série como
 * tendência, que é um movimento que ela não mede. E é curta de propósito: a
 * versão longa anterior ainda cortava a leitura gerencial em 1280 px.
 */
const DISTRIBUTION_NOTE = 'Minigráfico por Data de Início no período, não pela data do desfecho.'

/**
 * Os cinco indicadores aprovados, no card executivo consolidado.
 *
 * É o mesmo `CommercialExecutiveCard` da Visão Geral, e não classes parecidas:
 * superfície, tipografia, altura, ícone, minigráfico, leitura gerencial e
 * interação vêm todos do componente compartilhado. O estado "um card aberto por
 * vez" continua aqui, porque é da coleção desta página.
 *
 * A frente do card é deliberadamente curta: título, valor, ícone e minigráfico.
 * Nenhum card recebe `delta`, porque não existe comparação com o período
 * anterior neste bloco, e nada ocupa o lugar dela. Os denominadores e as taxas
 * continuam existindo, mas na leitura gerencial, onde cabem por extenso: na
 * frente do card eles eram cortados antes de terminarem a frase.
 *
 * Os denominadores são diferentes de propósito: fluxo e perdas usam as vendas
 * iniciadas, enquanto o churn usa as vendas que chegaram à ativação, que é a
 * única base capaz de responder quanto do que ativou foi perdido depois.
 *
 * O tom do card é identidade visual, e não semântica de resultado, exatamente
 * como na Visão Geral: a paleta compartilhada não tem vermelho, então a leitura
 * semântica das perdas continua onde ela é a informação, que é a Situação das
 * vendas e o badge da tabela. Nenhum card inventa uma cor fora do template.
 */
function CycleCards({ snapshot, theme }: { snapshot: SalesPeriodCycleSnapshot; theme: Theme }) {
  const [openCard, setOpenCard] = useState<string | null>(null)
  const containerRef = useRef<HTMLElement>(null)
  const { daily, metrics } = snapshot

  useEffect(() => {
    if (openCard === null) return
    const handlePointerDown = (event: PointerEvent) => {
      if (containerRef.current?.contains(event.target as Node) !== true) {
        setOpenCard(null)
      }
    }
    document.addEventListener('pointerdown', handlePointerDown)
    return () => document.removeEventListener('pointerdown', handlePointerDown)
  }, [openCard])

  const cards: readonly CycleCard[] = [
    {
      icon: ClipboardList,
      label: 'Vendas iniciadas',
      value: formatNumber(metrics.startedSales),
      points: daily.map((point) => point.startedSales),
      tone: 'blue',
      readingTitle: `${formatNumber(metrics.startedSales)} vendas começaram no período.`,
      readingText:
        'Este é o total do recorte e a base de fluxo e perdas. Ativação ou cancelamento posterior não muda o período da venda.',
      observe: DISTRIBUTION_NOTE,
    },
    {
      icon: CircleCheckBig,
      label: 'Chegaram à ativação',
      value: formatNumber(metrics.reachedActivation),
      points: daily.map(
        (point) => point.byOutcome.ativada + point.byOutcome['churn-pos-ativacao'],
      ),
      tone: 'green',
      readingTitle: `${formatNumber(metrics.reachedActivation)} vendas chegaram à ativação.`,
      readingText: `Inclui {${formatNumber(metrics.churn)}} vendas ativadas e depois canceladas. Permanecem ativadas sem cancelamento posterior: {${formatNumber(metrics.activated)}}.`,
      observe: DISTRIBUTION_NOTE,
    },
    {
      icon: Hourglass,
      label: 'Ainda em fluxo',
      value: formatNumber(metrics.inFlow),
      points: daily.map((point) => point.byOutcome['em-fluxo']),
      tone: 'amber',
      readingTitle: `${formatNumber(metrics.inFlow)} vendas ainda estão em fluxo.`,
      readingText:
        'Ainda não ativaram nem foram perdidas. O desfecho continua aberto na data de apuração.',
      observe: DISTRIBUTION_NOTE,
    },
    {
      icon: TrendingDown,
      label: 'Perdas pré-ativação',
      value: formatNumber(metrics.preActivationLosses),
      points: daily.map((point) => point.byOutcome['perda-pre-ativacao']),
      tone: 'indigo',
      readingTitle: `${formatNumber(metrics.preActivationLosses)} vendas foram perdidas antes da ativação.`,
      readingText:
        'São reprovadas ou canceladas sem ativação anterior. Não entram no churn; o motivo aparece na tabela.',
      observe: DISTRIBUTION_NOTE,
    },
    {
      icon: UserMinus,
      label: 'Churn pós-ativação',
      value: formatNumber(metrics.churn),
      points: daily.map((point) => point.byOutcome['churn-pos-ativacao']),
      tone: 'violet',
      readingTitle: `${formatNumber(metrics.churn)} vendas ativaram e depois cancelaram.`,
      readingText: churnReadingText(metrics),
      observe: DISTRIBUTION_NOTE,
    },
  ]

  return (
    <section
      aria-label="Indicadores das vendas iniciadas no período"
      className={CARD_GRID_CLASS}
      ref={containerRef}
    >
      {cards.map((card) => (
        <CommercialExecutiveCard
          // Só o indicador e o valor: a frente do card não publica mais nada, e
          // a leitura gerencial continua acessível pelo próprio card.
          accessibleText={`${card.label}: ${card.value}.`}
          icon={card.icon}
          key={card.label}
          label={card.label}
          observe={card.observe}
          onToggle={() => setOpenCard((current) => (current === card.label ? null : card.label))}
          open={openCard === card.label}
          readingText={card.readingText}
          readingTitle={card.readingTitle}
          theme={theme}
          tone={card.tone}
          value={card.value}
          variant="spark"
        >
          <CommercialSparkline color={commercialCardColors[card.tone]} points={card.points} />
        </CommercialExecutiveCard>
      ))}
    </section>
  )
}

/**
 * Leitura gerencial do churn: taxa oficial e impacto na base, nessa ordem.
 *
 * As duas frases são montadas juntas porque é a diferença entre elas que evita a
 * leitura errada: a taxa mede o churn sobre quem chegou à ativação, e o impacto
 * mede o mesmo churn sobre todas as vendas iniciadas. São dois percentuais
 * diferentes de propósito, e cada um escreve o próprio denominador.
 *
 * Recorte sem denominador não vira `0,0%`, que leria como "nenhuma": cada metade
 * cai para o texto que diz por que o percentual não existe.
 */
function churnReadingText(metrics: SalesPeriodCycleMetrics): string {
  const rate =
    metrics.churnShare === null
      ? 'Nenhuma venda do recorte chegou à ativação, então não há taxa de churn.'
      : `Taxa: {${formatPercent(metrics.churnShare)}} sobre as {${formatNumber(metrics.reachedActivation)}} que ativaram.`
  const impact =
    metrics.churnCohortImpact === null
      ? 'O recorte não tem venda iniciada para medir o impacto na base.'
      : `Impacto sobre as vendas iniciadas: {${formatPercent(metrics.churnCohortImpact)}}.`

  return `${rate} ${impact}`
}

/* -------------------------------------------------------------------------- */
/* Origem das vendas                                                          */
/* -------------------------------------------------------------------------- */

/**
 * Composição por origem.
 *
 * Origem é a classificação da venda conforme o indicador, e não o canal pelo
 * qual o cliente entrou em contato. A base não tem campo de canal de aquisição,
 * e nenhum outro campo serve para inferir um.
 *
 * As duas categorias são exclusivas e somam as vendas INICIADAS do recorte, e
 * não apenas as que continuam ativas: uma venda perdida antes de ativar também
 * teve uma origem. Indicação tem precedência, porque a venda indicada também tem
 * uma vendedora responsável, que continua na coluna Vendedor da tabela.
 */
function OriginsPanel({
  origins,
  total,
}: {
  origins: readonly SalesPeriodCycleOriginSlice[]
  total: number
}) {
  return (
    <Panel
      subtitle="Classificação da venda conforme o indicador: com CPF de indicador, é Indicação; sem indicador, é atribuída a Vendedores."
      title="Origem das vendas"
    >
      {total === 0 ? (
        <EmptyPanel>Nenhuma venda iniciada corresponde aos filtros selecionados.</EmptyPanel>
      ) : (
        <>
          <div className="mt-4 space-y-3.5">
            {origins.map((slice) => {
              const indicated = slice.origin === 'indicacao'
              const Icon = indicated ? Handshake : UsersRound

              return (
                <div className="rounded-xl border border-[var(--divider)] p-3" key={slice.origin}>
                  <div className="flex items-start justify-between gap-3">
                    <span
                      className={`rounded-lg p-2 ${indicated ? 'bg-[#14b8a6]/10 text-[#0f9689]' : 'bg-[#2f7de1]/10 text-[#2f7de1]'}`}
                    >
                      <Icon aria-hidden="true" size={17} />
                    </span>
                    <span className="font-mono text-[19px] font-bold text-[var(--text-heading)]">
                      {formatNumber(slice.startedSales)}
                    </span>
                  </div>
                  <div className="mt-3 flex items-center justify-between gap-2 text-[10.5px]">
                    <strong className="text-[var(--text-item)]">{slice.label}</strong>
                    <span className="text-[var(--text-secondary)]">
                      {formatPercent(slice.share)} do total
                    </span>
                  </div>
                  <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-[var(--divider)]">
                    <div
                      className={`h-full rounded-full ${indicated ? 'bg-[#14b8a6]' : 'bg-[#2f7de1]'}`}
                      style={{ width: `${slice.share * 100}%` }}
                    />
                  </div>
                  <p className="mt-2 text-[10.5px] text-[var(--text-secondary)]">
                    {currency.format(slice.monthlyContractedValue)} mensais contratados
                  </p>
                </div>
              )
            })}
          </div>
          <p className="mt-3 text-[10.5px] leading-[1.45] text-[var(--text-secondary)]">
            Somadas, as duas origens correspondem às {formatNumber(total)} vendas iniciadas do
            recorte, em qualquer resultado comercial.
          </p>
        </>
      )}
    </Panel>
  )
}

/* -------------------------------------------------------------------------- */
/* Alternativa acessível do gráfico                                           */
/* -------------------------------------------------------------------------- */

/**
 * O ECharts desenha em canvas, então nenhum valor da série chega a um leitor de
 * tela. A mesma série é publicada em uma tabela fora da tela, como já é feito
 * em Metas e Desempenho. O contêiner é `fixed` em `top:0; left:0` para não
 * esticar a área rolável do documento.
 */
function DailyChartTable({
  daily,
  periodLabel,
}: {
  daily: readonly SalesPeriodCycleDailyPoint[]
  periodLabel: string
}) {
  return (
    <div className="sr-only fixed left-0 top-0 pointer-events-none">
      <table>
        <caption>
          Evolução das vendas iniciadas de {periodLabel}, por Data de Início, com quantidade e valor
          mensal contratado.
        </caption>
        <thead>
          <tr>
            <th scope="col">Data de Início</th>
            <th scope="col">Vendas iniciadas</th>
            <th scope="col">Valor mensal contratado</th>
          </tr>
        </thead>
        <tbody>
          {daily.map((point) => (
            <tr key={point.date}>
              <th scope="row">{formatIsoAsBrDate(point.date)}</th>
              <td>{formatNumber(point.startedSales)}</td>
              <td>{currency.format(point.monthlyContractedValue)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

/* -------------------------------------------------------------------------- */
/* Painéis e estados                                                          */
/* -------------------------------------------------------------------------- */

function Panel({
  children,
  subtitle,
  title,
}: {
  children: ReactNode
  subtitle: string
  title: string
}) {
  return (
    <section className={panelClass}>
      <h2 className="text-[13.5px] font-semibold text-[var(--text-heading)]">{title}</h2>
      <p className="mt-0.5 text-[12px] leading-[1.45] text-[var(--text-secondary)]">{subtitle}</p>
      <div className="mt-2">{children}</div>
    </section>
  )
}

function EmptyPanel({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-[180px] items-center justify-center rounded-lg border border-dashed border-[var(--border)] px-5 text-center text-[12px] text-[var(--text-secondary)]">
      {children}
    </div>
  )
}

function LoadingPanel() {
  return (
    <div aria-live="polite" className={panelClass} role="status">
      <p className="text-[13px] text-[var(--text-secondary)]">
        Carregando as vendas iniciadas da base comercial mockada...
      </p>
      <div aria-hidden="true" className={`mt-4 ${CARD_GRID_CLASS}`}>
        {[0, 1, 2, 3, 4].map((index) => (
          <div className="h-[206px] animate-pulse rounded-xl bg-[var(--divider)]" key={index} />
        ))}
      </div>
    </div>
  )
}

/** Falha ao montar a base ou o ciclo. Não há retorno silencioso para uma tela vazia. */
function ErrorPanel({ message }: { message: string }) {
  return (
    <div className={panelClass} role="alert">
      <p className="text-[13.5px] font-semibold text-[var(--text-heading)]">
        Não foi possível montar as vendas iniciadas no período
      </p>
      <p className="mt-1.5 text-[12px] leading-[1.5] text-[var(--text-secondary)]">{message}</p>
    </div>
  )
}
