import { addDays, dayOfMonth, formatIsoAsBrDate } from '../../../data/commercialCalendar'
import type {
  CommercialActivationMode,
  CommercialCycleExecution,
  CommercialCycleServiceOrder,
  CommercialInstallationCharge,
  CommercialLossReason,
  CommercialSaleCycle,
} from '../../../data/commercialCycleTypes'
import type {
  CommercialCityId,
  CommercialDataset,
  CommercialInstallation,
  CommercialSaleStatus,
} from '../../../data/commercialTypes'
import { buildCommercialSaleCycles } from '../../../data/mockCommercialCycles'
import {
  DEFAULT_SALES_PERIOD_END,
  DEFAULT_SALES_PERIOD_START,
  buildSalesPeriodFacts,
  classifyCommercialInstallation,
  salesPeriodOriginLabels,
  salesPeriodOriginOf,
  type SalesPeriodFact,
  type SalesPeriodOrigin,
  type SalesPeriodOriginFilter,
} from './salesPeriodModel'

/**
 * Modelo do ciclo comercial de Vendas por Período.
 *
 * Responde o que acontece com a venda depois que ela começa: quantas iniciaram
 * no período, quantas chegaram à ativação, quantas continuam em fluxo, quantas
 * se perderam antes de ativar e quantas ativaram e depois cancelaram.
 *
 * Três separações sustentam o bloco inteiro:
 *
 * 1. A Data de Início decide sozinha o período. Ativação e cancelamento
 *    posteriores nunca transferem a venda para outro mês.
 * 2. O resultado comercial é DERIVADO por função pura das datas e do status.
 *    Não existe rótulo gravado capaz de divergir dos eventos.
 * 3. Cobrança da instalação, modalidade para ativação e execução resumida são
 *    três leituras independentes. Instalação isenta pode ter OS física
 *    concluída, e OS de ativação remota nunca vira instalação física.
 *
 * Os atributos comerciais da venda (contrato, cliente, vendedor, cidade, plano,
 * valor mensal e origem) NÃO são gerados aqui: eles vêm da projeção
 * `SalesPeriodFact`, que a página já usa, e são ligados ao ciclo por `saleId`.
 * Uma segunda geração de contratos, planos ou valores faria a mesma venda ter
 * dois conjuntos de atributos, e é justamente isso que a ligação evita.
 *
 * Nada aqui é consumido por Visão Geral ou por Metas e Desempenho, e nada aqui
 * altera os números daquelas páginas: este modelo lê a mesma base e produz uma
 * projeção própria, vinculada à venda por `saleId`.
 */

/* -------------------------------------------------------------------------- */
/* Classificação comercial                                                    */
/* -------------------------------------------------------------------------- */

/**
 * Resultado comercial da venda.
 *
 * `sem-classificacao` não é erro nem sobra: é a ausência declarada de regra
 * aprovada, hoje o caso do status Expirada, e também o destino de qualquer
 * registro incoerente, que fica visível em vez de ser corrigido em silêncio.
 */
export type SalesPeriodCycleOutcome =
  | 'em-fluxo'
  | 'ativada'
  | 'churn-pos-ativacao'
  | 'perda-pre-ativacao'
  | 'sem-classificacao'

/**
 * Erro de qualidade do registro.
 *
 * Sempre explícito, e sempre acompanhado de `sem-classificacao`: um registro
 * temporalmente impossível, ou incoerente entre status e eventos, não recebe
 * conserto automático e não entra em nenhuma categoria de negócio.
 */
export type SalesPeriodCycleIssue =
  | 'ativacao-anterior-ao-inicio'
  | 'cancelamento-anterior-ao-inicio'
  | 'cancelamento-anterior-a-ativacao'
  | 'ativacao-ausente'
  | 'ativacao-em-status-de-fluxo'
  | 'cancelamento-em-status-de-fluxo'
  | 'cancelamento-em-status-ativo'
  | 'cancelamento-ausente'
  | 'reprovacao-com-ativacao'
  | 'motivo-de-perda-sem-perda'
  | 'motivo-de-perda-ausente'

export type SalesPeriodCycleClassification = {
  readonly outcome: SalesPeriodCycleOutcome
  /** `null` quando o registro é coerente. */
  readonly issue: SalesPeriodCycleIssue | null
}

/**
 * Filtro por resultado comercial.
 *
 * `todos` é o valor neutro, no mesmo padrão de `SalesPeriodTeamFilter` e
 * `SalesPeriodOriginFilter`. O filtro apenas seleciona o resultado que a função
 * pura já derivou: ele nunca reclassifica a venda.
 */
export type SalesPeriodCycleOutcomeFilter = 'todos' | SalesPeriodCycleOutcome

export const salesPeriodCycleOutcomeLabels: Record<SalesPeriodCycleOutcome, string> = {
  'em-fluxo': 'Ainda em fluxo',
  ativada: 'Ativada',
  'churn-pos-ativacao': 'Churn pós-ativação',
  'perda-pre-ativacao': 'Perda pré-ativação',
  'sem-classificacao': 'Sem classificação',
}

export const commercialActivationModeLabels: Record<CommercialActivationMode, string> = {
  'instalacao-fisica': 'Instalação física',
  'ativacao-remota': 'Ativação remota',
  'sem-intervencao-tecnica': 'Sem intervenção técnica',
  'nao-identificada': 'Não identificada',
}

export const commercialInstallationChargeLabels: Record<CommercialInstallationCharge, string> = {
  integral: 'Integral',
  'com-desconto': 'Com desconto',
  isenta: 'Isenta',
  'sem-dado': 'Sem dado',
  'nao-aplicavel': 'Não aplicável',
}

export const commercialCycleExecutionLabels: Record<CommercialCycleExecution, string> = {
  'sem-necessidade': 'Sem necessidade',
  'sem-os-relacionada': 'Sem OS relacionada',
  pendente: 'Pendente',
  concluida: 'Concluída',
  improdutiva: 'Improdutiva',
  'encerrada-sem-conclusao': 'Encerrada sem conclusão',
  'sem-informacao': 'Sem informação',
}

export const commercialLossReasonLabels: Record<CommercialLossReason, string> = {
  duplicidade: 'Duplicidade',
  'cancelamento-de-contrato': 'Cancelamento de contrato',
  'nao-informado': 'Não informado',
}

/** Status que só têm leitura aprovada quando existe ativação e não existe cancelamento. */
const ACTIVATED_STATUSES: ReadonlySet<CommercialSaleStatus> = new Set([
  'ativa',
  'suspensa',
  'bloqueio-administrativo',
  'bloqueio-financeiro',
])

/** Status de venda que começou e ainda não teve ativação nem cancelamento. */
const FLOW_STATUSES: ReadonlySet<CommercialSaleStatus> = new Set([
  'pendente',
  'assinada',
  'agendada',
  'aguardando-aprovacao',
  'nao-sincronizada',
])

function unclassified(issue: SalesPeriodCycleIssue | null): SalesPeriodCycleClassification {
  return { outcome: 'sem-classificacao', issue }
}

/** Coerência temporal dos eventos, antes de qualquer leitura de negócio. */
function temporalIssueOf(cycle: CommercialSaleCycle): SalesPeriodCycleIssue | null {
  const { startDate, activatedAt, canceledAt } = cycle

  if (activatedAt !== null && activatedAt < startDate) return 'ativacao-anterior-ao-inicio'
  if (canceledAt !== null && canceledAt < startDate) return 'cancelamento-anterior-ao-inicio'
  if (activatedAt !== null && canceledAt !== null && canceledAt < activatedAt) {
    return 'cancelamento-anterior-a-ativacao'
  }

  return null
}

/** Leitura de negócio por status, já com os eventos validados no tempo. */
function outcomeByStatus(cycle: CommercialSaleCycle): SalesPeriodCycleClassification {
  const { status, activatedAt, canceledAt } = cycle

  if (ACTIVATED_STATUSES.has(status)) {
    if (activatedAt === null) return unclassified('ativacao-ausente')
    if (canceledAt !== null) return unclassified('cancelamento-em-status-ativo')

    return { outcome: 'ativada', issue: null }
  }

  if (FLOW_STATUSES.has(status)) {
    if (activatedAt !== null) return unclassified('ativacao-em-status-de-fluxo')
    if (canceledAt !== null) return unclassified('cancelamento-em-status-de-fluxo')

    return { outcome: 'em-fluxo', issue: null }
  }

  if (status === 'reprovada') {
    // Reprovação com ativação anterior não tem regra aprovada: fica visível.
    if (activatedAt !== null) return unclassified('reprovacao-com-ativacao')

    return { outcome: 'perda-pre-ativacao', issue: null }
  }

  if (status === 'cancelada') {
    if (canceledAt === null) return unclassified('cancelamento-ausente')

    return activatedAt === null
      ? { outcome: 'perda-pre-ativacao', issue: null }
      : { outcome: 'churn-pos-ativacao', issue: null }
  }

  // Expirada, e qualquer status futuro sem regra aprovada, como Cortesia.
  return unclassified(null)
}

function isLoss(outcome: SalesPeriodCycleOutcome): boolean {
  return outcome === 'perda-pre-ativacao' || outcome === 'churn-pos-ativacao'
}

/**
 * Resultado comercial de um ciclo. Função pura, sem estado e sem correção
 * silenciosa.
 *
 * A ordem importa: primeiro a coerência das datas, depois a leitura por status,
 * e só então a coerência do motivo de perda. Qualquer incoerência devolve
 * `sem-classificacao` com o erro nomeado, e nunca uma categoria plausível.
 *
 * Regras de negócio aprovadas:
 *
 * - Pendente, Assinada, Agendada, Aguardando aprovação e Não sincronizada, sem
 *   ativação e sem cancelamento: ainda em fluxo;
 * - Reprovada sem ativação: perda pré-ativação;
 * - Cancelada sem ativação: perda pré-ativação;
 * - Cancelada com ativação anterior: churn pós-ativação;
 * - Ativa, Suspensa e bloqueios, com ativação e sem cancelamento: ativada;
 * - Expirada: sem classificação, até existir nova decisão de negócio.
 *
 * O motivo de perda existe exatamente quando existe perda. Nenhuma OS participa
 * desta função: instalação improdutiva não vira motivo de cancelamento.
 */
export function classifySalesPeriodCycle(
  cycle: CommercialSaleCycle,
): SalesPeriodCycleClassification {
  const temporalIssue = temporalIssueOf(cycle)
  if (temporalIssue !== null) return unclassified(temporalIssue)

  const classification = outcomeByStatus(cycle)
  if (classification.issue !== null) return classification

  if (isLoss(classification.outcome)) {
    if (cycle.lossReason === null) return unclassified('motivo-de-perda-ausente')
  } else if (cycle.lossReason !== null) {
    return unclassified('motivo-de-perda-sem-perda')
  }

  return classification
}

/* -------------------------------------------------------------------------- */
/* Cobrança e execução                                                        */
/* -------------------------------------------------------------------------- */

/**
 * Cobrança da instalação, na leitura do ciclo.
 *
 * Reusa a classificação já validada do bloco de instalações, em vez de repetir a
 * regra: registro inválido continua sendo `sem-dado`, e ausência de registro
 * nunca vira isenção. `nao-aplicavel` depende da evidência explícita do próprio
 * ciclo, e não da falta de dado.
 */
export function salesPeriodCycleChargeOf(
  cycle: CommercialSaleCycle,
  installation: CommercialInstallation | undefined,
): CommercialInstallationCharge {
  if (!cycle.hasInstallationService) return 'nao-aplicavel'
  if (installation === undefined) return 'sem-dado'

  const status = classifyCommercialInstallation(installation)
  if (status === null) return 'sem-dado'

  return status === 'desconto' ? 'com-desconto' : status
}

/** OS que pertencem à ativação inicial. As demais existem e não decidem nada. */
function relatedOrdersOf(
  serviceOrders: readonly CommercialCycleServiceOrder[],
): CommercialCycleServiceOrder[] {
  return serviceOrders.filter((order) => order.kind !== 'nao-relacionada')
}

/**
 * Execução resumida.
 *
 * Precedência entre as tentativas relacionadas à ativação inicial: a instalação
 * concluída passa a ser o resultado principal, e uma nova tentativa pendente
 * substitui a improdutiva anterior na leitura resumida. As tentativas
 * improdutivas anteriores continuam contáveis no detalhe, em
 * `unproductiveAttempts`.
 *
 * Sem OS relacionada, quem responde é a modalidade: sem intervenção técnica é
 * ausência de necessidade, modalidade não identificada é ausência de informação,
 * e o restante é ausência de OS.
 */
export function salesPeriodCycleExecutionOf(cycle: CommercialSaleCycle): CommercialCycleExecution {
  const related = relatedOrdersOf(cycle.serviceOrders)
  const has = (outcome: CommercialCycleServiceOrder['outcome']): boolean =>
    related.some((order) => order.outcome === outcome)

  if (has('concluida')) return 'concluida'
  if (has('pendente')) return 'pendente'
  if (has('improdutiva')) return 'improdutiva'
  if (has('encerrada-sem-conclusao')) return 'encerrada-sem-conclusao'

  if (cycle.activationMode === 'sem-intervencao-tecnica') return 'sem-necessidade'
  if (cycle.activationMode === 'nao-identificada') return 'sem-informacao'

  return 'sem-os-relacionada'
}

/* -------------------------------------------------------------------------- */
/* Projeção analítica                                                         */
/* -------------------------------------------------------------------------- */

/**
 * Uma venda do ciclo comercial, já lida.
 *
 * Um registro por venda, sempre. Várias OS ficam dentro de `serviceOrders` e
 * nunca viram linhas novas.
 *
 * Os campos comerciais vêm inteiros de `SalesPeriodFact`, ligados por `saleId`.
 * A mesma venda tem aqui exatamente o mesmo contrato, cliente, vendedora,
 * cidade, plano e valor mensal que já tem no bloco de vendas ativas.
 */
export type SalesPeriodCycleRecord = {
  readonly saleId: string
  /** Data de Início. Único critério de inclusão no período. */
  readonly startDate: string
  readonly activatedAt: string | null
  readonly canceledAt: string | null
  readonly status: CommercialSaleStatus
  readonly contractCode: string
  readonly customerLabel: string
  /** Vendedora responsável. A venda indicada também tem uma. */
  readonly sellerId: string
  readonly sellerName: string
  /** Cidade do endereço onde a internet foi instalada. Nunca é origem comercial. */
  readonly cityId: CommercialCityId
  readonly cityName: string
  readonly planName: string
  /** Valor mensal contratado. Não é receita reconhecida. */
  readonly monthlyValue: number
  /** Origem, pela regra já aprovada: com indicador é Indicação, sem indicador é Vendedores. */
  readonly origin: SalesPeriodOrigin
  /** Resultado comercial derivado. Nunca é um rótulo gravado na base. */
  readonly outcome: SalesPeriodCycleOutcome
  /** Erro de qualidade explícito, quando o registro é incoerente. */
  readonly issue: SalesPeriodCycleIssue | null
  readonly lossReason: CommercialLossReason | null
  readonly activationMode: CommercialActivationMode
  readonly installationCharge: CommercialInstallationCharge
  readonly execution: CommercialCycleExecution
  readonly serviceOrders: readonly CommercialCycleServiceOrder[]
  /** Tentativas improdutivas relacionadas à ativação, mantidas contáveis. */
  readonly unproductiveAttempts: number
  readonly referenceDate: string
}

/**
 * Filtros globais da página, aplicados sobre as vendas iniciadas.
 *
 * Todos funcionam como interseção, e cada um tem um valor neutro explícito, no
 * mesmo padrão de `ActiveSalesFilters`: `null` significa todas as cidades,
 * todos os vendedores ou todos os planos, `todas` significa todas as origens e
 * `todos` significa todos os resultados comerciais.
 *
 * Os filtros avançados de status atual, modalidade, cobrança, execução e motivo
 * da perda não estão aqui de propósito: eles pertencem ao bloco de interface que
 * ainda não foi implementado.
 */
export type SalesPeriodCycleFilters = {
  /** Início do período. Comparado somente contra a Data de Início. */
  readonly periodStart: string
  readonly periodEnd: string
  /** Cidade de instalação. `null` significa todas. */
  readonly cityId: CommercialCityId | null
  /** `null` significa todos os vendedores. */
  readonly sellerId: string | null
  readonly origin: SalesPeriodOriginFilter
  /** `null` significa todos os planos. */
  readonly planName: string | null
  readonly outcome: SalesPeriodCycleOutcomeFilter
}

/**
 * Indicadores da coorte.
 *
 * `startedSales` é o denominador de fluxo e de perdas pré-ativação.
 * `reachedActivation` inclui as vendas que depois viraram churn, e é o
 * denominador do churn. O impacto na coorte é informação secundária, e por isso
 * usa `startedSales` de propósito.
 *
 * Por construção: iniciadas = ativadas + em fluxo + perdas + churn + sem
 * classificação, e chegaram à ativação = ativadas + churn.
 */
export type SalesPeriodCycleMetrics = {
  readonly startedSales: number
  readonly reachedActivation: number
  readonly activated: number
  readonly inFlow: number
  readonly preActivationLosses: number
  readonly churn: number
  readonly unclassified: number
  /**
   * Chegaram à ativação sobre as vendas iniciadas. `null` quando não há venda
   * iniciada. Inclui as vendas que depois viraram churn, de propósito.
   */
  readonly activationShare: number | null
  /** Sobre as vendas iniciadas. `null` quando não há venda iniciada. */
  readonly inFlowShare: number | null
  /** Sobre as vendas iniciadas. `null` quando não há venda iniciada. */
  readonly preActivationLossShare: number | null
  /** Sobre as vendas que chegaram à ativação. `null` quando não houve nenhuma. */
  readonly churnShare: number | null
  /** Churn sobre as vendas iniciadas. Informação secundária. */
  readonly churnCohortImpact: number | null
  /** Registros incoerentes do recorte. Deve ser zero na base mockada. */
  readonly qualityIssues: number
}

/**
 * Opções dos filtros que dependem dos registros.
 *
 * Vendedores e planos NÃO são gerados aqui: são os mesmos que os registros já
 * carregam, apenas reunidos sem repetição. Cidades continuam vindo do catálogo
 * do dataset, porque lá elas existem independentemente de haver venda.
 */
export type SalesPeriodCycleOptions = {
  readonly sellers: readonly { readonly id: string; readonly name: string }[]
  readonly plans: readonly string[]
}

/**
 * Um dia do período, sempre pela Data de Início.
 *
 * É o ponto da Evolução das vendas iniciadas. Ativação e cancelamento NÃO
 * posicionam nada aqui: a venda iniciada em 03/07 continua no dia 03/07 mesmo
 * que ative no dia 10 ou cancele no dia 20. Por isso a série responde "quantas
 * vendas começaram neste dia", e nunca "quantas ativaram neste dia".
 *
 * `byOutcome` existe para os minigráficos dos cards mostrarem a distribuição de
 * cada resultado pela Data de Início, e soma exatamente `startedSales`.
 */
export type SalesPeriodCycleDailyPoint = {
  readonly date: string
  readonly day: number
  /** Vendas com Data de Início neste dia, em qualquer resultado comercial. */
  readonly startedSales: number
  /** Valor mensal contratado por essas vendas. Não é receita reconhecida. */
  readonly monthlyContractedValue: number
  /** Distribuição do dia por resultado derivado. Soma `startedSales`. */
  readonly byOutcome: Readonly<Record<SalesPeriodCycleOutcome, number>>
}

/**
 * Composição por origem das vendas INICIADAS.
 *
 * As duas fatias sempre existem, mesmo zeradas, e sempre somam as vendas
 * iniciadas do recorte, e não apenas as que continuam ativas: cada venda é
 * classificada uma única vez pela mesma regra aprovada do indicador.
 */
export type SalesPeriodCycleOriginSlice = {
  readonly origin: SalesPeriodOrigin
  readonly label: string
  readonly startedSales: number
  readonly monthlyContractedValue: number
  /** Participação nas vendas iniciadas do recorte. */
  readonly share: number
}

export type SalesPeriodCycleSnapshot = {
  readonly filters: SalesPeriodCycleFilters
  readonly periodLabel: string
  readonly records: readonly SalesPeriodCycleRecord[]
  readonly metrics: SalesPeriodCycleMetrics
  /** Evolução por Data de Início, um ponto por dia do período. */
  readonly daily: readonly SalesPeriodCycleDailyPoint[]
  readonly origins: readonly SalesPeriodCycleOriginSlice[]
  /** Derivadas de TODAS as vendas, e não do recorte atual. */
  readonly options: SalesPeriodCycleOptions
}

/** Período padrão da página, com todos os demais filtros abertos. */
export function initialSalesPeriodCycleFilters(): SalesPeriodCycleFilters {
  return {
    periodStart: DEFAULT_SALES_PERIOD_START,
    periodEnd: DEFAULT_SALES_PERIOD_END,
    cityId: null,
    sellerId: null,
    origin: 'todas',
    planName: null,
    outcome: 'todos',
  }
}

function countUnproductive(serviceOrders: readonly CommercialCycleServiceOrder[]): number {
  return relatedOrdersOf(serviceOrders).filter((order) => order.outcome === 'improdutiva').length
}

function toRecord(
  cycle: CommercialSaleCycle,
  fact: SalesPeriodFact,
  installation: CommercialInstallation | undefined,
): SalesPeriodCycleRecord {
  const { outcome, issue } = classifySalesPeriodCycle(cycle)

  return {
    saleId: cycle.saleId,
    startDate: cycle.startDate,
    activatedAt: cycle.activatedAt,
    canceledAt: cycle.canceledAt,
    status: cycle.status,
    contractCode: fact.contractCode,
    customerLabel: fact.customerLabel,
    sellerId: fact.sellerId,
    sellerName: fact.sellerName,
    cityId: fact.cityId,
    cityName: fact.cityName,
    planName: fact.planName,
    monthlyValue: fact.monthlyValue,
    // A origem sai da mesma regra aprovada da página, e não de uma segunda leitura.
    origin: salesPeriodOriginOf(fact.indicatorCpf),
    outcome,
    issue,
    lossReason: cycle.lossReason,
    activationMode: cycle.activationMode,
    installationCharge: salesPeriodCycleChargeOf(cycle, installation),
    execution: salesPeriodCycleExecutionOf(cycle),
    serviceOrders: cycle.serviceOrders,
    unproductiveAttempts: countUnproductive(cycle.serviceOrders),
    referenceDate: cycle.referenceDate,
  }
}

/**
 * Ciclo comercial de todas as vendas da base, já classificado.
 *
 * Exatamente um registro por venda. Ciclo, fato comercial e instalação são
 * unidos por `saleId`, e nunca pela posição nos arrays: as três projeções são
 * construídas separadamente, e só o identificador da venda as liga.
 *
 * Um ciclo sem o fato comercial correspondente significaria que as duas
 * projeções deixaram de derivar da mesma base. Nesse caso a função INTERROMPE
 * com o `saleId` inconsistente no erro. Ela não descarta a venda e não inventa
 * contrato, plano ou valor: perder uma venda em silêncio faria todos os
 * indicadores da coorte fecharem sobre um total menor sem nada indicar isso.
 *
 * A instalação continua opcional, porque ausência de cobrança é um estado
 * previsto do negócio. Ausência de fato comercial não é.
 *
 * A base compartilhada não é alterada em nenhum ponto: ela é apenas lida.
 */
export function buildSalesPeriodCycleRecords(dataset: CommercialDataset): SalesPeriodCycleRecord[] {
  const installations = new Map(
    dataset.installations.map((installation) => [installation.saleId, installation]),
  )
  const facts = new Map(buildSalesPeriodFacts(dataset).map((fact) => [fact.id, fact]))

  return buildCommercialSaleCycles(dataset.sales, dataset.referenceDate).map((cycle) => {
    const fact = facts.get(cycle.saleId)

    if (fact === undefined) {
      throw new Error(`Venda sem fato comercial correspondente no ciclo: ${cycle.saleId}`)
    }

    return toRecord(cycle, fact, installations.get(cycle.saleId))
  })
}

/**
 * Todos os filtros globais funcionam como interseção.
 *
 * O período é comparado exclusivamente contra a Data de Início. Ativação e
 * cancelamento não participam do recorte temporal, então a venda iniciada em
 * julho continua em julho mesmo que ative ou cancele depois.
 *
 * O resultado comercial entra aqui já derivado: o filtro seleciona a venda, e
 * não reclassifica nenhuma.
 */
function matchesSalesPeriodCycleFilters(
  record: SalesPeriodCycleRecord,
  filters: SalesPeriodCycleFilters,
): boolean {
  if (record.startDate < filters.periodStart || record.startDate > filters.periodEnd) return false
  if (filters.cityId !== null && record.cityId !== filters.cityId) return false
  if (filters.sellerId !== null && record.sellerId !== filters.sellerId) return false
  if (filters.origin !== 'todas' && record.origin !== filters.origin) return false
  if (filters.planName !== null && record.planName !== filters.planName) return false
  if (filters.outcome !== 'todos' && record.outcome !== filters.outcome) return false

  return true
}

/** Vendas iniciadas do recorte, com todos os filtros globais aplicados. */
export function selectSalesPeriodCycleRecords(
  records: readonly SalesPeriodCycleRecord[],
  filters: SalesPeriodCycleFilters,
): SalesPeriodCycleRecord[] {
  return records.filter((record) => matchesSalesPeriodCycleFilters(record, filters))
}

function shareOf(value: number, total: number): number | null {
  return total === 0 ? null : value / total
}

export function buildSalesPeriodCycleMetrics(
  records: readonly SalesPeriodCycleRecord[],
): SalesPeriodCycleMetrics {
  const countOf = (outcome: SalesPeriodCycleOutcome): number =>
    records.filter((record) => record.outcome === outcome).length

  const startedSales = records.length
  const activated = countOf('ativada')
  const churn = countOf('churn-pos-ativacao')
  // Chegaram à ativação inclui quem depois cancelou: o churn não some da coorte.
  const reachedActivation = activated + churn
  const inFlow = countOf('em-fluxo')
  const preActivationLosses = countOf('perda-pre-ativacao')

  return {
    startedSales,
    reachedActivation,
    activated,
    inFlow,
    preActivationLosses,
    churn,
    unclassified: countOf('sem-classificacao'),
    activationShare: shareOf(reachedActivation, startedSales),
    inFlowShare: shareOf(inFlow, startedSales),
    preActivationLossShare: shareOf(preActivationLosses, startedSales),
    churnShare: shareOf(churn, reachedActivation),
    churnCohortImpact: shareOf(churn, startedSales),
    qualityIssues: records.filter((record) => record.issue !== null).length,
  }
}

/** Contagem zerada dos cinco resultados, base de cada dia da evolução. */
function emptyOutcomeCounts(): Record<SalesPeriodCycleOutcome, number> {
  return {
    'em-fluxo': 0,
    ativada: 0,
    'churn-pos-ativacao': 0,
    'perda-pre-ativacao': 0,
    'sem-classificacao': 0,
  }
}

/**
 * Evolução do recorte, dia a dia, pela Data de Início.
 *
 * O período inteiro é percorrido, e não apenas os dias com venda: um dia vazio
 * entra com zero, para o eixo do gráfico não comprimir o calendário e sugerir
 * uma continuidade que não existiu.
 */
export function buildSalesPeriodCycleDaily(
  records: readonly SalesPeriodCycleRecord[],
  periodStart: string,
  periodEnd: string,
): SalesPeriodCycleDailyPoint[] {
  const byDate = new Map<
    string,
    {
      startedSales: number
      monthlyContractedValue: number
      byOutcome: Record<SalesPeriodCycleOutcome, number>
    }
  >()

  records.forEach((record) => {
    const current = byDate.get(record.startDate) ?? {
      startedSales: 0,
      monthlyContractedValue: 0,
      byOutcome: emptyOutcomeCounts(),
    }

    current.startedSales += 1
    current.monthlyContractedValue += record.monthlyValue
    current.byOutcome[record.outcome] += 1
    byDate.set(record.startDate, current)
  })

  const points: SalesPeriodCycleDailyPoint[] = []
  for (let date = periodStart; date <= periodEnd; date = addDays(date, 1)) {
    const current = byDate.get(date)
    points.push({
      date,
      day: dayOfMonth(date),
      startedSales: current?.startedSales ?? 0,
      monthlyContractedValue: current?.monthlyContractedValue ?? 0,
      byOutcome: current?.byOutcome ?? emptyOutcomeCounts(),
    })
  }

  return points
}

/**
 * Origem das vendas iniciadas do recorte.
 *
 * O denominador é o total INICIADO, e não o total ainda ativo: uma venda
 * perdida antes de ativar continua tendo tido uma origem, e retirá-la faria as
 * duas fatias fecharem sobre um universo diferente do dos indicadores.
 */
export function buildSalesPeriodCycleOrigins(
  records: readonly SalesPeriodCycleRecord[],
): SalesPeriodCycleOriginSlice[] {
  return (['indicacao', 'vendedores'] as const).map((origin) => {
    const slice = records.filter((record) => record.origin === origin)

    return {
      origin,
      label: salesPeriodOriginLabels[origin],
      startedSales: slice.length,
      monthlyContractedValue: slice.reduce((total, record) => total + record.monthlyValue, 0),
      share: records.length === 0 ? 0 : slice.length / records.length,
    }
  })
}

/** Data de Início decrescente, com o identificador da venda como desempate estável. */
function sortCycleRecords(records: readonly SalesPeriodCycleRecord[]): SalesPeriodCycleRecord[] {
  return [...records].sort(
    (a, b) => b.startDate.localeCompare(a.startDate) || b.saleId.localeCompare(a.saleId),
  )
}

/**
 * Opções de vendedor e plano, derivadas do universo inteiro de vendas.
 *
 * De propósito antes dos filtros globais, como já acontece em
 * `buildActiveSalesOptions`: uma opção que desaparecesse da lista ao ser
 * aplicada deixaria o próprio filtro imprevisível.
 */
export function buildSalesPeriodCycleOptions(
  records: readonly SalesPeriodCycleRecord[],
): SalesPeriodCycleOptions {
  const sellers = new Map<string, string>()
  const plans = new Set<string>()

  records.forEach((record) => {
    sellers.set(record.sellerId, record.sellerName)
    plans.add(record.planName)
  })

  return {
    sellers: [...sellers.entries()]
      .map(([id, name]) => ({ id, name }))
      .sort((a, b) => a.name.localeCompare(b.name, 'pt-BR')),
    plans: [...plans].sort((a, b) => a.localeCompare(b, 'pt-BR')),
  }
}

/**
 * Recorte completo do ciclo comercial.
 *
 * Indicadores, evolução diária e origem são calculados sobre o MESMO conjunto já
 * filtrado que sai em `records`: nenhum número da coorte olha vendas fora do
 * recorte, e as três projeções fecham entre si. As opções dos filtros são a
 * única exceção declarada, e olham o universo inteiro.
 */
export function buildSalesPeriodCycleSnapshot(
  dataset: CommercialDataset,
  filters: SalesPeriodCycleFilters,
): SalesPeriodCycleSnapshot {
  const allRecords = buildSalesPeriodCycleRecords(dataset)
  const records = sortCycleRecords(selectSalesPeriodCycleRecords(allRecords, filters))

  return {
    filters,
    periodLabel: `${formatIsoAsBrDate(filters.periodStart)} a ${formatIsoAsBrDate(filters.periodEnd)}`,
    records,
    metrics: buildSalesPeriodCycleMetrics(records),
    daily: buildSalesPeriodCycleDaily(records, filters.periodStart, filters.periodEnd),
    origins: buildSalesPeriodCycleOrigins(records),
    options: buildSalesPeriodCycleOptions(allRecords),
  }
}

/* -------------------------------------------------------------------------- */
/* Paginação da tabela do ciclo                                               */
/* -------------------------------------------------------------------------- */

/** Mesma quantidade por página já usada nas outras tabelas do portal. */
export const SALES_PERIOD_CYCLE_PAGE_SIZE = 10

export type SalesPeriodCyclePage = {
  /** Página efetivamente exibida, já corrigida para o intervalo válido. */
  readonly page: number
  readonly totalPages: number
  readonly total: number
  /** Primeiro e último registro exibidos, em contagem humana. Zero na lista vazia. */
  readonly from: number
  readonly to: number
  readonly records: readonly SalesPeriodCycleRecord[]
}

/**
 * Recorte de uma página da tabela do ciclo.
 *
 * Função pura e própria deste bloco: ela recorta `SalesPeriodCycleRecord`, e
 * não reaproveita a paginação de `ActiveSaleRow`, que pertence ao universo de
 * vendas exclusivamente ativas.
 *
 * A página pedida é corrigida para dentro do intervalo válido em vez de virar
 * estado novo: com o conjunto encolhendo por filtro, o próprio render devolve
 * uma página existente, sem `setState` em efeito.
 */
export function buildSalesPeriodCyclePage(
  records: readonly SalesPeriodCycleRecord[],
  requestedPage: number,
  pageSize: number = SALES_PERIOD_CYCLE_PAGE_SIZE,
): SalesPeriodCyclePage {
  const total = records.length
  const totalPages = Math.max(1, Math.ceil(total / pageSize))
  const page = Math.min(Math.max(requestedPage, 0), totalPages - 1)
  const start = page * pageSize

  return {
    page,
    totalPages,
    total,
    from: total === 0 ? 0 : start + 1,
    to: Math.min(total, start + pageSize),
    records: records.slice(start, start + pageSize),
  }
}
