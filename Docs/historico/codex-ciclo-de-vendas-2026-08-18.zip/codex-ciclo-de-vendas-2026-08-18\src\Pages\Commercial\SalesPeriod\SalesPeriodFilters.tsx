import type { ReactNode } from 'react'

import {
  COMMERCIAL_PERIOD_END,
  COMMERCIAL_PERIOD_START,
  formatIsoAsBrDate,
} from '../../../data/commercialCalendar'
import type { CommercialCity, CommercialCityId } from '../../../data/commercialTypes'
import {
  initialSalesPeriodCycleFilters,
  salesPeriodCycleOutcomeLabels,
  type SalesPeriodCycleFilters as CycleFilters,
  type SalesPeriodCycleOptions,
  type SalesPeriodCycleOutcomeFilter,
} from './salesPeriodCycleModel'
import { salesPeriodOriginLabels, type SalesPeriodOriginFilter } from './salesPeriodModel'

/**
 * O anel de foco fica no campo inteiro, e não no controle.
 *
 * O controle usa `outline-none` para o campo parecer um só elemento; sem o
 * `focus-within` aqui, a navegação por teclado deixaria de mostrar onde está.
 *
 * No celular cada campo ocupa a linha inteira (`w-full`), e é isso que impede os
 * sete filtros de disputarem uma única linha estreita: com `flex-1` e `min-w-0`
 * eles podiam encolher até o rótulo e o valor ficarem ilegíveis em 390 px. A
 * partir de `sm` os campos voltam à largura natural e seguem quebrando linha
 * conforme o espaço disponível.
 */
const fieldClass =
  'flex w-full min-w-0 items-center gap-2 rounded-lg border border-[var(--border)] bg-[var(--surface)] px-3 py-2 text-[12px] text-[var(--text-item)] focus-within:ring-2 focus-within:ring-[var(--accent)] sm:w-auto sm:flex-none'
const controlClass = 'min-w-0 flex-1 bg-transparent font-semibold outline-none sm:max-w-[190px]'

/** Ordem aprovada do filtro de resultado comercial. */
const OUTCOME_OPTIONS = [
  'ativada',
  'em-fluxo',
  'perda-pre-ativacao',
  'churn-pos-ativacao',
  'sem-classificacao',
] as const

/**
 * Filtros de Vendas por Período.
 *
 * O universo da página são as vendas INICIADAS no período, então o filtro de
 * resultado comercial existe e é legítimo: ele seleciona onde a venda está
 * hoje, sem reclassificar nenhuma. O que continua fora é filtro de status
 * atual, modalidade, cobrança, execução e motivo da perda, que pertencem a um
 * bloco posterior.
 *
 * Time, CPF do indicador e retorno à base também não aparecem, porque nenhum
 * deles é dimensão deste bloco.
 */
export function SalesPeriodFilters({
  cities,
  filters,
  onChange,
  options,
  referenceDate,
}: {
  cities: readonly CommercialCity[]
  filters: CycleFilters
  onChange: (filters: CycleFilters) => void
  options: SalesPeriodCycleOptions
  /** Data de apuração do mock. Informativa, e nunca editável. */
  referenceDate: string
}) {
  const initial = initialSalesPeriodCycleFilters()
  const isInitial =
    filters.periodStart === initial.periodStart &&
    filters.periodEnd === initial.periodEnd &&
    filters.cityId === null &&
    filters.sellerId === null &&
    filters.origin === 'todas' &&
    filters.planName === null &&
    filters.outcome === 'todos'

  return (
    <section
      aria-label="Filtros das vendas iniciadas no período"
      className="rounded-xl border border-[var(--border)] bg-[var(--surface)] p-3"
    >
      <div className="flex flex-wrap gap-2">
        <FilterField label="Data inicial">
          <input
            className={controlClass}
            onChange={(event) => {
              const periodStart = event.target.value
              // Data vazia ou incompleta é descartada: o recorte nunca fica sem
              // período, e o valor anterior continua valendo.
              if (!periodStart) return

              onChange({
                ...filters,
                periodStart,
                periodEnd: periodStart > filters.periodEnd ? periodStart : filters.periodEnd,
              })
            }}
            max={COMMERCIAL_PERIOD_END}
            min={COMMERCIAL_PERIOD_START}
            required
            type="date"
            value={filters.periodStart}
          />
        </FilterField>

        <FilterField label="Data final">
          <input
            className={controlClass}
            onChange={(event) => {
              const periodEnd = event.target.value
              if (!periodEnd) return

              onChange({
                ...filters,
                periodStart: periodEnd < filters.periodStart ? periodEnd : filters.periodStart,
                periodEnd,
              })
            }}
            max={COMMERCIAL_PERIOD_END}
            min={COMMERCIAL_PERIOD_START}
            required
            type="date"
            value={filters.periodEnd}
          />
        </FilterField>

        <FilterField label="Cidade de instalação">
          <select
            className={controlClass}
            onChange={(event) =>
              onChange({
                ...filters,
                cityId:
                  event.target.value === 'todas'
                    ? null
                    : (event.target.value as CommercialCityId),
              })
            }
            value={filters.cityId ?? 'todas'}
          >
            <option value="todas">Todas as cidades</option>
            {cities.map((city) => (
              <option key={city.id} value={city.id}>
                {city.name}
              </option>
            ))}
          </select>
        </FilterField>

        <FilterField label="Vendedor">
          <select
            className={controlClass}
            onChange={(event) =>
              onChange({
                ...filters,
                sellerId: event.target.value === 'todos' ? null : event.target.value,
              })
            }
            value={filters.sellerId ?? 'todos'}
          >
            <option value="todos">Todos os vendedores</option>
            {options.sellers.map((seller) => (
              <option key={seller.id} value={seller.id}>
                {seller.name}
              </option>
            ))}
          </select>
        </FilterField>

        <FilterField label="Origem">
          <select
            className={controlClass}
            onChange={(event) =>
              onChange({ ...filters, origin: event.target.value as SalesPeriodOriginFilter })
            }
            value={filters.origin}
          >
            <option value="todas">Todas as origens</option>
            <option value="indicacao">{salesPeriodOriginLabels.indicacao}</option>
            <option value="vendedores">{salesPeriodOriginLabels.vendedores}</option>
          </select>
        </FilterField>

        <FilterField label="Plano">
          <select
            className={controlClass}
            onChange={(event) =>
              onChange({
                ...filters,
                planName: event.target.value === 'todos' ? null : event.target.value,
              })
            }
            value={filters.planName ?? 'todos'}
          >
            <option value="todos">Todos os planos</option>
            {options.plans.map((plan) => (
              <option key={plan} value={plan}>
                {plan}
              </option>
            ))}
          </select>
        </FilterField>

        <FilterField label="Resultado comercial">
          <select
            className={controlClass}
            onChange={(event) =>
              onChange({
                ...filters,
                outcome: event.target.value as SalesPeriodCycleOutcomeFilter,
              })
            }
            value={filters.outcome}
          >
            <option value="todos">Todos os resultados</option>
            {OUTCOME_OPTIONS.map((outcome) => (
              <option key={outcome} value={outcome}>
                {salesPeriodCycleOutcomeLabels[outcome]}
              </option>
            ))}
          </select>
        </FilterField>
      </div>

      <div className="mt-2.5 flex flex-wrap items-center justify-between gap-2 border-t border-[var(--divider)] pt-2.5">
        {/* Data de apuração do mock, só informativa: a situação exibida é a
            desta data, e não a de hoje. O total de vendas iniciadas saiu daqui:
            ele já é o valor do primeiro card, e repeti-lo na faixa dos filtros
            só ocupava a linha. */}
        <p className="text-[11.5px] text-[var(--text-secondary)]">
          Situação em{' '}
          <b className="font-mono text-[var(--text-item)]">{formatIsoAsBrDate(referenceDate)}</b>
        </p>
        <button
          className="rounded-lg px-3 py-1.5 text-[11.5px] font-semibold text-[var(--accent)] transition hover:bg-[var(--hover-bg)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--accent)] disabled:cursor-default disabled:text-[var(--text-disabled)] disabled:hover:bg-transparent"
          disabled={isInitial}
          onClick={() => onChange(initialSalesPeriodCycleFilters())}
          type="button"
        >
          Limpar filtros
        </button>
      </div>
    </section>
  )
}

function FilterField({ children, label }: { children: ReactNode; label: string }) {
  return (
    <label className={fieldClass}>
      <span className="flex-none text-[var(--text-secondary)]">{label}</span>
      {children}
    </label>
  )
}
