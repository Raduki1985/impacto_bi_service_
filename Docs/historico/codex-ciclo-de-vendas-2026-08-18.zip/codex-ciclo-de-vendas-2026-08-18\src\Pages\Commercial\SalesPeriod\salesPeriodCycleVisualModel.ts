import type { Theme } from '../../../contexts/PreferencesContextCore'
import type { SalesPeriodCycleOutcome } from './salesPeriodCycleModel'

/**
 * Leitura visual do ciclo comercial de Vendas por Período.
 *
 * Existe para separar o que é aparência do que é regra: `salesPeriodCycleModel`
 * responde quantas vendas iniciaram, quantas ativaram e onde foram perdidas, e
 * não precisa saber em qual tom cada resultado é pintado nem qual é o tema
 * ativo. É por isso que o modelo analítico não depende de `Theme` e não guarda
 * valor hexadecimal nenhum.
 *
 * O alcance deste arquivo é esta página, e só ela. Os únicos templates visuais
 * consolidados do projeto hoje são os cards e gráficos de Comercial > Visão
 * Geral, que não são tocados aqui. A composição Situação das vendas ainda é
 * candidata a template: enquanto não for validada visualmente e aprovada, nada
 * daqui deve ser promovido a componente genérico, biblioteca compartilhada ou
 * padrão oficial do portal.
 */

/**
 * Tons semânticos da leitura do ciclo.
 *
 * São os cinco resultados derivados mais os dois agregados que a página mostra:
 * `iniciadas` é o total neutro do recorte e `chegaram-a-ativacao` é o ramo
 * positivo, que soma ativadas e churn.
 */
export type SalesPeriodCycleTone = SalesPeriodCycleOutcome | 'iniciadas' | 'chegaram-a-ativacao'

/**
 * Cor de cada tom, por tema.
 *
 * Fica em um lugar só, e não repetida em cada componente, pelo mesmo motivo de
 * `commercialCardColors`: indicadores, Situação das vendas e badge da tabela
 * precisam pintar o mesmo resultado com a mesma cor, e um valor duplicado
 * dessincroniza em silêncio.
 *
 * A cor é sólida e precisa alcançar contraste sozinha em cada superfície, então
 * claro e escuro não compartilham valor. Ela também nunca é o único portador de
 * significado: todo item exibido traz rótulo, contagem e percentual em texto.
 *
 * Semântica aprovada: ativação e continuidade em verde, fluxo em âmbar, perda
 * pré-ativação em vermelho, churn pós-ativação em violeta, ausência de
 * classificação em cinza e o total iniciado em neutro.
 */
export const salesPeriodCycleColors: Record<Theme, Record<SalesPeriodCycleTone, string>> = {
  light: {
    iniciadas: '#344054',
    'chegaram-a-ativacao': '#00844d',
    ativada: '#00844d',
    'em-fluxo': '#b45309',
    'perda-pre-ativacao': '#b51d38',
    'churn-pos-ativacao': '#6d28d9',
    'sem-classificacao': '#667085',
  },
  dark: {
    iniciadas: '#dfe5ec',
    'chegaram-a-ativacao': '#34d399',
    ativada: '#34d399',
    'em-fluxo': '#f7ab24',
    'perda-pre-ativacao': '#ff8fa3',
    'churn-pos-ativacao': '#c4b5fd',
    'sem-classificacao': '#98a2b3',
  },
}
