/**
 * Ciclo comercial mockado de cada venda.
 *
 * DADOS SINTÉTICOS. Datas, motivos, modalidades, Ordens de Serviço e a
 * distribuição entre os casos existem apenas para exercitar as regras do ciclo.
 * Nada aqui foi extraído do SGI, do Sales ou do Voalle, e nenhum número
 * representa o comportamento real da Impacto Telecom.
 *
 * A base compartilhada (`mockCommercialData`) não é tocada: esta projeção lê as
 * vendas e devolve UM registro de ciclo por venda, vinculado por `saleId`. Os
 * indicadores de Visão Geral e de Metas e Desempenho continuam saindo dos mesmos
 * fatos de antes.
 *
 * Como a Data de Início foi separada da ativação compartilhada:
 *
 * - `startDate` é um campo próprio do ciclo. Para a venda que ativou, ele
 *   coincide com a data de ativação da base, seguindo a convenção informada
 *   pelos DEVs de que início e ativação nascem iguais no protótipo. Para a venda
 *   que ainda não ativou, ele vem da assinatura ou da criação, porque a venda em
 *   fluxo TEM início e não tem ativação;
 * - `activatedAt` continua sendo um campo distinto, preenchido somente quando
 *   houve ativação. Coincidir de valor não é ser o mesmo campo: a página futura
 *   pode passar a receber `startsAt` do Sales sem que nada mais mude aqui.
 *
 * Tudo é determinístico. A mesma venda recebe sempre o mesmo ciclo: cada
 * atributo sai de um hash do identificador dela, e nunca da posição na coleção
 * nem de `Math.random()`.
 */

import { addDays } from './commercialCalendar'
import type {
  CommercialActivationMode,
  CommercialCycleServiceOrder,
  CommercialCycleServiceOrderKind,
  CommercialCycleServiceOrderOutcome,
  CommercialLossReason,
  CommercialSaleCycle,
} from './commercialCycleTypes'
import type { CommercialSale, CommercialSaleStatus } from './commercialTypes'
import { commercialInstallationOf } from './mockCommercialInstallations'

/** Semente fixa do ciclo. Trocá-la muda todos os detalhes sintéticos. */
const CYCLE_SEED = 'impacto-ciclo-comercial-2026'

/** Hash FNV-1a, o mesmo padrão determinístico já usado na base comercial. */
function seedFrom(text: string): number {
  let hash = 2166136261

  for (let index = 0; index < text.length; index += 1) {
    hash ^= text.charCodeAt(index)
    hash = Math.imul(hash, 16777619)
  }

  return hash >>> 0
}

/**
 * Sorteio estável de um atributo.
 *
 * `salt` separa os atributos entre si, para modalidade, cobrança, prazo e OS não
 * ficarem correlacionados por acidente. Depende só do identificador da venda,
 * então reordenar a coleção não muda nenhum ciclo.
 */
function bucketOf(saleId: string, salt: string, size: number): number {
  return seedFrom(`${CYCLE_SEED}:${salt}:${saleId}`) % size
}

/**
 * Forma do ciclo, decidida pelo status atual da venda.
 *
 * Não é a classificação comercial: é apenas qual conjunto de eventos o mock
 * precisa produzir. A classificação continua sendo derivada por função pura, a
 * partir das datas e do status resultantes.
 */
type CycleShape = 'ativada' | 'em-fluxo' | 'perda-pre-ativacao' | 'churn' | 'sem-eventos'

/** Status que, na base, já nascem com ativação. */
const ACTIVATED_STATUSES: ReadonlySet<CommercialSaleStatus> = new Set([
  'ativa',
  'suspensa',
  'bloqueio-administrativo',
  'bloqueio-financeiro',
])

/** Status de venda que começou e ainda não ativou nem foi cancelada. */
const FLOW_STATUSES: ReadonlySet<CommercialSaleStatus> = new Set([
  'pendente',
  'assinada',
  'agendada',
  'aguardando-aprovacao',
  'nao-sincronizada',
])

/**
 * Parte das vendas canceladas do mock recebe ativação anterior, para existir
 * churn de coorte de verdade. A base compartilhada não distingue os dois casos,
 * e criar essa distinção nela mudaria os números das outras páginas.
 */
function isChurnCandidate(saleId: string): boolean {
  return bucketOf(saleId, 'churn', 3) === 0
}

function shapeOf(sale: CommercialSale): CycleShape {
  if (ACTIVATED_STATUSES.has(sale.status)) return 'ativada'
  if (FLOW_STATUSES.has(sale.status)) return 'em-fluxo'
  if (sale.status === 'reprovada') return 'perda-pre-ativacao'
  if (sale.status === 'cancelada') {
    return isChurnCandidate(sale.id) ? 'churn' : 'perda-pre-ativacao'
  }

  // Expirada: sem regra de negócio aprovada, então o ciclo não inventa evento.
  return 'sem-eventos'
}

/**
 * Data de Início do ciclo.
 *
 * A venda ativada começa no dia da ativação, conforme a convenção do protótipo.
 * A venda que nunca ativou começa na assinatura, ou na criação quando não houve
 * assinatura: ela tem início mesmo sem ativação, e é esse início que a coloca no
 * período.
 */
function startDateOf(sale: CommercialSale): string {
  return sale.activatedAt ?? sale.signedAt ?? sale.createdAt
}

/** Prazos sintéticos entre o início e o cancelamento, em dias corridos. */
const CANCELLATION_DELAYS = [5, 9, 14, 21, 33, 47, 68, 96] as const

/**
 * Data de cancelamento.
 *
 * Sempre posterior ou igual ao início, e nunca depois da data de apuração: o
 * mock não projeta evento que ainda não aconteceu. O prazo é longo de propósito,
 * para existir venda iniciada em um mês e cancelada no mês seguinte, que precisa
 * continuar pertencendo ao mês do início.
 */
function cancellationDateOf(saleId: string, startDate: string, referenceDate: string): string {
  const delay =
    CANCELLATION_DELAYS[bucketOf(saleId, 'prazo-cancelamento', CANCELLATION_DELAYS.length)]
  const canceledAt = addDays(startDate, delay)

  return canceledAt > referenceDate ? referenceDate : canceledAt
}

function activationModeOf(saleId: string): CommercialActivationMode {
  const bucket = bucketOf(saleId, 'modalidade', 100)

  if (bucket < 55) return 'instalacao-fisica'
  if (bucket < 80) return 'ativacao-remota'
  if (bucket < 93) return 'sem-intervencao-tecnica'

  return 'nao-identificada'
}

/**
 * Evidência explícita de que a venda não contratou serviço de instalação.
 *
 * Exige as duas condições: nenhuma cobrança registrada E a marcação sintética
 * deste recorte. Ausência de registro sozinha continua sendo `sem-dado`, e não
 * vira `nao-aplicavel`.
 */
function hasInstallationServiceOf(saleId: string): boolean {
  if (commercialInstallationOf(saleId) !== null) return true

  return bucketOf(saleId, 'servico-instalacao', 5) !== 0
}

/**
 * Motivo da perda.
 *
 * Depende apenas da forma do ciclo e do status. Não olha nenhuma OS: tentativa
 * improdutiva não pode virar causa de cancelamento sem motivo explícito.
 * `duplicidade` só aparece antes da ativação, que é onde a duplicidade é
 * detectada no mock.
 */
function lossReasonOf(sale: CommercialSale, shape: CycleShape): CommercialLossReason | null {
  if (shape === 'perda-pre-ativacao') {
    if (sale.status === 'reprovada') return 'nao-informado'

    const bucket = bucketOf(sale.id, 'motivo-perda', 10)
    if (bucket < 4) return 'duplicidade'

    return bucket < 8 ? 'cancelamento-de-contrato' : 'nao-informado'
  }

  if (shape === 'churn') {
    return bucketOf(sale.id, 'motivo-churn', 10) < 7 ? 'cancelamento-de-contrato' : 'nao-informado'
  }

  return null
}

/** OS que a modalidade justifica. Sem intervenção e sem identificação não geram. */
function relatedOrderKindOf(mode: CommercialActivationMode): CommercialCycleServiceOrderKind | null {
  if (mode === 'instalacao-fisica') return 'instalacao'
  if (mode === 'ativacao-remota') return 'ativacao-remota'

  return null
}

/**
 * Desfechos das tentativas relacionadas à ativação inicial, na ordem.
 *
 * A venda ativada pode ter tentado mais de uma vez antes de concluir; a venda em
 * fluxo pode ter uma tentativa improdutiva e outra pendente, ou só a improdutiva,
 * e continua em fluxo nos dois casos; a perda pode ter terminado sem conclusão.
 */
function relatedOutcomesOf(
  saleId: string,
  shape: CycleShape,
): readonly CommercialCycleServiceOrderOutcome[] {
  if (shape === 'ativada' || shape === 'churn') {
    const bucket = bucketOf(saleId, 'os-ativada', 10)
    if (bucket < 6) return ['concluida']
    if (bucket < 9) return ['improdutiva', 'concluida']

    return ['improdutiva', 'improdutiva', 'concluida']
  }

  if (shape === 'em-fluxo') {
    const bucket = bucketOf(saleId, 'os-fluxo', 10)
    if (bucket < 3) return []
    if (bucket < 6) return ['pendente']
    if (bucket < 8) return ['improdutiva', 'pendente']

    return ['improdutiva']
  }

  if (shape === 'perda-pre-ativacao') {
    const bucket = bucketOf(saleId, 'os-perda', 10)
    if (bucket < 4) return []
    if (bucket < 7) return ['encerrada-sem-conclusao']

    return ['improdutiva', 'encerrada-sem-conclusao']
  }

  return bucketOf(saleId, 'os-sem-eventos', 10) < 5 ? [] : ['encerrada-sem-conclusao']
}

/** Código sintético da OS, derivado do identificador da venda. */
function serviceOrderCodeOf(saleId: string, position: number): string {
  return `${saleId.replace(/^VD-/, 'OS-')}-${position + 1}`
}

/**
 * OS resumidas da venda.
 *
 * Uma parte das vendas também recebe uma OS de outro assunto, concluída. Ela
 * existe justamente para provar que uma OS não relacionada à ativação inicial
 * não define a execução da instalação, mesmo sendo o desfecho mais forte.
 */
function buildServiceOrders(
  saleId: string,
  shape: CycleShape,
  mode: CommercialActivationMode,
): CommercialCycleServiceOrder[] {
  const relatedKind = relatedOrderKindOf(mode)
  const orders: CommercialCycleServiceOrder[] =
    relatedKind === null
      ? []
      : relatedOutcomesOf(saleId, shape).map((outcome, index) => ({
          code: serviceOrderCodeOf(saleId, index),
          kind: relatedKind,
          outcome,
        }))

  if (bucketOf(saleId, 'os-nao-relacionada', 8) === 0) {
    orders.push({
      code: serviceOrderCodeOf(saleId, orders.length),
      kind: 'nao-relacionada',
      outcome: 'concluida',
    })
  }

  return orders
}

/**
 * Ciclo comercial de uma venda. Puro e estável.
 *
 * A ativação, quando existe, coincide com a Data de Início, conforme a convenção
 * do protótipo. Os dois campos continuam separados no tipo, e nenhuma regra do
 * ciclo lê um no lugar do outro.
 */
export function commercialSaleCycleOf(
  sale: CommercialSale,
  referenceDate: string,
): CommercialSaleCycle {
  const shape = shapeOf(sale)
  const startDate = startDateOf(sale)
  const activated = shape === 'ativada' || shape === 'churn'
  const canceled =
    shape === 'churn' || (shape === 'perda-pre-ativacao' && sale.status === 'cancelada')
  const activationMode = activationModeOf(sale.id)

  return {
    saleId: sale.id,
    startDate,
    activatedAt: activated ? startDate : null,
    canceledAt: canceled ? cancellationDateOf(sale.id, startDate, referenceDate) : null,
    status: sale.status,
    lossReason: lossReasonOf(sale, shape),
    activationMode,
    hasInstallationService: hasInstallationServiceOf(sale.id),
    serviceOrders: buildServiceOrders(sale.id, shape, activationMode),
    referenceDate,
  }
}

/** Um ciclo por venda, na mesma ordem recebida. Nenhuma venda é duplicada. */
export function buildCommercialSaleCycles(
  sales: readonly CommercialSale[],
  referenceDate: string,
): CommercialSaleCycle[] {
  return sales.map((sale) => commercialSaleCycleOf(sale, referenceDate))
}
