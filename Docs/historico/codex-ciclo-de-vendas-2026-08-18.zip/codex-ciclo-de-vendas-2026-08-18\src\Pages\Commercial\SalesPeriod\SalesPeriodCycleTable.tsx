import type { Theme } from '../../../contexts/PreferencesContextCore'
import { formatIsoAsBrDate } from '../../../data/commercialCalendar'
import { formatNumber } from '../../../lib/formatters'
import { SalesPeriodCycleOutcomeBadge } from './SalesPeriodCycleSituation'
import {
  buildSalesPeriodCyclePage,
  commercialActivationModeLabels,
  commercialCycleExecutionLabels,
  commercialInstallationChargeLabels,
  type SalesPeriodCyclePage,
  type SalesPeriodCycleRecord,
} from './salesPeriodCycleModel'
import { commercialSaleStatusLabels, salesPeriodOriginLabels } from './salesPeriodModel'

/**
 * Detalhamento das vendas iniciadas no período.
 *
 * É a tabela do CICLO, e não a das vendas exclusivamente ativas: cada linha é
 * uma venda iniciada no recorte, em qualquer resultado comercial. Uma venda com
 * três Ordens de Serviço continua sendo uma linha, porque a granularidade é a
 * venda.
 *
 * O acabamento é o da tabela anterior do bloco: mesma densidade de linha, mesma
 * tipografia, mesmo cabeçalho em versalete, mesmas divisórias, células
 * alinhadas ao meio, rolagem lateral dentro do próprio painel e painel ocupando
 * a largura disponível. O que mudou foi o conteúdo, e não a linguagem visual.
 *
 * Nada de operação técnica aparece aqui: técnico, agenda, equipamentos, rota,
 * produtividade e observações pertencem ao domínio de Ordens de Serviço. Deste
 * bloco entram apenas as três leituras independentes do ciclo, que são
 * modalidade para ativação, execução resumida e cobrança da instalação.
 *
 * Ordenação, filtro por coluna, painel lateral e navegação para a assinatura ou
 * para a OS ficam fora deste bloco de propósito: um ícone de filtro sem
 * comportamento implementado é pior do que a ausência dele.
 */

/**
 * Larguras das dez colunas.
 *
 * Percentuais com `table-fixed`, no mesmo padrão da tabela anterior: as
 * proporções não dependem do conteúdo da página exibida, então uma coluna tem a
 * mesma largura na primeira e na última página. O `min-width` garante o mínimo
 * legível e joga o excedente para a rolagem lateral do próprio contêiner.
 */
const COLUMN_WIDTHS = ['8%', '13%', '12%', '12%', '11%', '9%', '7%', '8%', '11%', '9%'] as const

/**
 * Altura de linha e de cabeçalho, iguais às da tabela anterior.
 *
 * As células de duas linhas cabem em 48px porque a segunda linha é de apoio, em
 * 10px: é a mesma composição que Cliente e CPF já usavam.
 */
const ROW_HEIGHT = 48
const HEADER_HEIGHT = 40
const VISIBLE_ROWS = 10

const panelClass =
  'min-w-0 rounded-xl border border-[var(--border)] bg-[var(--surface)] px-[18px] py-4'
const headerCellClass =
  'px-2 py-2 align-middle text-[10px] font-bold uppercase tracking-[0.45px] text-[var(--text-secondary)]'
const cellClass = 'px-2 align-middle'
const primaryLineClass = 'truncate font-semibold leading-tight text-[var(--text-item)]'

const paginationButtonClass =
  'rounded-lg border border-[var(--border)] px-3 py-1.5 text-[11.5px] font-semibold text-[var(--text-item)] transition hover:bg-[var(--hover-bg)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--accent)] disabled:cursor-default disabled:text-[var(--text-disabled)] disabled:hover:bg-transparent'

export function SalesPeriodCycleTable({
  onPageChange,
  page,
  records,
  theme,
}: {
  onPageChange: (page: number) => void
  page: number
  records: readonly SalesPeriodCycleRecord[]
  theme: Theme
}) {
  const slice = buildSalesPeriodCyclePage(records, page)

  return (
    <section aria-labelledby="vendas-iniciadas-detalhe" className={panelClass}>
      <h2
        className="text-[13.5px] font-semibold text-[var(--text-heading)]"
        id="vendas-iniciadas-detalhe"
      >
        Detalhamento das vendas iniciadas
      </h2>
      <p className="mt-0.5 text-[12px] leading-[1.45] text-[var(--text-secondary)]">
        Um registro por venda, com os mesmos filtros dos indicadores, dos gráficos e da Situação
        das vendas. Várias Ordens de Serviço não criam linhas novas.
      </p>

      {slice.total === 0 ? (
        <div className="mt-3 flex min-h-[180px] flex-col items-center justify-center gap-1.5 rounded-lg border border-dashed border-[var(--border)] px-5 text-center text-[12px] text-[var(--text-secondary)]">
          <p>Nenhuma venda iniciada corresponde aos filtros selecionados.</p>
          <p className="text-[11.5px]">
            Limpe os filtros ou amplie o período para voltar ao recorte inicial.
          </p>
        </div>
      ) : (
        <>
          {/* A rolagem lateral fica só na tabela: o corpo da página nunca rola
              na horizontal, nem no celular. A altura mínima equivale a dez
              linhas mais o cabeçalho, então a última página, mesmo curta, não
              encolhe o painel nem move a paginação. */}
          <div
            className="mt-3 overflow-x-auto"
            style={{ minHeight: HEADER_HEIGHT + ROW_HEIGHT * VISIBLE_ROWS }}
          >
            <table className="w-full min-w-[1320px] table-fixed border-collapse text-left text-[11.5px]">
              <colgroup>
                {COLUMN_WIDTHS.map((width, index) => (
                  <col key={index} style={{ width }} />
                ))}
              </colgroup>
              <thead>
                <tr className="border-b border-[var(--divider)]" style={{ height: HEADER_HEIGHT }}>
                  <th className={headerCellClass} scope="col">
                    Data de Início
                  </th>
                  <th className={headerCellClass} scope="col">
                    Contrato e cliente
                  </th>
                  <th className={headerCellClass} scope="col">
                    Vendedor e origem
                  </th>
                  <th className={headerCellClass} scope="col">
                    Cidade e plano
                  </th>
                  <th className={headerCellClass} scope="col">
                    Resultado comercial
                  </th>
                  <th className={headerCellClass} scope="col">
                    Status atual
                  </th>
                  <th className={headerCellClass} scope="col">
                    Ativação
                  </th>
                  <th className={headerCellClass} scope="col">
                    Cancelamento
                  </th>
                  <th className={headerCellClass} scope="col">
                    Modalidade e execução
                  </th>
                  <th className={headerCellClass} scope="col">
                    Cobrança da instalação
                  </th>
                </tr>
              </thead>
              <tbody>
                {slice.records.map((record) => (
                  <tr
                    className="border-b border-[var(--divider)] last:border-0"
                    key={record.saleId}
                    style={{ height: ROW_HEIGHT }}
                  >
                    <td className={`${cellClass} truncate font-mono text-[var(--text-secondary)]`}>
                      {formatIsoAsBrDate(record.startDate)}
                    </td>
                    <td className={cellClass}>
                      <p className="truncate font-mono font-semibold leading-tight text-[var(--text-item)]">
                        {record.contractCode}
                      </p>
                      <p
                        className="truncate text-[10px] leading-tight text-[var(--text-secondary)]"
                        title={record.customerLabel}
                      >
                        {record.customerLabel}
                      </p>
                    </td>
                    <td className={cellClass}>
                      <p className={primaryLineClass} title={record.sellerName}>
                        {record.sellerName}
                      </p>
                      <p className="truncate text-[10px] leading-tight text-[var(--text-secondary)]">
                        {salesPeriodOriginLabels[record.origin]}
                      </p>
                    </td>
                    <td className={cellClass}>
                      <p
                        className="truncate leading-tight text-[var(--text-item)]"
                        title={record.cityName}
                      >
                        {record.cityName}
                      </p>
                      <p
                        className="truncate text-[10px] leading-tight text-[var(--text-secondary)]"
                        title={record.planName}
                      >
                        {record.planName}
                      </p>
                    </td>
                    <td className={cellClass}>
                      <SalesPeriodCycleOutcomeBadge outcome={record.outcome} theme={theme} />
                    </td>
                    <td className={`${cellClass} truncate text-[var(--text-item)]`}>
                      {commercialSaleStatusLabels[record.status]}
                    </td>
                    <td className={`${cellClass} text-[var(--text-secondary)]`}>
                      <EventDate date={record.activatedAt} missing="Ainda não ativada" />
                    </td>
                    <td className={`${cellClass} text-[var(--text-secondary)]`}>
                      <EventDate date={record.canceledAt} missing="Sem cancelamento" />
                    </td>
                    <td className={cellClass}>
                      <p className={primaryLineClass}>
                        {commercialActivationModeLabels[record.activationMode]}
                      </p>
                      <p className="truncate text-[10px] leading-tight text-[var(--text-secondary)]">
                        Execução: {commercialCycleExecutionLabels[record.execution]}
                      </p>
                    </td>
                    <td className={`${cellClass} truncate text-[var(--text-secondary)]`}>
                      Cobrança: {commercialInstallationChargeLabels[record.installationCharge]}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <TablePagination onPageChange={onPageChange} slice={slice} />
        </>
      )}
    </section>
  )
}

/**
 * Data de um evento do ciclo.
 *
 * Ausência tem texto próprio: uma venda ainda não ativada não recebe traço nem
 * data vazia, porque "ainda não aconteceu" é informação, e não falta de dado.
 */
function EventDate({ date, missing }: { date: string | null; missing: string }) {
  if (date === null) {
    return <span className="block truncate text-[10px] leading-tight">{missing}</span>
  }

  return <span className="block truncate font-mono">{formatIsoAsBrDate(date)}</span>
}

function TablePagination({
  onPageChange,
  slice,
}: {
  onPageChange: (page: number) => void
  slice: SalesPeriodCyclePage
}) {
  return (
    <nav
      aria-label="Paginação do detalhamento das vendas iniciadas"
      className="mt-3 flex flex-wrap items-center justify-between gap-3 border-t border-[var(--divider)] pt-3"
    >
      <p aria-live="polite" className="text-[11.5px] text-[var(--text-secondary)]">
        Mostrando <b className="font-mono text-[var(--text-item)]">{formatNumber(slice.from)}</b> a{' '}
        <b className="font-mono text-[var(--text-item)]">{formatNumber(slice.to)}</b> de{' '}
        <b className="font-mono text-[var(--text-item)]">{formatNumber(slice.total)}</b>{' '}
        {slice.total === 1 ? 'venda iniciada' : 'vendas iniciadas'}
      </p>
      <div className="flex items-center gap-2">
        <button
          className={paginationButtonClass}
          disabled={slice.page === 0}
          onClick={() => onPageChange(slice.page - 1)}
          type="button"
        >
          Anterior
        </button>
        <span className="text-[11.5px] text-[var(--text-secondary)]">
          Página <b className="font-mono text-[var(--text-item)]">{slice.page + 1}</b> de{' '}
          <b className="font-mono text-[var(--text-item)]">{slice.totalPages}</b>
        </span>
        <button
          className={paginationButtonClass}
          disabled={slice.page >= slice.totalPages - 1}
          onClick={() => onPageChange(slice.page + 1)}
          type="button"
        >
          Próxima
        </button>
      </div>
    </nav>
  )
}
