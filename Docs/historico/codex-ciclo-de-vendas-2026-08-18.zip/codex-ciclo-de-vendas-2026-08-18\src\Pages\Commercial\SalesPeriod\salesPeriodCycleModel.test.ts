import { describe, expect, it, vi } from 'vitest'

import { monthKeyOf } from '../../../data/commercialCalendar'
import type { CommercialSaleCycle } from '../../../data/commercialCycleTypes'
import type { CommercialDataset } from '../../../data/commercialTypes'
import { getCommercialDataset } from '../../../data/mockCommercialData'
import { buildCommercialSaleCycles, commercialSaleCycleOf } from '../../../data/mockCommercialCycles'
import { commercialInstallationOf } from '../../../data/mockCommercialInstallations'
import {
  SALES_PERIOD_CYCLE_PAGE_SIZE,
  buildSalesPeriodCycleDaily,
  buildSalesPeriodCycleOptions,
  buildSalesPeriodCycleOrigins,
  buildSalesPeriodCyclePage,
  buildSalesPeriodCycleRecords,
  buildSalesPeriodCycleSnapshot,
  classifySalesPeriodCycle,
  initialSalesPeriodCycleFilters,
  salesPeriodCycleExecutionOf,
  selectSalesPeriodCycleRecords,
  type SalesPeriodCycleFilters,
  type SalesPeriodCycleRecord,
} from './salesPeriodCycleModel'
import {
  buildActiveSalesSnapshot,
  buildSalesPeriodFacts,
  classifyCommercialInstallation,
  initialActiveSalesFilters,
  salesPeriodOriginOf,
} from './salesPeriodModel'

const dataset = getCommercialDataset()

/** Estado da base compartilhada ANTES de qualquer leitura do ciclo comercial. */
const salesBefore = JSON.stringify(dataset.sales)
const installationsBefore = JSON.stringify(dataset.installations)

const JULY = { periodStart: '2026-07-01', periodEnd: '2026-07-31' } as const
const JUNE = { periodStart: '2026-06-01', periodEnd: '2026-06-30' } as const

const records = buildSalesPeriodCycleRecords(dataset)
const recordsBySaleId = new Map(records.map((record) => [record.saleId, record]))

/** Filtros globais completos, com os valores neutros do padrão da página. */
function filtersOf(overrides: Partial<SalesPeriodCycleFilters> = {}): SalesPeriodCycleFilters {
  return { ...initialSalesPeriodCycleFilters(), ...overrides }
}

function snapshotOf(overrides: Partial<SalesPeriodCycleFilters> = JULY) {
  return buildSalesPeriodCycleSnapshot(dataset, filtersOf(overrides))
}

/** Ciclo coerente mínimo, para os casos construídos à mão. */
const baseCycle: CommercialSaleCycle = {
  saleId: 'VD-2026-00001',
  startDate: '2026-07-01',
  activatedAt: null,
  canceledAt: null,
  status: 'pendente',
  lossReason: null,
  activationMode: 'instalacao-fisica',
  hasInstallationService: true,
  serviceOrders: [],
  referenceDate: '2026-07-31',
}

function cycleWith(overrides: Partial<CommercialSaleCycle>): CommercialSaleCycle {
  return { ...baseCycle, ...overrides }
}

function outcomeOf(overrides: Partial<CommercialSaleCycle>) {
  return classifySalesPeriodCycle(cycleWith(overrides)).outcome
}

/* -------------------------------------------------------------------------- */
/* Granularidade e determinismo                                               */
/* -------------------------------------------------------------------------- */

describe('projeção isolada do ciclo comercial', () => {
  it('cria exatamente um registro por venda, vinculado por saleId', () => {
    const saleIds = new Set(dataset.sales.map((sale) => sale.id))

    expect(records).toHaveLength(dataset.sales.length)
    expect(recordsBySaleId.size).toBe(dataset.sales.length)
    records.forEach((record) => expect(saleIds.has(record.saleId)).toBe(true))
  })

  it('não duplica a venda quando existem várias OS relacionadas', () => {
    const comVariasOs = records.filter((record) => record.serviceOrders.length > 1)

    expect(comVariasOs.length).toBeGreaterThan(0)
    // Uma linha por venda mesmo com três OS, e os códigos de OS são distintos.
    comVariasOs.forEach((record) => {
      const codes = new Set(record.serviceOrders.map((order) => order.code))
      expect(codes.size).toBe(record.serviceOrders.length)
    })
    expect(new Set(comVariasOs.map((record) => record.saleId)).size).toBe(comVariasOs.length)
  })

  it('devolve o mesmo ciclo em toda execução e em qualquer ordem da coleção', () => {
    const primeira = buildCommercialSaleCycles(dataset.sales, dataset.referenceDate)
    const segunda = buildCommercialSaleCycles(dataset.sales, dataset.referenceDate)
    const invertida = new Map(
      buildCommercialSaleCycles([...dataset.sales].reverse(), dataset.referenceDate).map(
        (cycle) => [cycle.saleId, cycle],
      ),
    )

    expect(primeira).toEqual(segunda)
    primeira.forEach((cycle) => expect(invertida.get(cycle.saleId)).toEqual(cycle))
    // A venda isolada recebe o mesmo ciclo que recebe dentro da coleção.
    const [sale] = dataset.sales
    expect(commercialSaleCycleOf(sale, dataset.referenceDate)).toEqual(primeira[0])
  })

  it('mantém a base compartilhada intacta e os números atuais das outras páginas', () => {
    const ativas = buildActiveSalesSnapshot(dataset, initialActiveSalesFilters())

    expect(JSON.stringify(dataset.sales)).toBe(salesBefore)
    expect(JSON.stringify(dataset.installations)).toBe(installationsBefore)
    // Julho continua com as mesmas 883 vendas ativas do bloco já existente.
    expect(ativas.metrics.activeSales).toBe(883)
  })
})

/* -------------------------------------------------------------------------- */
/* Data de Início                                                             */
/* -------------------------------------------------------------------------- */

describe('Data de Início como único critério de período', () => {
  it('seleciona somente pela Data de Início, sem olhar ativação ou cancelamento', () => {
    const snapshot = snapshotOf()

    expect(snapshot.records.length).toBeGreaterThan(0)
    snapshot.records.forEach((record) => {
      expect(record.startDate >= JULY.periodStart).toBe(true)
      expect(record.startDate <= JULY.periodEnd).toBe(true)
    })
    expect(snapshot.metrics.startedSales).toBe(snapshot.records.length)
  })

  it('mantém em junho a venda iniciada em junho e cancelada em julho', () => {
    const june = new Set(snapshotOf(JUNE).records.map((record) => record.saleId))
    const july = new Set(snapshotOf().records.map((record) => record.saleId))
    const atravessam = records.filter(
      (record) =>
        record.canceledAt !== null &&
        monthKeyOf(record.startDate) === '2026-06' &&
        monthKeyOf(record.canceledAt) === '2026-07',
    )

    expect(atravessam.length).toBeGreaterThan(0)
    atravessam.forEach((record) => {
      expect(june.has(record.saleId)).toBe(true)
      expect(july.has(record.saleId)).toBe(false)
    })
  })

  it('separa semanticamente início, ativação e cancelamento', () => {
    const emFluxo = records.filter((record) => record.outcome === 'em-fluxo')
    const churn = records.filter((record) => record.outcome === 'churn-pos-ativacao')

    // Venda em fluxo tem início e não tem ativação nem cancelamento.
    expect(emFluxo.length).toBeGreaterThan(0)
    emFluxo.forEach((record) => {
      expect(record.startDate.length).toBe(10)
      expect(record.activatedAt).toBeNull()
      expect(record.canceledAt).toBeNull()
    })

    // Churn tem os três eventos, com o cancelamento depois da ativação.
    expect(churn.length).toBeGreaterThan(0)
    churn.forEach((record) => {
      expect(record.activatedAt).not.toBeNull()
      expect(record.canceledAt).not.toBeNull()
      expect(record.canceledAt! >= record.activatedAt!).toBe(true)
    })
  })

  it('não projeta evento depois da data de apuração', () => {
    records.forEach((record) => {
      expect(record.referenceDate).toBe(dataset.referenceDate)
      expect(record.startDate <= record.referenceDate).toBe(true)
      if (record.activatedAt !== null) expect(record.activatedAt <= record.referenceDate).toBe(true)
      if (record.canceledAt !== null) expect(record.canceledAt <= record.referenceDate).toBe(true)
    })
  })

  it('ordena por Data de Início decrescente com desempate estável', () => {
    const ordenados = snapshotOf().records

    for (let index = 1; index < ordenados.length; index += 1) {
      const anterior = ordenados[index - 1]
      const atual = ordenados[index]

      expect(anterior.startDate >= atual.startDate).toBe(true)
      if (anterior.startDate === atual.startDate) {
        expect(anterior.saleId > atual.saleId).toBe(true)
      }
    }
  })
})

/* -------------------------------------------------------------------------- */
/* Classificação comercial                                                    */
/* -------------------------------------------------------------------------- */

describe('classificação comercial derivada', () => {
  it('trata como ainda em fluxo os status sem ativação e sem cancelamento', () => {
    ;(
      ['pendente', 'assinada', 'agendada', 'aguardando-aprovacao', 'nao-sincronizada'] as const
    ).forEach((status) => expect(outcomeOf({ status })).toBe('em-fluxo'))
  })

  it('trata reprovada e cancelada sem ativação como perda pré-ativação', () => {
    expect(outcomeOf({ status: 'reprovada', lossReason: 'nao-informado' })).toBe(
      'perda-pre-ativacao',
    )
    expect(
      outcomeOf({ status: 'cancelada', canceledAt: '2026-07-10', lossReason: 'duplicidade' }),
    ).toBe('perda-pre-ativacao')
  })

  it('trata cancelada com ativação anterior como churn pós-ativação', () => {
    expect(
      outcomeOf({
        status: 'cancelada',
        activatedAt: '2026-07-01',
        canceledAt: '2026-07-20',
        lossReason: 'cancelamento-de-contrato',
      }),
    ).toBe('churn-pos-ativacao')
  })

  it('trata ativa, suspensa e bloqueios com ativação como ativada', () => {
    ;(['ativa', 'suspensa', 'bloqueio-administrativo', 'bloqueio-financeiro'] as const).forEach(
      (status) => expect(outcomeOf({ status, activatedAt: '2026-07-01' })).toBe('ativada'),
    )
  })

  it('deixa Expirada sem classificação, e sem erro de qualidade', () => {
    const classificacao = classifySalesPeriodCycle(cycleWith({ status: 'expirada' }))

    expect(classificacao.outcome).toBe('sem-classificacao')
    expect(classificacao.issue).toBeNull()
  })

  it('não corrige registro temporalmente impossível', () => {
    const impossiveis: readonly [Partial<CommercialSaleCycle>, string][] = [
      [
        {
          status: 'cancelada',
          activatedAt: '2026-07-20',
          canceledAt: '2026-07-05',
          lossReason: 'cancelamento-de-contrato',
        },
        'cancelamento-anterior-a-ativacao',
      ],
      [{ status: 'ativa', activatedAt: '2026-06-25' }, 'ativacao-anterior-ao-inicio'],
      [
        { status: 'cancelada', canceledAt: '2026-06-25', lossReason: 'duplicidade' },
        'cancelamento-anterior-ao-inicio',
      ],
    ]

    impossiveis.forEach(([overrides, issue]) => {
      const classificacao = classifySalesPeriodCycle(cycleWith(overrides))

      expect(classificacao.outcome).toBe('sem-classificacao')
      expect(classificacao.issue).toBe(issue)
    })
  })

  it('nomeia a incoerência entre status e eventos em vez de escolher categoria plausível', () => {
    const incoerentes: readonly [Partial<CommercialSaleCycle>, string][] = [
      [{ status: 'ativa' }, 'ativacao-ausente'],
      [
        { status: 'ativa', activatedAt: '2026-07-01', canceledAt: '2026-07-09' },
        'cancelamento-em-status-ativo',
      ],
      [{ status: 'pendente', activatedAt: '2026-07-01' }, 'ativacao-em-status-de-fluxo'],
      [
        { status: 'assinada', canceledAt: '2026-07-09', lossReason: 'duplicidade' },
        'cancelamento-em-status-de-fluxo',
      ],
      [{ status: 'cancelada', lossReason: 'duplicidade' }, 'cancelamento-ausente'],
      [
        { status: 'reprovada', activatedAt: '2026-07-01', lossReason: 'nao-informado' },
        'reprovacao-com-ativacao',
      ],
      [
        { status: 'ativa', activatedAt: '2026-07-01', lossReason: 'duplicidade' },
        'motivo-de-perda-sem-perda',
      ],
      [{ status: 'cancelada', canceledAt: '2026-07-10' }, 'motivo-de-perda-ausente'],
    ]

    incoerentes.forEach(([overrides, issue]) => {
      const classificacao = classifySalesPeriodCycle(cycleWith(overrides))

      expect(classificacao.issue).toBe(issue)
      expect(classificacao.outcome).toBe('sem-classificacao')
    })
  })

  it('classifica a mesma venda sempre da mesma forma', () => {
    const [record] = records
    const cycle = commercialSaleCycleOf(dataset.sales[0], dataset.referenceDate)

    expect(classifySalesPeriodCycle(cycle)).toEqual(classifySalesPeriodCycle(cycle))
    expect(classifySalesPeriodCycle(cycle).outcome).toBe(record.outcome)
  })

  it('não produz nenhum erro de qualidade na base mockada', () => {
    expect(records.filter((record) => record.issue !== null)).toHaveLength(0)
    expect(snapshotOf().metrics.qualityIssues).toBe(0)
  })

  it('mantém o motivo de perda existente exatamente quando existe perda', () => {
    records.forEach((record) => {
      const perda =
        record.outcome === 'perda-pre-ativacao' || record.outcome === 'churn-pos-ativacao'

      expect(record.lossReason !== null).toBe(perda)
    })
  })
})

/* -------------------------------------------------------------------------- */
/* Indicadores da coorte                                                      */
/* -------------------------------------------------------------------------- */

describe('indicadores da coorte', () => {
  it('fecha as vendas iniciadas com a soma dos resultados', () => {
    const { metrics } = snapshotOf()

    expect(
      metrics.activated +
        metrics.inFlow +
        metrics.preActivationLosses +
        metrics.churn +
        metrics.unclassified,
    ).toBe(metrics.startedSales)
  })

  it('inclui em Chegaram à ativação as vendas que depois viraram churn', () => {
    const snapshot = snapshotOf()
    const { metrics } = snapshot
    const comAtivacao = snapshot.records.filter((record) => record.activatedAt !== null)

    expect(metrics.churn).toBeGreaterThan(0)
    expect(metrics.reachedActivation).toBe(metrics.activated + metrics.churn)
    expect(metrics.reachedActivation).toBe(comAtivacao.length)
    expect(metrics.reachedActivation).toBeGreaterThan(metrics.activated)
  })

  it('mede a chegada à ativação sobre as vendas iniciadas', () => {
    const { metrics } = snapshotOf()

    expect(metrics.activationShare).toBeCloseTo(
      metrics.reachedActivation / metrics.startedSales,
      10,
    )
    // O churn está dentro do numerador: a taxa de ativação não desconta quem
    // cancelou depois.
    expect(metrics.activationShare!).toBeGreaterThan(metrics.activated / metrics.startedSales)
    // Os quatro percentuais sobre vendas iniciadas fecham em 100%.
    expect(
      metrics.activationShare! +
        metrics.inFlowShare! +
        metrics.preActivationLossShare! +
        metrics.unclassified / metrics.startedSales,
    ).toBeCloseTo(1, 10)
  })

  it('usa vendas iniciadas em fluxo e perdas, e ativação no churn', () => {
    const { metrics } = snapshotOf()

    expect(metrics.inFlowShare).toBeCloseTo(metrics.inFlow / metrics.startedSales, 10)
    expect(metrics.preActivationLossShare).toBeCloseTo(
      metrics.preActivationLosses / metrics.startedSales,
      10,
    )
    expect(metrics.churnShare).toBeCloseTo(metrics.churn / metrics.reachedActivation, 10)
    // Impacto na coorte é a mesma contagem sobre outro denominador.
    expect(metrics.churnCohortImpact).toBeCloseTo(metrics.churn / metrics.startedSales, 10)
    expect(metrics.churnShare!).toBeGreaterThan(metrics.churnCohortImpact!)
  })

  it('não inventa percentual em recorte sem venda iniciada', () => {
    const { metrics } = snapshotOf({ periodStart: '2026-07-01', periodEnd: '2026-07-01' })
    const vazio = snapshotOf({ periodStart: '2026-08-01', periodEnd: '2026-08-31' }).metrics

    expect(metrics.startedSales).toBeGreaterThan(0)
    expect(vazio.startedSales).toBe(0)
    expect(vazio.reachedActivation).toBe(0)
    expect(vazio.activationShare).toBeNull()
    expect(vazio.inFlowShare).toBeNull()
    expect(vazio.preActivationLossShare).toBeNull()
    expect(vazio.churnShare).toBeNull()
    expect(vazio.churnCohortImpact).toBeNull()
  })

  it('começa no período padrão da página e com todos os demais filtros abertos', () => {
    expect(initialSalesPeriodCycleFilters()).toEqual({
      periodStart: '2026-07-01',
      periodEnd: '2026-07-31',
      cityId: null,
      sellerId: null,
      origin: 'todas',
      planName: null,
      outcome: 'todos',
    })
  })
})

/* -------------------------------------------------------------------------- */
/* Ligação com o fato comercial                                               */
/* -------------------------------------------------------------------------- */

describe('ligação com o fato comercial já usado pela página', () => {
  const facts = new Map(buildSalesPeriodFacts(dataset).map((fact) => [fact.id, fact]))

  it('reutiliza os atributos comerciais existentes, sem gerar dados novos', () => {
    expect(records.length).toBeGreaterThan(0)
    records.forEach((record) => {
      const fact = facts.get(record.saleId)

      expect(fact).toBeDefined()
      expect(record.contractCode).toBe(fact?.contractCode)
      expect(record.customerLabel).toBe(fact?.customerLabel)
      expect(record.sellerId).toBe(fact?.sellerId)
      expect(record.sellerName).toBe(fact?.sellerName)
      expect(record.cityId).toBe(fact?.cityId)
      expect(record.cityName).toBe(fact?.cityName)
      expect(record.planName).toBe(fact?.planName)
      expect(record.monthlyValue).toBe(fact?.monthlyValue)
      expect(record.origin).toBe(salesPeriodOriginOf(fact?.indicatorCpf ?? null))
    })
  })

  it('liga por saleId, e não pela posição dos arrays', () => {
    // A mesma base com as vendas em ordem invertida produz os mesmos registros.
    const invertidos = buildSalesPeriodCycleRecords({
      ...dataset,
      sales: [...dataset.sales].reverse(),
    })
    const porSaleId = new Map(invertidos.map((record) => [record.saleId, record]))

    expect(invertidos).toHaveLength(records.length)
    records.forEach((record) => expect(porSaleId.get(record.saleId)).toEqual(record))
  })

  it('não deixa nenhuma venda desaparecer na associação', () => {
    const recortes: readonly (typeof dataset.sales)[] = [
      dataset.sales,
      [...dataset.sales].reverse(),
      dataset.sales.slice(0, 25),
      dataset.sales.slice(-40),
    ]

    recortes.forEach((sales) => {
      const recorte = buildSalesPeriodCycleRecords({ ...dataset, sales })

      // O total acompanha as vendas, e o conjunto de identificadores é o mesmo.
      expect(recorte).toHaveLength(sales.length)
      expect(new Set(recorte.map((record) => record.saleId))).toEqual(
        new Set(sales.map((sale) => sale.id)),
      )
    })
  })

  it('interrompe com o saleId inconsistente quando falta o fato comercial', async () => {
    const perdida = dataset.sales[0].id

    vi.resetModules()
    // Única falha capaz de sumir com uma venda: o fato comercial dela deixar de
    // existir. Aqui ela é forçada, e só neste teste, para provar que a ausência
    // vira erro nomeado em vez de registro descartado em silêncio.
    vi.doMock('./salesPeriodModel', async (importOriginal) => {
      const actual = await importOriginal<typeof import('./salesPeriodModel')>()

      return {
        ...actual,
        buildSalesPeriodFacts: (base: CommercialDataset) =>
          actual.buildSalesPeriodFacts(base).filter((fact) => fact.id !== perdida),
      }
    })

    try {
      const { buildSalesPeriodCycleRecords: comFatoAusente } = await import(
        './salesPeriodCycleModel'
      )

      expect(() => comFatoAusente(dataset)).toThrowError(
        new RegExp(`Venda sem fato comercial correspondente no ciclo: ${perdida}`),
      )
    } finally {
      vi.doUnmock('./salesPeriodModel')
      vi.resetModules()
    }
  })

  it('preserva os campos do ciclo ao acrescentar os campos comerciais', () => {
    const cycles = new Map(
      buildCommercialSaleCycles(dataset.sales, dataset.referenceDate).map((cycle) => [
        cycle.saleId,
        cycle,
      ]),
    )

    records.forEach((record) => {
      const cycle = cycles.get(record.saleId)

      expect(record.startDate).toBe(cycle?.startDate)
      expect(record.activatedAt).toBe(cycle?.activatedAt ?? null)
      expect(record.canceledAt).toBe(cycle?.canceledAt ?? null)
      expect(record.status).toBe(cycle?.status)
      expect(record.lossReason).toBe(cycle?.lossReason ?? null)
      expect(record.activationMode).toBe(cycle?.activationMode)
      expect(record.serviceOrders).toEqual(cycle?.serviceOrders)
      expect(record.referenceDate).toBe(cycle?.referenceDate)
      expect(record.outcome).toBe(classifySalesPeriodCycle(cycle!).outcome)
    })
  })

  it('mantém a venda indicada com vendedora responsável e origem única', () => {
    const indicadas = records.filter((record) => record.origin === 'indicacao')

    expect(indicadas.length).toBeGreaterThan(0)
    indicadas.forEach((record) => {
      expect(record.sellerId.length).toBeGreaterThan(0)
      expect(record.sellerName.length).toBeGreaterThan(0)
    })
  })
})

/* -------------------------------------------------------------------------- */
/* Filtros globais                                                            */
/* -------------------------------------------------------------------------- */

describe('filtros globais das vendas iniciadas', () => {
  it('filtra pela cidade de instalação', () => {
    const snapshot = snapshotOf({ cityId: 'piracaia' })

    expect(snapshot.records.length).toBeGreaterThan(0)
    expect(snapshot.records.every((record) => record.cityId === 'piracaia')).toBe(true)
    expect(snapshot.records.every((record) => record.cityName === 'Piracaia')).toBe(true)
    expect(snapshot.metrics.startedSales).toBe(snapshot.records.length)
    expect(snapshot.metrics.startedSales).toBeLessThan(snapshotOf().metrics.startedSales)
  })

  it('filtra pelo vendedor responsável pela venda', () => {
    const sellerId = 'vnd-ana-maria'
    const snapshot = snapshotOf({ sellerId })

    expect(snapshot.records.length).toBeGreaterThan(0)
    expect(snapshot.records.every((record) => record.sellerId === sellerId)).toBe(true)
  })

  it('filtra por origem sem contar a mesma venda duas vezes', () => {
    const todas = snapshotOf()
    const indicacao = snapshotOf({ origin: 'indicacao' })
    const vendedores = snapshotOf({ origin: 'vendedores' })
    const indicacaoIds = new Set(indicacao.records.map((record) => record.saleId))

    expect(indicacao.records.length).toBeGreaterThan(0)
    expect(vendedores.records.length).toBeGreaterThan(0)
    expect(vendedores.records.some((record) => indicacaoIds.has(record.saleId))).toBe(false)
    expect(indicacao.metrics.startedSales + vendedores.metrics.startedSales).toBe(
      todas.metrics.startedSales,
    )
    // A venda indicada continua tendo vendedora, e mesmo assim não entra em Vendedores.
    expect(indicacao.records.every((record) => record.sellerId.length > 0)).toBe(true)
  })

  it('filtra por plano reaproveitando o plano sintético existente', () => {
    const planName = snapshotOf().records[0].planName
    const snapshot = snapshotOf({ planName })

    expect(snapshot.records.length).toBeGreaterThan(0)
    expect(snapshot.records.every((record) => record.planName === planName)).toBe(true)
  })

  it('filtra pelo resultado comercial já derivado, sem reclassificar a venda', () => {
    const todas = snapshotOf()
    const churn = snapshotOf({ outcome: 'churn-pos-ativacao' })
    const emFluxo = snapshotOf({ outcome: 'em-fluxo' })

    expect(churn.records.every((record) => record.outcome === 'churn-pos-ativacao')).toBe(true)
    expect(churn.records.length).toBe(todas.metrics.churn)
    expect(emFluxo.records.length).toBe(todas.metrics.inFlow)
    // Cada venda do recorte mantém exatamente a classificação que já tinha.
    churn.records.forEach((record) => {
      expect(recordsBySaleId.get(record.saleId)?.outcome).toBe('churn-pos-ativacao')
    })
  })

  it('combina os filtros como interseção, sem duplicar venda', () => {
    const cidade = snapshotOf({ cityId: 'atibaia' })
    const combinado = snapshotOf({ cityId: 'atibaia', origin: 'indicacao' })
    const ids = new Set(combinado.records.map((record) => record.saleId))

    expect(combinado.records.length).toBeGreaterThan(0)
    expect(combinado.records.length).toBeLessThan(cidade.records.length)
    expect(ids.size).toBe(combinado.records.length)
    expect(
      combinado.records.every(
        (record) => record.cityId === 'atibaia' && record.origin === 'indicacao',
      ),
    ).toBe(true)
  })

  it('recalcula todos os indicadores sobre o mesmo conjunto filtrado', () => {
    const snapshot = snapshotOf({ cityId: 'piracaia' })
    const { records: recorte, metrics } = snapshot
    const contaPorResultado = (outcome: SalesPeriodCycleRecord['outcome']) =>
      recorte.filter((record) => record.outcome === outcome).length
    const comAtivacao = recorte.filter((record) => record.activatedAt !== null).length

    expect(metrics.startedSales).toBe(recorte.length)
    expect(metrics.activated).toBe(contaPorResultado('ativada'))
    expect(metrics.inFlow).toBe(contaPorResultado('em-fluxo'))
    expect(metrics.preActivationLosses).toBe(contaPorResultado('perda-pre-ativacao'))
    expect(metrics.churn).toBe(contaPorResultado('churn-pos-ativacao'))
    expect(metrics.unclassified).toBe(contaPorResultado('sem-classificacao'))
    expect(metrics.reachedActivation).toBe(comAtivacao)
    // Denominadores continuam corretos depois do filtro.
    expect(metrics.inFlowShare).toBeCloseTo(metrics.inFlow / recorte.length, 10)
    expect(metrics.preActivationLossShare).toBeCloseTo(
      metrics.preActivationLosses / recorte.length,
      10,
    )
    expect(metrics.churnShare).toBeCloseTo(metrics.churn / metrics.reachedActivation, 10)
    expect(metrics.churnCohortImpact).toBeCloseTo(metrics.churn / recorte.length, 10)
  })

  it('mantém a Data de Início como único critério temporal, mesmo com outros filtros', () => {
    const snapshot = snapshotOf({ ...JUNE, cityId: 'atibaia' })

    expect(snapshot.records.length).toBeGreaterThan(0)
    snapshot.records.forEach((record) => {
      expect(record.startDate >= JUNE.periodStart).toBe(true)
      expect(record.startDate <= JUNE.periodEnd).toBe(true)
    })
    // Existe venda do recorte cujo cancelamento caiu fora do período, e ela fica.
    expect(
      snapshot.records.some(
        (record) => record.canceledAt !== null && record.canceledAt > JUNE.periodEnd,
      ),
    ).toBe(true)
  })

  it('aplica os mesmos filtros na seleção direta dos registros', () => {
    const filters = filtersOf({ cityId: 'piracaia', origin: 'vendedores' })
    const selecionados = selectSalesPeriodCycleRecords(records, filters)
    const snapshot = buildSalesPeriodCycleSnapshot(dataset, filters)

    expect(selecionados).toHaveLength(snapshot.records.length)
    expect(new Set(selecionados.map((record) => record.saleId))).toEqual(
      new Set(snapshot.records.map((record) => record.saleId)),
    )
  })

  it('devolve recorte vazio, e não erro, quando nada corresponde', () => {
    // Venda indicada é sempre do canal interno, então nunca tem plano corporativo.
    const snapshot = snapshotOf({ origin: 'indicacao', planName: 'Link Corporativo' })

    expect(snapshot.records).toHaveLength(0)
    expect(snapshot.metrics.startedSales).toBe(0)
    expect(snapshot.metrics.reachedActivation).toBe(0)
    expect(snapshot.metrics.churnShare).toBeNull()
    expect(snapshot.metrics.inFlowShare).toBeNull()
  })
})

/* -------------------------------------------------------------------------- */
/* Modalidade, cobrança e execução                                            */
/* -------------------------------------------------------------------------- */

describe('modalidade, cobrança e execução como conceitos independentes', () => {
  const withCharge = (charge: SalesPeriodCycleRecord['installationCharge']) =>
    records.filter((record) => record.installationCharge === charge)
  const withMode = (mode: SalesPeriodCycleRecord['activationMode']) =>
    records.filter((record) => record.activationMode === mode)

  it('exercita todas as modalidades, cobranças e execuções da base', () => {
    expect(new Set(records.map((record) => record.activationMode))).toEqual(
      new Set([
        'instalacao-fisica',
        'ativacao-remota',
        'sem-intervencao-tecnica',
        'nao-identificada',
      ]),
    )
    expect(new Set(records.map((record) => record.installationCharge))).toEqual(
      new Set(['integral', 'com-desconto', 'isenta', 'sem-dado', 'nao-aplicavel']),
    )
    expect(new Set(records.map((record) => record.execution))).toEqual(
      new Set([
        'sem-necessidade',
        'sem-os-relacionada',
        'pendente',
        'concluida',
        'improdutiva',
        'encerrada-sem-conclusao',
        'sem-informacao',
      ]),
    )
  })

  it('lê a cobrança pela mesma regra já validada das instalações', () => {
    records.forEach((record) => {
      const installation = commercialInstallationOf(record.saleId)

      if (installation === null) {
        expect(['sem-dado', 'nao-aplicavel']).toContain(record.installationCharge)
        return
      }

      const status = classifyCommercialInstallation(installation)
      const esperado =
        status === null ? 'sem-dado' : status === 'desconto' ? 'com-desconto' : status

      expect(record.installationCharge).toBe(esperado)
    })
  })

  it('só usa Não aplicável com evidência explícita, e nunca por ausência de dado', () => {
    const semDado = withCharge('sem-dado')
    const naoAplicavel = withCharge('nao-aplicavel')

    expect(semDado.length).toBeGreaterThan(0)
    expect(naoAplicavel.length).toBeGreaterThan(0)
    // As duas leituras convivem entre as vendas sem registro de cobrança.
    semDado.forEach((record) => expect(commercialInstallationOf(record.saleId)).toBeNull())
    naoAplicavel.forEach((record) => expect(commercialInstallationOf(record.saleId)).toBeNull())
  })

  it('aceita instalação isenta com OS física concluída', () => {
    const isentaComOs = withCharge('isenta').filter(
      (record) =>
        record.execution === 'concluida' &&
        record.serviceOrders.some((order) => order.kind === 'instalacao'),
    )

    expect(isentaComOs.length).toBeGreaterThan(0)
  })

  it('não transforma OS de ativação remota em instalação física', () => {
    const remotas = withMode('ativacao-remota')
    const fisicas = withMode('instalacao-fisica')

    expect(remotas.length).toBeGreaterThan(0)
    remotas.forEach((record) => {
      expect(record.serviceOrders.some((order) => order.kind === 'instalacao')).toBe(false)
    })
    fisicas.forEach((record) => {
      expect(record.serviceOrders.some((order) => order.kind === 'ativacao-remota')).toBe(false)
    })
    // Concluir a execução acontece nas duas modalidades: execução não é modalidade.
    expect(remotas.some((record) => record.execution === 'concluida')).toBe(true)
    expect(fisicas.some((record) => record.execution === 'concluida')).toBe(true)
  })

  it('mantém cobrança e modalidade independentes entre si', () => {
    const combinacoes = new Set(
      records.map((record) => `${record.activationMode}|${record.installationCharge}`),
    )

    expect(combinacoes.has('instalacao-fisica|isenta')).toBe(true)
    expect(combinacoes.has('instalacao-fisica|integral')).toBe(true)
    expect(combinacoes.has('ativacao-remota|integral')).toBe(true)
    expect(combinacoes.has('sem-intervencao-tecnica|com-desconto')).toBe(true)
  })
})

/* -------------------------------------------------------------------------- */
/* Ordens de Serviço relacionadas                                             */
/* -------------------------------------------------------------------------- */

describe('resumo das Ordens de Serviço', () => {
  it('deixa a instalação concluída ser o resultado principal', () => {
    expect(
      salesPeriodCycleExecutionOf(
        cycleWith({
          serviceOrders: [
            { code: 'OS-1', kind: 'instalacao', outcome: 'improdutiva' },
            { code: 'OS-2', kind: 'instalacao', outcome: 'concluida' },
          ],
        }),
      ),
    ).toBe('concluida')
  })

  it('deixa a nova tentativa pendente substituir a improdutiva anterior', () => {
    const cycle = cycleWith({
      serviceOrders: [
        { code: 'OS-1', kind: 'instalacao', outcome: 'improdutiva' },
        { code: 'OS-2', kind: 'instalacao', outcome: 'pendente' },
      ],
    })

    expect(salesPeriodCycleExecutionOf(cycle)).toBe('pendente')
  })

  it('mantém as tentativas improdutivas contáveis no detalhe', () => {
    const comImprodutiva = records.filter((record) => record.unproductiveAttempts > 0)

    expect(comImprodutiva.length).toBeGreaterThan(0)
    comImprodutiva.forEach((record) => {
      const improdutivas = record.serviceOrders.filter(
        (order) => order.kind !== 'nao-relacionada' && order.outcome === 'improdutiva',
      )

      expect(record.unproductiveAttempts).toBe(improdutivas.length)
    })
    // A tentativa improdutiva continua contável mesmo quando a execução já mudou.
    expect(comImprodutiva.some((record) => record.execution === 'concluida')).toBe(true)
    expect(comImprodutiva.some((record) => record.execution === 'pendente')).toBe(true)
  })

  it('não deixa OS não relacionada definir a execução da instalação', () => {
    const comNaoRelacionada = records.filter((record) =>
      record.serviceOrders.some((order) => order.kind === 'nao-relacionada'),
    )
    const semRelacionada = comNaoRelacionada.filter((record) =>
      record.serviceOrders.every((order) => order.kind === 'nao-relacionada'),
    )

    expect(comNaoRelacionada.length).toBeGreaterThan(0)
    expect(semRelacionada.length).toBeGreaterThan(0)
    // A OS não relacionada é concluída, e mesmo assim não conclui a instalação.
    semRelacionada.forEach((record) => {
      expect(record.execution).not.toBe('concluida')
      expect(record.unproductiveAttempts).toBe(0)
    })
  })

  it('separa sem necessidade, sem OS relacionada e sem informação', () => {
    expect(
      salesPeriodCycleExecutionOf(cycleWith({ activationMode: 'sem-intervencao-tecnica' })),
    ).toBe('sem-necessidade')
    expect(salesPeriodCycleExecutionOf(cycleWith({ activationMode: 'nao-identificada' }))).toBe(
      'sem-informacao',
    )
    expect(salesPeriodCycleExecutionOf(cycleWith({ activationMode: 'instalacao-fisica' }))).toBe(
      'sem-os-relacionada',
    )
  })

  it('não transforma instalação improdutiva em motivo de perda', () => {
    const improdutivas = records.filter((record) => record.unproductiveAttempts > 0)
    const emFluxo = improdutivas.filter((record) => record.outcome === 'em-fluxo')
    const ativadas = improdutivas.filter((record) => record.outcome === 'ativada')

    // A improdutiva anterior convive com venda em fluxo e com venda ativada.
    expect(emFluxo.length).toBeGreaterThan(0)
    expect(ativadas.length).toBeGreaterThan(0)
    emFluxo.forEach((record) => expect(record.lossReason).toBeNull())
    ativadas.forEach((record) => expect(record.lossReason).toBeNull())
  })
})

/* -------------------------------------------------------------------------- */
/* Casos sintéticos exigidos                                                  */
/* -------------------------------------------------------------------------- */

describe('casos determinísticos representados na base', () => {
  const existe = (predicate: (record: SalesPeriodCycleRecord) => boolean): boolean =>
    records.some(predicate)

  it('cobre os casos aprovados do ciclo comercial', () => {
    expect(existe((r) => r.outcome === 'ativada' && r.canceledAt === null)).toBe(true)
    expect(existe((r) => r.outcome === 'em-fluxo')).toBe(true)
    expect(
      existe(
        (r) =>
          r.outcome === 'perda-pre-ativacao' &&
          r.lossReason === 'duplicidade' &&
          r.activatedAt === null &&
          r.canceledAt !== null,
      ),
    ).toBe(true)
    expect(existe((r) => r.outcome === 'churn-pos-ativacao')).toBe(true)
    expect(existe((r) => r.activationMode === 'ativacao-remota')).toBe(true)
    expect(existe((r) => r.activationMode === 'instalacao-fisica')).toBe(true)
    expect(existe((r) => r.installationCharge === 'isenta' && r.serviceOrders.length > 0)).toBe(true)
    expect(existe((r) => r.outcome === 'em-fluxo' && r.unproductiveAttempts > 0)).toBe(true)
    expect(existe((r) => r.serviceOrders.length > 1)).toBe(true)
    expect(existe((r) => r.installationCharge === 'sem-dado')).toBe(true)
    expect(existe((r) => r.execution === 'sem-informacao')).toBe(true)
    expect(existe((r) => r.status === 'expirada' && r.outcome === 'sem-classificacao')).toBe(true)
  })

  it('deixa os motivos de perda restritos aos três valores permitidos', () => {
    const motivos = new Set(
      records.flatMap((record) => (record.lossReason === null ? [] : [record.lossReason])),
    )

    expect(motivos).toEqual(new Set(['duplicidade', 'cancelamento-de-contrato', 'nao-informado']))
  })
})

/* -------------------------------------------------------------------------- */
/* Opções dos filtros                                                         */
/* -------------------------------------------------------------------------- */

describe('opções dos filtros que dependem dos registros', () => {
  it('reaproveita os vendedores e planos existentes, sem gerar dados novos', () => {
    const options = buildSalesPeriodCycleOptions(records)
    const sellerNames = new Map(records.map((record) => [record.sellerId, record.sellerName]))
    const plans = new Set(records.map((record) => record.planName))

    expect(options.sellers).toHaveLength(sellerNames.size)
    options.sellers.forEach((seller) => expect(sellerNames.get(seller.id)).toBe(seller.name))
    expect(new Set(options.plans)).toEqual(plans)
  })

  it('ordena vendedores pelo nome e planos pelo rótulo, em pt-BR', () => {
    const { plans, sellers } = buildSalesPeriodCycleOptions(records)

    expect(sellers.map((seller) => seller.name)).toEqual(
      [...sellers.map((seller) => seller.name)].sort((a, b) => a.localeCompare(b, 'pt-BR')),
    )
    expect(plans).toEqual([...plans].sort((a, b) => a.localeCompare(b, 'pt-BR')))
  })

  it('deriva as opções do universo inteiro, e não do recorte filtrado', () => {
    const completo = snapshotOf().options
    const recortado = snapshotOf({ cityId: 'piracaia', outcome: 'churn-pos-ativacao' }).options

    // A opção não desaparece da lista depois de ser aplicada: o filtro continua
    // previsível, e o recorte vazio ainda oferece o caminho de volta.
    expect(recortado).toEqual(completo)
    expect(completo.sellers.length).toBeGreaterThan(1)
    expect(completo.plans.length).toBeGreaterThan(1)
  })
})

/* -------------------------------------------------------------------------- */
/* Paginação da tabela do ciclo                                               */
/* -------------------------------------------------------------------------- */

describe('paginação pura do ciclo', () => {
  const recorte = snapshotOf().records

  it('recorta dez vendas por página, mantendo uma linha por venda', () => {
    const primeira = buildSalesPeriodCyclePage(recorte, 0)

    expect(SALES_PERIOD_CYCLE_PAGE_SIZE).toBe(10)
    expect(primeira.records).toHaveLength(10)
    expect(primeira.total).toBe(recorte.length)
    expect(primeira.from).toBe(1)
    expect(primeira.to).toBe(10)
    expect(primeira.totalPages).toBe(Math.ceil(recorte.length / 10))
    expect(new Set(primeira.records.map((record) => record.saleId)).size).toBe(10)
    expect(primeira.records).toEqual(recorte.slice(0, 10))
  })

  it('alcança todos os registros, sem repetir e sem perder nenhum', () => {
    const vistos: string[] = []
    const { totalPages } = buildSalesPeriodCyclePage(recorte, 0)

    for (let page = 0; page < totalPages; page += 1) {
      buildSalesPeriodCyclePage(recorte, page).records.forEach((record) =>
        vistos.push(record.saleId),
      )
    }

    expect(vistos).toHaveLength(recorte.length)
    expect(new Set(vistos).size).toBe(recorte.length)
  })

  it('corrige a página pedida em vez de criar estado novo', () => {
    const alta = buildSalesPeriodCyclePage(recorte, 9_999)
    const negativa = buildSalesPeriodCyclePage(recorte, -3)

    expect(alta.page).toBe(alta.totalPages - 1)
    expect(alta.records.length).toBeGreaterThan(0)
    expect(alta.to).toBe(recorte.length)
    expect(negativa.page).toBe(0)
  })

  it('devolve uma página válida também na lista vazia', () => {
    const vazia = buildSalesPeriodCyclePage([], 4)

    expect(vazia.records).toHaveLength(0)
    expect(vazia.total).toBe(0)
    expect(vazia.totalPages).toBe(1)
    expect(vazia.page).toBe(0)
    // Contagem humana não começa em 1 quando não existe registro.
    expect(vazia.from).toBe(0)
    expect(vazia.to).toBe(0)
  })

  it('mostra a última página parcial sem completar com linha falsa', () => {
    const doze = recorte.slice(0, 12)
    const ultima = buildSalesPeriodCyclePage(doze, 1)

    expect(ultima.records).toHaveLength(2)
    expect(ultima.from).toBe(11)
    expect(ultima.to).toBe(12)
    expect(ultima.totalPages).toBe(2)
  })
})

/* -------------------------------------------------------------------------- */
/* Projeções analíticas dos painéis                                           */
/* -------------------------------------------------------------------------- */

describe('evolução das vendas iniciadas', () => {
  it('publica um ponto por dia do período, inclusive nos dias sem venda', () => {
    const { daily } = snapshotOf()

    expect(daily).toHaveLength(31)
    expect(daily[0].date).toBe('2026-07-01')
    expect(daily[30].date).toBe('2026-07-31')
    // A sequência é contínua: o eixo não comprime o calendário.
    daily.forEach((point, index) => {
      expect(point.day).toBe(index + 1)
      if (index > 0) expect(point.date > daily[index - 1].date).toBe(true)
    })
  })

  it('fecha a evolução com as vendas iniciadas e com o valor mensal do recorte', () => {
    const snapshot = snapshotOf()
    const totalPontos = snapshot.daily.reduce((sum, point) => sum + point.startedSales, 0)
    const valorPontos = snapshot.daily.reduce(
      (sum, point) => sum + point.monthlyContractedValue,
      0,
    )
    const valorRegistros = snapshot.records.reduce((sum, record) => sum + record.monthlyValue, 0)

    expect(totalPontos).toBe(snapshot.metrics.startedSales)
    expect(valorPontos).toBeCloseTo(valorRegistros, 6)
  })

  it('agrupa cada venda pela Data de Início, e nunca pela ativação ou pelo cancelamento', () => {
    const julho = snapshotOf()
    const junho = snapshotOf(JUNE)
    const porDataJunho = new Map(junho.daily.map((point) => [point.date, point]))
    // Venda iniciada em junho e cancelada em julho: ela pertence ao dia de junho
    // em que começou, e não ao dia de julho em que foi cancelada.
    const atravessa = junho.records.find(
      (record) => record.canceledAt !== null && monthKeyOf(record.canceledAt) === '2026-07',
    )

    expect(atravessa).toBeDefined()
    expect(porDataJunho.get(atravessa!.startDate)!.byOutcome[atravessa!.outcome]).toBeGreaterThan(0)
    expect(julho.records.some((record) => record.saleId === atravessa!.saleId)).toBe(false)

    julho.daily.forEach((point) => {
      const doDia = julho.records.filter((record) => record.startDate === point.date)
      expect(point.startedSales).toBe(doDia.length)
    })
  })

  it('distribui o dia pelos cinco resultados, somando o total iniciado do dia', () => {
    const { daily } = snapshotOf()

    daily.forEach((point) => {
      const soma = Object.values(point.byOutcome).reduce((total, value) => total + value, 0)

      expect(soma).toBe(point.startedSales)
    })
  })

  it('devolve zero, e não ausência de ponto, para o dia sem venda iniciada', () => {
    const daily = buildSalesPeriodCycleDaily([], '2026-07-01', '2026-07-03')

    expect(daily).toHaveLength(3)
    daily.forEach((point) => {
      expect(point.startedSales).toBe(0)
      expect(point.monthlyContractedValue).toBe(0)
      expect(point.byOutcome.ativada).toBe(0)
    })
  })
})

describe('origem das vendas iniciadas', () => {
  it('fecha as duas origens com o total INICIADO, e não só com o que continua ativo', () => {
    const snapshot = snapshotOf()
    const [indicacao, vendedores] = snapshot.origins
    const perdidas = snapshot.records.filter(
      (record) => record.outcome === 'perda-pre-ativacao' || record.outcome === 'churn-pos-ativacao',
    )

    expect(snapshot.origins).toHaveLength(2)
    expect(indicacao.startedSales + vendedores.startedSales).toBe(snapshot.metrics.startedSales)
    expect(indicacao.share + vendedores.share).toBeCloseTo(1, 10)
    // As vendas perdidas continuam tendo origem: retirá-las mudaria o universo.
    expect(perdidas.length).toBeGreaterThan(0)
    expect(indicacao.startedSales + vendedores.startedSales).toBeGreaterThan(
      snapshot.metrics.activated,
    )
  })

  it('usa a mesma regra do indicador e soma o valor mensal de cada origem', () => {
    const snapshot = snapshotOf()

    snapshot.origins.forEach((slice) => {
      const doGrupo = snapshot.records.filter((record) => record.origin === slice.origin)
      const valor = doGrupo.reduce((sum, record) => sum + record.monthlyValue, 0)

      expect(slice.startedSales).toBe(doGrupo.length)
      expect(slice.monthlyContractedValue).toBeCloseTo(valor, 6)
      expect(slice.share).toBeCloseTo(doGrupo.length / snapshot.metrics.startedSales, 10)
    })
  })

  it('mantém as duas fatias mesmo no recorte vazio, sem dividir por zero', () => {
    const origins = buildSalesPeriodCycleOrigins([])

    expect(origins.map((slice) => slice.origin)).toEqual(['indicacao', 'vendedores'])
    origins.forEach((slice) => {
      expect(slice.startedSales).toBe(0)
      expect(slice.share).toBe(0)
      expect(Number.isNaN(slice.share)).toBe(false)
    })
  })

  it('recorta origem e evolução com o mesmo conjunto filtrado dos indicadores', () => {
    const snapshot = snapshotOf({ ...JULY, cityId: 'piracaia' })
    const totalOrigens = snapshot.origins.reduce((sum, slice) => sum + slice.startedSales, 0)
    const totalDiario = snapshot.daily.reduce((sum, point) => sum + point.startedSales, 0)

    expect(snapshot.metrics.startedSales).toBeLessThan(snapshotOf().metrics.startedSales)
    expect(totalOrigens).toBe(snapshot.metrics.startedSales)
    expect(totalDiario).toBe(snapshot.metrics.startedSales)
  })
})
