import type { Theme } from '../../../contexts/PreferencesContextCore'
import { formatNumber, formatPercent } from '../../../lib/formatters'
import {
  salesPeriodCycleOutcomeLabels,
  type SalesPeriodCycleMetrics,
  type SalesPeriodCycleOutcome,
} from './salesPeriodCycleModel'
import { salesPeriodCycleColors, type SalesPeriodCycleTone } from './salesPeriodCycleVisualModel'

/**
 * Situação das vendas.
 *
 * Painel analítico compacto, no mesmo contêiner e na mesma linguagem dos demais
 * gráficos comerciais da página. Ele responde uma pergunta só: onde estão hoje
 * as vendas iniciadas no recorte.
 *
 * A composição é de 100%, e não árvore, funil nem fluxo ramificado. Funil
 * sugere etapas sequenciais obrigatórias, e a árvore transformava uma leitura
 * secundária no elemento dominante da página. O que existe aqui são cinco
 * resultados MUTUAMENTE EXCLUSIVOS que somam as vendas iniciadas.
 *
 * `Chegaram à ativação` não é fatia: ele agrega Ativadas mais Churn, e virar um
 * sexto segmento faria a composição somar mais que o total iniciado. Esse
 * agregado já é publicado no card executivo correspondente.
 *
 * A cor nunca carrega sozinha o significado: cada resultado traz rótulo,
 * contagem e percentual em texto, então uma fatia de meio por cento continua
 * legível mesmo sendo um traço na barra.
 *
 * Este painel é específico de Vendas por Período e não é template compartilhado.
 * Este arquivo também publica o badge do resultado comercial usado pela tabela:
 * é ele que concentra a leitura semântica, para o mesmo resultado nunca
 * aparecer com duas cores diferentes na mesma página.
 */

/** Um resultado final do ciclo, com contagem e participação no total iniciado. */
type SituationSlice = {
  readonly tone: SalesPeriodCycleTone
  readonly label: string
  readonly count: number
}

const panelClass =
  'min-w-0 rounded-xl border border-[var(--border)] bg-[var(--surface)] px-[18px] py-4'

export function SalesPeriodCycleSituation({
  metrics,
  theme,
}: {
  metrics: SalesPeriodCycleMetrics
  theme: Theme
}) {
  const colors = salesPeriodCycleColors[theme]
  const { startedSales } = metrics

  /**
   * Ordem aprovada da composição: o resultado consolidado primeiro, depois o
   * que ainda está em andamento, depois as duas perdas e, por último, a ausência
   * declarada de classificação.
   */
  const slices: readonly SituationSlice[] = [
    { tone: 'ativada', label: 'Ativadas sem cancelamento posterior', count: metrics.activated },
    {
      tone: 'em-fluxo',
      label: salesPeriodCycleOutcomeLabels['em-fluxo'],
      count: metrics.inFlow,
    },
    {
      tone: 'perda-pre-ativacao',
      label: salesPeriodCycleOutcomeLabels['perda-pre-ativacao'],
      count: metrics.preActivationLosses,
    },
    {
      tone: 'churn-pos-ativacao',
      label: salesPeriodCycleOutcomeLabels['churn-pos-ativacao'],
      count: metrics.churn,
    },
    {
      tone: 'sem-classificacao',
      label: salesPeriodCycleOutcomeLabels['sem-classificacao'],
      count: metrics.unclassified,
    },
  ]

  return (
    <section aria-labelledby="situacao-das-vendas" className={panelClass}>
      <h2
        className="text-[13.5px] font-semibold text-[var(--text-heading)]"
        id="situacao-das-vendas"
      >
        Situação das vendas
      </h2>
      <p className="mt-0.5 text-[12px] leading-[1.45] text-[var(--text-secondary)]">
        Onde estão hoje as vendas com Data de Início no período selecionado.
      </p>

      {startedSales === 0 ? (
        <div className="mt-3 flex min-h-[120px] flex-col items-center justify-center gap-1.5 rounded-lg border border-dashed border-[var(--border)] px-5 text-center text-[12px] text-[var(--text-secondary)]">
          <p>Nenhuma venda iniciada corresponde aos filtros selecionados.</p>
          <p className="text-[11.5px]">
            Limpe os filtros ou amplie o período para voltar ao recorte inicial.
          </p>
        </div>
      ) : (
        <>
          {/* Composição de 100%. Decorativa para leitor de tela: cada segmento
              tem rótulo, contagem e percentual em texto logo abaixo. */}
          <div
            aria-hidden="true"
            className="mt-3 flex h-3 gap-px overflow-hidden rounded-full bg-[var(--divider)]"
          >
            {slices.map((slice) =>
              slice.count === 0 ? null : (
                <div
                  key={slice.tone}
                  style={{
                    background: colors[slice.tone],
                    width: `${(slice.count / startedSales) * 100}%`,
                  }}
                />
              ),
            )}
          </div>

          <ul className="mt-3 grid min-w-0 grid-cols-1 gap-2.5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
            {slices.map((slice) => (
              <li
                className="min-w-0 rounded-lg border border-[var(--divider)] px-2.5 py-2"
                key={slice.tone}
              >
                <p className="flex min-w-0 items-center gap-1.5 text-[11px] font-semibold leading-[1.3] text-[var(--text-item)]">
                  <span
                    aria-hidden="true"
                    className="h-1.5 w-1.5 flex-none rounded-full"
                    style={{ background: colors[slice.tone] }}
                  />
                  <span className="min-w-0 flex-1">{slice.label}</span>
                </p>
                <p className="mt-1.5 flex items-baseline gap-1.5">
                  <b className="font-mono text-[17px] font-bold leading-none text-[var(--text-heading)]">
                    {formatNumber(slice.count)}
                  </b>
                  <span
                    className="font-mono text-[11px] font-semibold"
                    style={{ color: colors[slice.tone] }}
                  >
                    {formatPercent(slice.count / startedSales)}
                  </span>
                </p>
              </li>
            ))}
          </ul>

          <p className="mt-3 text-[11px] leading-[1.45] text-[var(--text-secondary)]">
            Os cinco resultados são exclusivos e somam as{' '}
            <b className="font-mono text-[var(--text-item)]">{formatNumber(startedSales)}</b>{' '}
            {startedSales === 1 ? 'venda iniciada' : 'vendas iniciadas'} do recorte. Chegaram à
            ativação inclui as vendas que depois foram canceladas, então ele não aparece como uma
            fatia própria. {churnNote(metrics)}
          </p>
        </>
      )}
    </section>
  )
}

/**
 * Aviso do denominador do churn.
 *
 * O percentual da fatia é sobre as vendas iniciadas, como o de todas as outras.
 * A taxa oficial do indicador usa outro denominador, e dizer isso aqui evita a
 * leitura de que um dos dois números estaria errado.
 */
function churnNote(metrics: SalesPeriodCycleMetrics): string {
  if (metrics.churnShare === null) {
    return 'Nenhuma venda do recorte chegou à ativação, então não há taxa de churn.'
  }

  return `Taxa do indicador: ${formatPercent(metrics.churnShare)} sobre as ${formatNumber(metrics.reachedActivation)} vendas que chegaram à ativação.`
}

/**
 * Badge do resultado comercial.
 *
 * Usa a mesma cor semântica da Situação das vendas e sempre acompanha o rótulo
 * aprovado por extenso: a cor reforça, e nunca substitui, a informação.
 */
export function SalesPeriodCycleOutcomeBadge({
  outcome,
  theme,
}: {
  outcome: SalesPeriodCycleOutcome
  theme: Theme
}) {
  const color = salesPeriodCycleColors[theme][outcome]

  return (
    <span
      className="inline-flex items-center gap-1.5 whitespace-nowrap rounded-full border px-2 py-0.5 text-[10px] font-semibold"
      style={{ background: `${color}14`, borderColor: `${color}40`, color }}
    >
      <span
        aria-hidden="true"
        className="h-1.5 w-1.5 flex-none rounded-full"
        style={{ background: color }}
      />
      {salesPeriodCycleOutcomeLabels[outcome]}
    </span>
  )
}
