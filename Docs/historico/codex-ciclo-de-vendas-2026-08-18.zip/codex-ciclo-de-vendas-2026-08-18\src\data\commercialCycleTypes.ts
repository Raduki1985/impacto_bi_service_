/**
 * Ciclo comercial da venda.
 *
 * Projeção SEPARADA de `CommercialSale`. Ela não substitui, não estende e não
 * reinterpreta a venda compartilhada: o vínculo é `saleId`, e Visão Geral e
 * Metas e Desempenho continuam consumindo exatamente os mesmos fatos de antes.
 *
 * O que este domínio acrescenta é o ciclo, e não o cadastro: quando a venda
 * começou, se chegou a ativar, se foi cancelada, sob qual modalidade seria
 * ativada, como a instalação foi cobrada e o que as Ordens de Serviço
 * relacionadas resumem. Nada aqui pertence ao domínio de OS: técnico, agenda,
 * rota, equipamentos, fotos e observações continuam fora, de propósito.
 *
 * Três datas semanticamente distintas, e uma só decide o período:
 *
 * - `startDate` é a Data de Início. É a ÚNICA que atribui a venda a um período.
 * - `activatedAt` é a Data de ativação. Uma venda pode iniciar em um mês e
 *   ativar em outro sem mudar de período.
 * - `canceledAt` é a Data de cancelamento. Também não transfere a venda.
 *
 * O resultado comercial NÃO é um campo gravado: ele é derivado por função pura
 * a partir das datas e do status, para não existir um rótulo manual capaz de
 * divergir dos eventos. A derivação vive em
 * `Pages/Commercial/SalesPeriod/salesPeriodCycleModel`.
 *
 * Todos os dados desta projeção são sintéticos e não representam a operação
 * real da Impacto Telecom.
 */

import type { CommercialSaleStatus } from './commercialTypes'

/**
 * Modalidade pela qual a venda seria ativada.
 *
 * É independente da cobrança e da execução: instalação física pode ser isenta,
 * e ativação remota também possui Ordem de Serviço. `nao-identificada` é
 * ausência de informação, e nunca deve ser lida como ausência de instalação.
 */
export type CommercialActivationMode =
  | 'instalacao-fisica'
  | 'ativacao-remota'
  | 'sem-intervencao-tecnica'
  | 'nao-identificada'

/**
 * Situação da cobrança do serviço de instalação, na leitura do ciclo.
 *
 * `sem-dado` é ausência de registro e não é isenção. `nao-aplicavel` exige
 * evidência explícita de que a venda não contratou serviço de instalação, e é
 * por isso que essa evidência é um fato do próprio ciclo
 * (`hasInstallationService`), e não uma inferência a partir da ausência.
 */
export type CommercialInstallationCharge =
  | 'integral'
  | 'com-desconto'
  | 'isenta'
  | 'sem-dado'
  | 'nao-aplicavel'

/**
 * Execução resumida da ativação.
 *
 * Deriva das Ordens de Serviço relacionadas à ativação inicial e da modalidade.
 * `sem-necessidade` é o caso em que não havia intervenção técnica prevista;
 * `sem-os-relacionada` é o caso em que havia e nenhuma OS foi encontrada.
 */
export type CommercialCycleExecution =
  | 'sem-necessidade'
  | 'sem-os-relacionada'
  | 'pendente'
  | 'concluida'
  | 'improdutiva'
  | 'encerrada-sem-conclusao'
  | 'sem-informacao'

/**
 * Motivo da perda, nos três valores sintéticos permitidos no mock.
 *
 * Uma instalação improdutiva anterior NUNCA vira motivo: ela é um evento
 * associado, e atribuir causa sem motivo explícito seria inventar a regra.
 */
export type CommercialLossReason = 'duplicidade' | 'cancelamento-de-contrato' | 'nao-informado'

/**
 * Relação da OS com a ativação inicial da venda.
 *
 * `nao-relacionada` existe para provar a regra: OS de outro assunto não define
 * a execução da instalação, mesmo concluída.
 */
export type CommercialCycleServiceOrderKind = 'instalacao' | 'ativacao-remota' | 'nao-relacionada'

export type CommercialCycleServiceOrderOutcome =
  | 'pendente'
  | 'concluida'
  | 'improdutiva'
  | 'encerrada-sem-conclusao'

/**
 * Referência resumida de uma OS.
 *
 * Só o suficiente para contar tentativas e resolver a execução. Nada de
 * técnico, agenda, rota, equipamentos, fotos ou observações: isso pertence ao
 * domínio de Ordens de Serviço, que não é este.
 */
export type CommercialCycleServiceOrder = {
  readonly code: string
  readonly kind: CommercialCycleServiceOrderKind
  readonly outcome: CommercialCycleServiceOrderOutcome
}

/**
 * Um registro de ciclo por venda. Nunca mais de um.
 *
 * Várias OS relacionadas não multiplicam a venda: elas ficam dentro de
 * `serviceOrders`, na ordem das tentativas.
 */
export type CommercialSaleCycle = {
  /** Venda à qual o ciclo pertence. É a granularidade, e é única. */
  readonly saleId: string
  /** Data de Início. Único critério de inclusão no período. */
  readonly startDate: string
  /** Data de ativação. `null` enquanto a venda não ativou. */
  readonly activatedAt: string | null
  /** Data de cancelamento. `null` enquanto a venda não foi cancelada. */
  readonly canceledAt: string | null
  /** Status atual da assinatura, o mesmo vocabulário do cadastro da venda. */
  readonly status: CommercialSaleStatus
  /** Motivo da perda. `null` quando não houve perda. */
  readonly lossReason: CommercialLossReason | null
  readonly activationMode: CommercialActivationMode
  /**
   * Evidência explícita de que a venda contratou serviço de instalação.
   * `false` é afirmação do mock, e não ausência de dado: só ela permite a
   * leitura `nao-aplicavel` na cobrança.
   */
  readonly hasInstallationService: boolean
  /** Tentativas e OS relacionadas, na ordem em que aconteceram. */
  readonly serviceOrders: readonly CommercialCycleServiceOrder[]
  /** Data de referência da apuração. Nenhum evento do ciclo a ultrapassa. */
  readonly referenceDate: string
}
