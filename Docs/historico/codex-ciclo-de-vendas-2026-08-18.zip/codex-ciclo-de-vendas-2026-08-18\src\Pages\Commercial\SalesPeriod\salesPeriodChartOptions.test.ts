import { describe, expect, it } from 'vitest'

import {
  formatSalesPeriodDailyTooltip,
  makeSalesPeriodDailyOptions,
  SALES_PERIOD_COUNT_SERIES,
  SALES_PERIOD_VALUE_SERIES,
} from './salesPeriodChartOptions'
import type { SalesPeriodCycleDailyPoint } from './salesPeriodCycleModel'

/**
 * Um dia da evolução, agrupado pela Data de Início.
 *
 * A distribuição por resultado existe no ponto e continua fora do gráfico: o
 * painel mostra quantidade iniciada e valor mensal contratado, e é a Situação
 * das vendas que responde onde essas vendas estão hoje.
 */
const daily: readonly SalesPeriodCycleDailyPoint[] = [
  {
    date: '2026-07-22',
    day: 22,
    startedSales: 32,
    monthlyContractedValue: 4466.800000000001,
    byOutcome: {
      ativada: 26,
      'em-fluxo': 4,
      'perda-pre-ativacao': 1,
      'churn-pos-ativacao': 1,
      'sem-classificacao': 0,
    },
  },
]

/** O tipo de série do ECharts é uma união ampla; o teste só lê nome e dados. */
type SeriesShape = { readonly name?: string; readonly data?: unknown }

function seriesOf(): SeriesShape[] {
  const { series } = makeSalesPeriodDailyOptions(daily)
  return (Array.isArray(series) ? series : [series]) as SeriesShape[]
}

describe('salesPeriodChartOptions', () => {
  it('nomeia as séries pela terminologia de vendas iniciadas', () => {
    const series = seriesOf()

    expect(SALES_PERIOD_COUNT_SERIES).toBe('Vendas iniciadas')
    expect(SALES_PERIOD_VALUE_SERIES).toBe('Valor mensal contratado')
    expect(series.map((item) => item.name)).toEqual([
      SALES_PERIOD_COUNT_SERIES,
      SALES_PERIOD_VALUE_SERIES,
    ])
    // Nenhuma série afirma que houve uma ativação dentro do período: o eixo é a
    // Data de Início, e não a data de ativação ou de cancelamento.
    expect(JSON.stringify(series)).not.toContain('ativadas')
    expect(JSON.stringify(series)).not.toContain('ativas')
  })

  it('lê a quantidade iniciada e o valor mensal contratado dos pontos da evolução', () => {
    const series = seriesOf()

    expect(makeSalesPeriodDailyOptions(daily).tooltip).toBeDefined()
    // A barra é o total iniciado do dia, e não apenas o que ativou.
    expect(series[0]?.data).toEqual([32])
    expect(series[1]?.data).toEqual([4466.800000000001])
  })

  it('mantém a barra igual à soma dos resultados do dia', () => {
    const [point] = daily
    const total = Object.values(point.byOutcome).reduce((sum, value) => sum + value, 0)

    expect(total).toBe(point.startedSales)
    expect(seriesOf()[0]?.data).toEqual([total])
  })

  it('formata o valor mensal do tooltip em reais com duas casas decimais', () => {
    // Montado pelo próprio Intl para o teste não depender de qual espaço o
    // ambiente grava entre o símbolo e o número.
    const expectedValue = new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(4466.8)
    const tooltip = formatSalesPeriodDailyTooltip([
      {
        axisValueLabel: '22/07',
        marker: '•',
        seriesName: SALES_PERIOD_COUNT_SERIES,
        value: 32,
      },
      {
        axisValueLabel: '22/07',
        marker: '•',
        seriesName: SALES_PERIOD_VALUE_SERIES,
        value: 4466.800000000001,
      },
    ])

    expect(expectedValue).toMatch(/^R\$\s4\.466,80$/u)
    expect(tooltip).toContain('32 vendas')
    expect(tooltip).toContain(expectedValue)
    expect(tooltip).not.toContain('4466.800000000001')
  })
})
