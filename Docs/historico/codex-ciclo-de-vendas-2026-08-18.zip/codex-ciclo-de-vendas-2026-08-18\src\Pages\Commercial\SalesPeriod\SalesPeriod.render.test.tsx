import { renderToStaticMarkup } from 'react-dom/server'
import { describe, expect, it, vi } from 'vitest'

import { PreferencesProvider } from '../../../contexts/PreferencesContext'
import type { Theme } from '../../../contexts/PreferencesContextCore'
import { formatIsoAsBrDate } from '../../../data/commercialCalendar'
import type { CommercialDataset } from '../../../data/commercialTypes'
import { getCommercialDataset } from '../../../data/mockCommercialData'
import { formatNumber, formatPercent } from '../../../lib/formatters'
import { SalesPeriod } from './SalesPeriod'
import { SalesPeriodCycleSituation } from './SalesPeriodCycleSituation'
import { SalesPeriodCycleTable } from './SalesPeriodCycleTable'
import { SalesPeriodFilters } from './SalesPeriodFilters'
import {
  buildSalesPeriodCycleRecords,
  buildSalesPeriodCycleSnapshot,
  initialSalesPeriodCycleFilters,
  type SalesPeriodCycleFilters as CycleFilters,
  type SalesPeriodCycleRecord,
} from './salesPeriodCycleModel'

/**
 * Teste de fumaça da página e das composições próprias deste bloco.
 *
 * Não substitui a validação visual: ele garante que cada estado renderiza, que a
 * terminologia aprovada chega à tela, que os números publicados são os do modelo
 * e que a apresentação continua sendo a do template consolidado do Comercial.
 *
 * O que ele protege, em ordem: os cards compartilhados com a Visão Geral, os
 * cinco indicadores do ciclo, a ausência de comparação com período anterior, os
 * painéis de Evolução e de Origem, a Situação das vendas compacta, o fechamento
 * dos resultados com o total iniciado, o denominador do churn, uma linha por
 * venda, a ausência de detalhe operacional de OS e o aviso de dados sintéticos.
 *
 * A interação de clique não é exercitada aqui: o projeto roda os testes em
 * ambiente Node, com `renderToStaticMarkup` e sem DOM, então trocar filtro e
 * paginar não é automatizável neste arquivo. O que é verificado no lugar é o
 * resultado de cada recorte, renderizando as composições com o snapshot já
 * filtrado, e a paginação pura fica coberta em `salesPeriodCycleModel.test.ts`.
 *
 * A ordem dos casos importa: o primeiro depende de a base ainda não ter sido
 * montada neste arquivo.
 */

let cached: CommercialDataset | null = null

/** Base montada sob demanda, para não quebrar o caso do estado de carregamento. */
function base(): CommercialDataset {
  cached ??= getCommercialDataset()

  return cached
}

function renderPage() {
  return renderToStaticMarkup(
    <PreferencesProvider>
      <SalesPeriod />
    </PreferencesProvider>,
  )
}

function snapshotOf(overrides: Partial<CycleFilters> = {}) {
  return buildSalesPeriodCycleSnapshot(base(), {
    ...initialSalesPeriodCycleFilters(),
    ...overrides,
  })
}

function renderSituation(overrides: Partial<CycleFilters> = {}, theme: Theme = 'light') {
  return renderToStaticMarkup(
    <SalesPeriodCycleSituation metrics={snapshotOf(overrides).metrics} theme={theme} />,
  )
}

function renderTable(
  records: readonly SalesPeriodCycleRecord[],
  { page = 0, theme = 'light' as Theme } = {},
) {
  return renderToStaticMarkup(
    <SalesPeriodCycleTable onPageChange={() => {}} page={page} records={records} theme={theme} />,
  )
}

/** Registro real da base que atende a condição pedida. */
function pick(predicate: (record: SalesPeriodCycleRecord) => boolean): SalesPeriodCycleRecord {
  const record = buildSalesPeriodCycleRecords(base()).find(predicate)

  expect(record).toBeDefined()

  return record!
}

/** Quantidade de linhas do corpo da tabela, pela altura fixa de linha. */
function rowCount(html: string): number {
  return (html.match(/height:48px/g) ?? []).length
}

/** Quantidade de cards executivos, pela faixa de valor do componente compartilhado. */
function cardCount(html: string): number {
  return (html.match(/flex h-\[30px\] items-end/g) ?? []).length
}

describe('página Vendas por Período', () => {
  it('mostra o estado de carregamento antes de a base existir', () => {
    const html = renderPage()

    expect(html).toContain('Carregando as vendas iniciadas')
    expect(html).toContain('role="status"')
    // O carregamento usa a mesma grade dos cards, com os mesmos cinco blocos:
    // sem isso o layout pularia quando os valores reais entrassem.
    expect(html).toContain('sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5')
    expect((html.match(/animate-pulse/g) ?? []).length).toBe(5)
  })

  it('publica os cinco indicadores do ciclo com os nomes aprovados', () => {
    const { metrics } = snapshotOf()
    const html = renderPage()

    for (const label of [
      'Vendas iniciadas',
      'Chegaram à ativação',
      'Ainda em fluxo',
      'Perdas pré-ativação',
      'Churn pós-ativação',
    ]) {
      expect(html).toContain(label)
    }

    for (const value of [
      metrics.startedSales,
      metrics.reachedActivation,
      metrics.inFlow,
      metrics.preActivationLosses,
      metrics.churn,
    ]) {
      expect(html).toContain(`>${formatNumber(value)}</p>`)
    }

    expect(html).not.toContain('NaN')
    expect(html).not.toContain('Infinity')
    expect(html).not.toContain('undefined')
  })

  it('monta os cinco indicadores no card executivo compartilhado da Visão Geral', () => {
    const html = renderPage()

    // Cinco cards, cada um com a faixa de valor, a leitura gerencial, o bloco
    // OBSERVAR e o minigráfico do componente compartilhado. Se a página voltasse
    // a desenhar indicadores próprios, nenhuma destas marcas apareceria.
    expect(cardCount(html)).toBe(5)
    expect((html.match(/Leitura gerencial/g) ?? []).length).toBe(5)
    expect((html.match(/OBSERVAR/g) ?? []).length).toBe(5)
    expect((html.match(/commercial-spark-/g) ?? []).length).toBeGreaterThanOrEqual(5)
    expect((html.match(/min-h-\[206px\] cursor-pointer/g) ?? []).length).toBe(5)
    // Cinco em uma linha a partir de `xl`, na mesma grade que a Visão Geral usa
    // para os cinco cards dela.
    expect(html).toContain('sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5')
  })

  it('descreve o minigráfico pela Data de Início, e nunca pela data do desfecho', () => {
    const html = renderPage()

    // Texto curto aprovado, igual nos cinco cards: a versão longa anterior era o
    // que ainda cortava a leitura gerencial em 1280 px.
    const observe = 'Minigráfico por Data de Início no período, não pela data do desfecho.'
    expect(html).toContain(observe)
    expect((html.split(observe).length - 1)).toBe(5)

    expect(html).not.toContain('Distribuição pela Data de Início')
    for (const wrong of [
      'crescimento',
      'tendência',
      'ao longo do tempo',
      'Evolução diária do resultado',
    ]) {
      // A série é distribuição pela data em que a venda começou; nenhum texto
      // do bloco pode sugerir movimento do resultado no tempo.
      expect(html).not.toContain(wrong)
    }
  })

  it('não exibe nenhuma comparação com o período anterior', () => {
    const html = renderPage()

    for (const removed of [
      'vs. p.p.',
      'versus período anterior',
      'Sem período anterior',
      'Estável',
      'período anterior',
      '▲',
      '▼',
    ]) {
      expect(html).not.toContain(removed)
    }
    // A faixa de comparação do card compartilhado nem chega a ser montada.
    expect(html).not.toContain('flex h-[24px] items-center')
  })

  it('não publica nenhuma legenda contextual abaixo do valor dos cards', () => {
    const { metrics } = snapshotOf()
    const html = renderPage()

    // A faixa de detalhe do card compartilhado nem chega a ser montada: a frente
    // do card fica com título, valor, ícone e minigráfico, e nada mais.
    expect(html).not.toContain('mt-1.5 text-[11px] font-semibold text-[var(--text-secondary)]')
    for (const removed of [
      'vendas com Data de Início no período e nos filtros selecionados',
      `${formatPercent(metrics.activationShare!)} das vendas iniciadas`,
      `${formatPercent(metrics.inFlowShare!)} das vendas iniciadas`,
      `${formatPercent(metrics.preActivationLossShare!)} das vendas iniciadas`,
      `${formatPercent(metrics.churnShare!)} das vendas que chegaram à ativação`,
      'sem vendas iniciadas no recorte',
    ]) {
      expect(html).not.toContain(removed)
    }
  })

  it('usa vendas ativadas no churn e as iniciadas apenas como impacto secundário', () => {
    const { metrics } = snapshotOf()
    const html = renderPage()

    // Taxa e impacto vivem na leitura gerencial, cada um escrevendo o próprio
    // denominador: são universos diferentes, e não uma divergência.
    expect(html).toContain('Taxa: ')
    expect(html).toContain(' que ativaram. Impacto sobre as vendas iniciadas: ')
    expect(html).toContain(`>${formatPercent(metrics.churnShare!)}</b>`)
    expect(html).toContain(`>${formatNumber(metrics.reachedActivation)}</b>`)
    expect(html).toContain(`>${formatPercent(metrics.churnCohortImpact!)}</b>`)
    // O impacto na base é menor que a taxa oficial, porque o denominador é maior.
    expect(metrics.churnShare!).toBeGreaterThan(metrics.churnCohortImpact!)
  })

  it('inclui em Chegaram à ativação as vendas que depois viraram churn', () => {
    const { metrics } = snapshotOf()
    const html = renderPage()

    expect(metrics.churn).toBeGreaterThan(0)
    expect(metrics.reachedActivation).toBe(metrics.activated + metrics.churn)
    expect(html).toContain(
      ' vendas ativadas e depois canceladas. Permanecem ativadas sem cancelamento posterior: ',
    )
    expect(html).toContain(`>${formatNumber(metrics.churn)}</b>`)
    expect(html).toContain(`>${formatNumber(metrics.activated)}</b>`)
    expect(html).toContain('Chegaram à ativação inclui as vendas que depois foram canceladas')
  })

  it('ordena os blocos como a referência aprovada', () => {
    const html = renderPage()
    const posicaoDe = (texto: string) => {
      const index = html.indexOf(texto)
      expect(index).toBeGreaterThan(-1)

      return index
    }

    const filtros = posicaoDe('Filtros das vendas iniciadas no período')
    const cards = posicaoDe('Indicadores das vendas iniciadas no período')
    const evolucao = posicaoDe('Evolução das vendas iniciadas')
    const origem = posicaoDe('Origem das vendas')
    const situacao = posicaoDe('Situação das vendas')
    const tabela = posicaoDe('Detalhamento das vendas iniciadas')
    const aviso = posicaoDe('Esboço com dados sintéticos')

    expect(filtros).toBeLessThan(cards)
    expect(cards).toBeLessThan(evolucao)
    expect(evolucao).toBeLessThan(origem)
    expect(origem).toBeLessThan(situacao)
    expect(situacao).toBeLessThan(tabela)
    expect(tabela).toBeLessThan(aviso)
  })

  it('não reintroduz hero, funil nem fluxo ramificado', () => {
    const html = renderPage()

    for (const removed of ['Funil', 'Mapa da coorte', 'coorte', 'Não chegaram à ativação']) {
      expect(html).not.toContain(removed)
    }
  })

  it('mantém o aviso de dados sintéticos atualizado', () => {
    const html = renderPage()

    for (const text of [
      'dados sintéticos',
      'nenhum percentual desta página representa a operação real',
      'Não existe integração com o Sales ou com o SGI neste protótipo',
      'passará a usar a Data de Início oficial da venda',
      'instalação isenta não é ausência de instalação',
      'ativação remota não é instalação física',
      `Base mockada apurada em ${formatIsoAsBrDate(base().referenceDate)}`,
    ]) {
      expect(html).toContain(text)
    }
  })

  it('não expõe nenhum detalhe operacional de Ordem de Serviço', () => {
    const html = renderPage()

    for (const removed of ['Técnico', 'Agenda', 'Equipamento', 'Rota', 'Produtividade', 'Observaç']) {
      expect(html).not.toContain(removed)
    }
    // Nenhum código de OS chega à tela: a granularidade exibida é a venda.
    expect(html).not.toMatch(/OS-\d/)
  })
})

/* -------------------------------------------------------------------------- */
/* Evolução das vendas iniciadas                                              */
/* -------------------------------------------------------------------------- */

describe('Evolução das vendas iniciadas', () => {
  it('usa o título aprovado e diz que o agrupamento é pela Data de Início', () => {
    const html = renderPage()

    expect(html).toContain('Evolução das vendas iniciadas')
    expect(html).toContain(
      'Quantidade de vendas e valor mensal contratado agrupados pela Data de Início',
    )
    expect(html).toContain('de 01/07/2026 a 31/07/2026')
    // O painel voltou como gráfico, e não como lista de números.
    expect(html).toContain('min-width:600px')
  })

  it('não posiciona registro pela data de ativação nem pela de cancelamento', () => {
    const html = renderPage()

    for (const wrong of [
      'por data de ativação',
      'por data de cancelamento',
      'ativadas no dia',
      'canceladas no dia',
    ]) {
      expect(html).not.toContain(wrong)
    }
  })

  it('publica a alternativa acessível da série, fora da área rolável', () => {
    const { daily, metrics } = snapshotOf()
    const html = renderPage()
    const wrapped =
      html.match(/<div class="sr-only fixed left-0 top-0 pointer-events-none"><table>/g) ?? []

    expect(wrapped).toHaveLength(1)
    expect(html).toContain('<caption>')
    expect(html).toContain('<th scope="col">Vendas iniciadas</th>')
    expect(html).toContain('<th scope="row">01/07/2026</th>')
    expect(html).toContain('<th scope="row">31/07/2026</th>')
    // Um dia por linha, e a série fecha com o total iniciado do recorte.
    expect(daily).toHaveLength(31)
    expect(daily.reduce((total, point) => total + point.startedSales, 0)).toBe(
      metrics.startedSales,
    )
  })
})

/* -------------------------------------------------------------------------- */
/* Origem das vendas                                                          */
/* -------------------------------------------------------------------------- */

describe('Origem das vendas', () => {
  it('mantém o painel, os nomes oficiais e a regra pelo indicador', () => {
    const html = renderPage()

    expect(html).toContain('Origem das vendas')
    expect(html).toContain('Indicação')
    expect(html).toContain('Vendedores')
    expect(html).toContain('Classificação da venda conforme o indicador')
    expect(html).toContain('com CPF de indicador, é Indicação')
    expect(html).toContain('sem indicador, é atribuída a Vendedores')

    for (const wrong of ['canal de aquisição', 'venda passiva', 'prospecção', 'Indicação 000.']) {
      expect(html).not.toContain(wrong)
    }
  })

  it('fecha as duas origens com as vendas iniciadas, e não só com as ativas', () => {
    const { metrics, origins } = snapshotOf()
    const html = renderPage()
    const [indicacao, vendedores] = origins

    expect(indicacao.startedSales + vendedores.startedSales).toBe(metrics.startedSales)
    expect(html).toContain(
      `Somadas, as duas origens correspondem às ${formatNumber(metrics.startedSales)} vendas iniciadas do`,
    )
    expect(html).toContain(`>${formatNumber(indicacao.startedSales)}</span>`)
    expect(html).toContain(`>${formatNumber(vendedores.startedSales)}</span>`)
    expect(html).toContain(`${formatPercent(indicacao.share)} do total`)
    // O universo deixou de ser somente o das vendas que continuam ativas.
    expect(metrics.startedSales).toBeGreaterThan(metrics.activated)
    expect(html).not.toContain('vendas ativas iniciadas do recorte')
  })
})

/* -------------------------------------------------------------------------- */
/* Situação das vendas                                                        */
/* -------------------------------------------------------------------------- */

describe('Situação das vendas', () => {
  it('usa o título e o subtítulo aprovados', () => {
    const html = renderPage()

    expect(html).toContain('Situação das vendas')
    expect(html).toContain('Onde estão hoje as vendas com Data de Início no período selecionado.')
  })

  it('é um painel compacto, e não mais a árvore ramificada', () => {
    const html = renderSituation()

    // Exatamente cinco itens de composição, sem ramos intermediários, sem
    // trilho de árvore e sem os traços de ligação que a versão anterior usava.
    expect((html.match(/rounded-lg border border-\[var\(--divider\)\] px-2\.5 py-2/g) ?? []).length).toBe(5)
    expect(html).not.toContain('Não chegaram à ativação')
    expect(html).not.toContain('border-l border-[var(--divider)] pl-3')
    // Os agregados por ramo saíram junto com a árvore.
    expect(html).not.toContain('% das iniciadas')
    // Altura contida: uma barra de composição, e não um bloco de altura livre.
    expect(html).toContain('flex h-3 gap-px overflow-hidden rounded-full')
  })

  it('fecha os cinco resultados exclusivos com as vendas iniciadas', () => {
    const { metrics } = snapshotOf()
    const html = renderSituation()
    const slices: readonly (readonly [string, number])[] = [
      ['Ativadas sem cancelamento posterior', metrics.activated],
      ['Ainda em fluxo', metrics.inFlow],
      ['Perda pré-ativação', metrics.preActivationLosses],
      ['Churn pós-ativação', metrics.churn],
      ['Sem classificação', metrics.unclassified],
    ]

    expect(slices.reduce((total, [, value]) => total + value, 0)).toBe(metrics.startedSales)
    slices.forEach(([label, value]) => {
      expect(html).toContain(label)
      expect(html).toContain(`>${formatNumber(value)}</b>`)
    })
    expect(html).toContain('Os cinco resultados são exclusivos e somam as')
    expect(html).toContain(`>${formatNumber(metrics.startedSales)}</b>`)
  })

  it('não transforma Chegaram à ativação em uma sexta fatia', () => {
    const { metrics } = snapshotOf()
    const html = renderSituation()

    // O agregado é explicado como agregado, e nunca recebe contagem própria na
    // composição: somá-lo às fatias ultrapassaria o total iniciado.
    expect(html).toContain('não aparece como uma fatia própria')
    expect(html).not.toContain(`>${formatNumber(metrics.reachedActivation)}</b>`)
    expect(metrics.reachedActivation).toBe(metrics.activated + metrics.churn)
  })

  it('mantém contagem e percentual em texto para as categorias pequenas', () => {
    const { metrics } = snapshotOf()
    const html = renderSituation()

    // A menor categoria não depende do tamanho do traço na barra.
    expect(metrics.unclassified).toBeLessThan(metrics.activated)
    expect(html).toContain(`>${formatNumber(metrics.unclassified)}</b>`)
    expect(html).toContain(formatPercent(metrics.unclassified / metrics.startedSales))
  })

  it('avisa que a taxa oficial do churn usa as vendas que chegaram à ativação', () => {
    const { metrics } = snapshotOf()
    const html = renderSituation()

    expect(html).toContain(
      `Taxa do indicador: ${formatPercent(metrics.churnShare!)} sobre as ${formatNumber(metrics.reachedActivation)} vendas que chegaram à ativação.`,
    )
  })

  it('não transforma a composição em botão', () => {
    const html = renderSituation()

    expect(html).not.toContain('<button')
    expect(html).not.toContain('role="button"')
    expect(html).not.toContain('cursor-pointer')
  })

  it('mostra o estado vazio quando nenhuma venda corresponde aos filtros', () => {
    const agosto = { periodStart: '2026-08-01', periodEnd: '2026-08-31' }
    const html = renderSituation(agosto)

    expect(snapshotOf(agosto).metrics.startedSales).toBe(0)
    expect(html).toContain('Nenhuma venda iniciada corresponde aos filtros selecionados.')
    expect(html).toContain('Limpe os filtros ou amplie o período para voltar ao recorte inicial.')
    expect(html).not.toContain('0,0%')
  })

  it('funciona nos dois temas, com a cor semântica de cada resultado', () => {
    const claro = renderSituation()
    const escuro = renderSituation({}, 'dark')

    // Verde de ativação, âmbar de fluxo, vermelho de perda e violeta de churn.
    for (const color of ['#00844d', '#b45309', '#b51d38', '#6d28d9']) {
      expect(claro).toContain(color)
      expect(escuro).not.toContain(color)
    }
    for (const color of ['#34d399', '#f7ab24', '#ff8fa3', '#c4b5fd']) {
      expect(escuro).toContain(color)
      expect(claro).not.toContain(color)
    }
  })
})

/* -------------------------------------------------------------------------- */
/* Filtros globais                                                            */
/* -------------------------------------------------------------------------- */

describe('filtros globais da página', () => {
  it('oferece os sete filtros deste bloco, com os resultados aprovados', () => {
    const html = renderPage()

    for (const text of [
      'Data inicial',
      'Data final',
      'Cidade de instalação',
      'Todos os vendedores',
      'Todas as origens',
      'Todos os planos',
      'Resultado comercial',
      'Todos os resultados',
      'Ativada',
      'Ainda em fluxo',
      'Perda pré-ativação',
      'Churn pós-ativação',
      'Sem classificação',
      'Limpar filtros',
    ]) {
      expect(html).toContain(text)
    }

    expect(html).not.toContain('Todos os status')
    expect(html).not.toContain('CPF indicador')
    expect(html).not.toContain('Todas as modalidades')
    expect(html).not.toContain('Todos os motivos')
  })

  it('informa a data de apuração sem repetir o total de vendas iniciadas', () => {
    const html = renderPage()

    expect(html).toContain(`Situação em <b class="font-mono text-[var(--text-item)]">31/07/2026`)
    // O total do recorte é o valor do primeiro card: a faixa dos filtros não o
    // repete, em nenhuma das duas flexões.
    expect(html).not.toContain('vendas iniciadas no recorte')
    expect(html).not.toContain('venda iniciada no recorte')
    expect(html).not.toContain('vendas ativas iniciadas no recorte')
  })

  it('dá a linha inteira a cada campo no celular, e larguras naturais a partir de sm', () => {
    const html = renderPage()

    // Sete campos, cada um ocupando a largura disponível até `sm`. Antes eles
    // dividiam uma única linha com `flex-1` e encolhiam até ficarem ilegíveis
    // em 390 px.
    expect((html.match(/flex w-full min-w-0 items-center/g) ?? []).length).toBe(7)
    expect((html.match(/sm:w-auto sm:flex-none/g) ?? []).length).toBe(7)
    // O contêiner continua quebrando linha conforme o espaço disponível.
    expect(html).toContain('flex flex-wrap gap-2')
  })

  it('desabilita Limpar filtros exatamente no recorte inicial', () => {
    const cities = base().cities
    const options = snapshotOf().options
    const render = (filters: CycleFilters) =>
      renderToStaticMarkup(
        <SalesPeriodFilters
          cities={cities}
          filters={filters}
          onChange={() => {}}
          options={options}
          referenceDate={base().referenceDate}
        />,
      )

    const inicial = render(initialSalesPeriodCycleFilters())
    const filtrado = render({ ...initialSalesPeriodCycleFilters(), outcome: 'churn-pos-ativacao' })

    expect(inicial).toContain('disabled=""')
    expect(filtrado).not.toContain('disabled=""')
  })
})

/* -------------------------------------------------------------------------- */
/* Coerência entre filtro, indicadores e tabela                               */
/* -------------------------------------------------------------------------- */

describe('coerência do recorte entre indicadores, situação e tabela', () => {
  it('recorta por resultado comercial sem reclassificar nenhuma venda', () => {
    const snapshot = snapshotOf({ outcome: 'churn-pos-ativacao' })
    const { metrics } = snapshot
    const situacao = renderSituation({ outcome: 'churn-pos-ativacao' })
    const tabela = renderTable(snapshot.records)

    expect(metrics.startedSales).toBe(metrics.churn)
    // Todo o recorte chegou à ativação, então o churn é 100% da composição.
    expect(metrics.reachedActivation).toBe(metrics.startedSales)
    expect(situacao).toContain('Churn pós-ativação')
    // As cinco fatias continuam visíveis, e é isso que mostra o fechamento: as
    // quatro zeradas mais o churn somam o total iniciado.
    expect(situacao).toContain('Ainda em fluxo')
    expect(situacao).toContain(
      '<b class="font-mono text-[17px] font-bold leading-none text-[var(--text-heading)]">0</b>',
    )
    expect(situacao).toContain(
      `<b class="font-mono text-[17px] font-bold leading-none text-[var(--text-heading)]">${formatNumber(metrics.churn)}</b>`,
    )
    // Uma linha por venda, e todas com o mesmo resultado.
    expect((tabela.match(/Churn pós-ativação/g) ?? []).length).toBe(rowCount(tabela))
    expect(tabela).not.toContain('>Ativada<')
  })

  it('recorta por cidade de instalação', () => {
    const snapshot = snapshotOf({ cityId: 'piracaia' })
    const tabela = renderTable(snapshot.records)

    expect(snapshot.metrics.startedSales).toBeLessThan(snapshotOf().metrics.startedSales)
    expect(snapshot.records.every((record) => record.cityName === 'Piracaia')).toBe(true)
    // Uma célula de cidade por linha exibida, e nenhuma outra cidade na página.
    expect((tabela.match(/>Piracaia<\/p>/g) ?? []).length).toBe(rowCount(tabela))
    expect(tabela).not.toContain('>Atibaia</p>')
  })

  it('recorta por vendedor responsável', () => {
    const sellerId = snapshotOf().options.sellers[0].id
    const sellerName = snapshotOf().options.sellers[0].name
    const snapshot = snapshotOf({ sellerId })
    const tabela = renderTable(snapshot.records)

    expect(snapshot.records.length).toBeGreaterThan(0)
    expect(snapshot.records.every((record) => record.sellerId === sellerId)).toBe(true)
    expect((tabela.match(new RegExp(sellerName, 'g')) ?? []).length).toBeGreaterThanOrEqual(
      rowCount(tabela),
    )
  })

  it('recorta por origem, mantendo a vendedora da venda indicada', () => {
    const indicacao = snapshotOf({ origin: 'indicacao' })
    const vendedores = snapshotOf({ origin: 'vendedores' })
    const tabela = renderTable(indicacao.records)

    expect(indicacao.metrics.startedSales + vendedores.metrics.startedSales).toBe(
      snapshotOf().metrics.startedSales,
    )
    expect((tabela.match(/Indicação/g) ?? []).length).toBe(rowCount(tabela))
    expect(tabela).not.toContain('>Vendedores<')
    expect(indicacao.records.every((record) => record.sellerName.length > 0)).toBe(true)
  })

  it('recorta por plano', () => {
    const planName = snapshotOf().options.plans[0]
    const snapshot = snapshotOf({ planName })
    const tabela = renderTable(snapshot.records)

    expect(snapshot.records.length).toBeGreaterThan(0)
    expect(snapshot.records.every((record) => record.planName === planName)).toBe(true)
    expect((tabela.match(new RegExp(`>${planName}</p>`, 'g')) ?? []).length).toBe(rowCount(tabela))
  })

  it('devolve a primeira página quando o recorte encolhe abaixo da página pedida', () => {
    const recorte = snapshotOf({ outcome: 'churn-pos-ativacao' }).records
    const html = renderTable(recorte, { page: 7 })

    expect(recorte.length).toBeGreaterThan(0)
    expect(recorte.length).toBeLessThanOrEqual(10)
    // Nenhuma página vazia: a paginação corrige a página pedida.
    expect(rowCount(html)).toBe(recorte.length)
    expect(html).toContain('Página <b class="font-mono text-[var(--text-item)]">1</b>')
  })
})

/* -------------------------------------------------------------------------- */
/* Tabela do ciclo                                                            */
/* -------------------------------------------------------------------------- */

describe('tabela das vendas iniciadas', () => {
  it('monta as dez colunas aprovadas, sem filtro local nem ordenação', () => {
    const html = renderPage()

    for (const column of [
      'Data de Início',
      'Contrato e cliente',
      'Vendedor e origem',
      'Cidade e plano',
      'Resultado comercial',
      'Status atual',
      'Modalidade e execução',
      'Cobrança da instalação',
    ]) {
      expect(html).toContain(column)
    }

    expect(html).toContain('table-fixed')
    expect((html.match(/<col style=/g) ?? []).length).toBe(10)
    // Nenhum ícone de filtro sem comportamento implementado.
    expect(html).not.toContain('aria-label="Filtrar')
    expect(html).not.toContain('Limpar filtros da tabela')
    expect(html).not.toContain('role="dialog"')
  })

  it('recupera o acabamento visual da tabela anterior', () => {
    const html = renderPage()

    // Mesma densidade de linha, mesmo cabeçalho, mesmas divisórias, células
    // alinhadas ao meio e rolagem lateral dentro do próprio painel.
    expect(rowCount(html)).toBe(10)
    expect(html).toContain('height:40px')
    expect(html).toContain('min-height:520px')
    expect(html).toContain('mt-3 overflow-x-auto')
    expect(html).toContain(
      'px-2 py-2 align-middle text-[10px] font-bold uppercase tracking-[0.45px]',
    )
    expect((html.match(/border-b border-\[var\(--divider\)\] last:border-0/g) ?? []).length).toBe(10)
    expect(html).toContain('w-full min-w-[1320px] table-fixed border-collapse text-left')
  })

  it('pagina de dez em dez, contando as vendas do recorte', () => {
    const { metrics } = snapshotOf()
    const html = renderPage()

    expect(html).toContain(
      `de <b class="font-mono text-[var(--text-item)]">${formatNumber(metrics.startedSales)}</b> vendas iniciadas`,
    )
    expect(html).toContain('Anterior')
    expect(html).toContain('Próxima')
    expect(html).toContain('aria-label="Paginação do detalhamento das vendas iniciadas"')
  })

  it('mantém uma linha por venda mesmo com várias Ordens de Serviço', () => {
    const record = pick((item) => item.serviceOrders.length > 1)
    const html = renderTable([record])

    expect(record.serviceOrders.length).toBeGreaterThan(1)
    expect(rowCount(html)).toBe(1)
    expect((html.match(new RegExp(record.contractCode.replace('#', ''), 'g')) ?? []).length).toBe(1)
    expect(html).not.toMatch(/OS-\d/)
  })

  it('usa texto explícito para ativação e cancelamento ausentes', () => {
    const semAtivacao = pick((item) => item.activatedAt === null && item.canceledAt === null)
    const comChurn = pick((item) => item.outcome === 'churn-pos-ativacao')
    const html = renderTable([semAtivacao])
    const churn = renderTable([comChurn])

    expect(html).toContain('Ainda não ativada')
    expect(html).toContain('Sem cancelamento')
    // Nenhum traço, zero ou data falsa no lugar do evento que não aconteceu.
    expect(html).not.toContain('01/01/1970')
    expect(html).not.toContain('>-<')

    expect(churn).toContain(formatIsoAsBrDate(comChurn.activatedAt!))
    expect(churn).toContain(formatIsoAsBrDate(comChurn.canceledAt!))
    expect(churn).not.toContain('Ainda não ativada')
    expect(churn).not.toContain('Sem cancelamento')
  })

  it('separa instalação isenta de ausência de dado e de não aplicável', () => {
    const isenta = pick((item) => item.installationCharge === 'isenta')
    const semDado = pick((item) => item.installationCharge === 'sem-dado')
    const naoAplicavel = pick((item) => item.installationCharge === 'nao-aplicavel')

    const isentaHtml = renderTable([isenta])
    const semDadoHtml = renderTable([semDado])

    expect(isentaHtml).toContain('Cobrança: Isenta')
    expect(isentaHtml).not.toContain('Sem dado')
    expect(semDadoHtml).toContain('Cobrança: Sem dado')
    expect(semDadoHtml).not.toContain('Isenta')
    expect(renderTable([naoAplicavel])).toContain('Cobrança: Não aplicável')
  })

  it('não apresenta ativação remota como instalação física', () => {
    const remota = pick((item) => item.activationMode === 'ativacao-remota')
    const fisica = pick((item) => item.activationMode === 'instalacao-fisica')
    const remotaHtml = renderTable([remota])
    const fisicaHtml = renderTable([fisica])

    expect(remotaHtml).toContain('Ativação remota')
    expect(remotaHtml).not.toContain('Instalação física')
    expect(fisicaHtml).toContain('Instalação física')
    expect(fisicaHtml).not.toContain('Ativação remota')
    // Execução resumida continua sendo leitura própria, e não modalidade.
    expect(remotaHtml).toContain('Execução:')
  })

  it('mostra o estado vazio no lugar da tabela quando nada corresponde', () => {
    const html = renderTable([])

    expect(html).toContain('Nenhuma venda iniciada corresponde aos filtros selecionados.')
    expect(html).toContain('Limpe os filtros ou amplie o período para voltar ao recorte inicial.')
    expect(html).not.toContain('<table')
    expect(html).not.toContain('Anterior')
  })

  it('não oferece ação ainda não implementada', () => {
    const html = renderTable(snapshotOf().records)

    // Os únicos botões da tabela são os dois da paginação.
    expect((html.match(/<button/g) ?? []).length).toBe(2)
    expect(html).not.toContain('Ver assinatura')
    expect(html).not.toContain('Ver OS')
    expect(html).not.toContain('Detalhes')
  })
})

/* -------------------------------------------------------------------------- */
/* Erro de integridade                                                        */
/* -------------------------------------------------------------------------- */

describe('erro de integridade do ciclo', () => {
  it('apresenta o erro em vez de converter o recorte em lista vazia', async () => {
    const message = 'Venda sem fato comercial correspondente no ciclo: VD-2026-00001'

    vi.resetModules()
    // O modelo interrompe de propósito quando uma venda perde o fato comercial.
    // Aqui a falha é forçada, e só neste teste, para provar que a página mostra o
    // erro em vez de uma tela sem vendas.
    vi.doMock('./salesPeriodCycleModel', async (importOriginal) => {
      const actual = await importOriginal<typeof import('./salesPeriodCycleModel')>()

      return {
        ...actual,
        buildSalesPeriodCycleSnapshot: () => {
          throw new Error(message)
        },
      }
    })

    try {
      const [{ SalesPeriod: ComFalha }, { PreferencesProvider: Provider }, mock] =
        await Promise.all([
          import('./SalesPeriod'),
          import('../../../contexts/PreferencesContext'),
          import('../../../data/mockCommercialData'),
        ])

      // A base existe: o que falha é a montagem do ciclo, e não o carregamento.
      mock.getCommercialDataset()

      const html = renderToStaticMarkup(
        <Provider>
          <ComFalha />
        </Provider>,
      )

      expect(html).toContain('role="alert"')
      expect(html).toContain('Não foi possível montar as vendas iniciadas no período')
      expect(html).toContain(message)
      expect(html).not.toContain('Nenhuma venda iniciada corresponde aos filtros selecionados.')
      expect(html).not.toContain('Situação das vendas')
    } finally {
      vi.doUnmock('./salesPeriodCycleModel')
      vi.resetModules()
    }
  })
})
